import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SAMPLE_QUESTIONS } from './src/data/sampleQuestions.js';
import { Question, GameSession, Participant, SessionStatus, GameHistoryRecord } from './src/types.js';
import { safeInsertQuizRoom, inspectQuizRoomSchema } from './src/lib/quizRoomInspector.js';

const app = express();
const PORT = 3000;
const server = http.createServer(app);

app.use(express.json());

// Supabase Server Client Helper
function getSupabaseServer(): SupabaseClient | null {
  const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '';
  const key = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  if (url && key) {
    try {
      return createClient(url, key);
    } catch (e) {
      console.warn('Server Supabase initialization warning:', e);
    }
  }
  return null;
}

// In-Memory Database Stores (Synced with Supabase when available)
let questionBank: Question[] = [...SAMPLE_QUESTIONS];
const activeSessions: Map<string, GameSession> = new Map();
const gameHistory: GameHistoryRecord[] = [];

// Sync state helpers
async function syncQuestionsFromSupabase() {
  const sb = getSupabaseServer();
  if (!sb) return;
  try {
    const { data, error } = await sb.from('questions').select('*').order('created_at', { ascending: false });
    if (!error && data && data.length > 0) {
      questionBank = data.map((q: any) => ({
        id: q.id,
        question: q.question,
        options: Array.isArray(q.options) ? q.options : (typeof q.options === 'string' ? JSON.parse(q.options) : q.options),
        correctAnswer: q.correct_answer,
        category: q.category,
        difficulty: q.difficulty,
        explanation: q.explanation || '',
        tags: Array.isArray(q.tags) ? q.tags : [],
        estimatedTimeSec: q.estimated_time_sec || 20,
        status: 'active'
      }));

    }
  } catch (err) {
    console.error('Failed to sync questions from Supabase:', err);
  }
}

async function saveQuestionToSupabaseServer(q: Question) {
  const sb = getSupabaseServer();
  if (!sb) return;
  try {
    await sb.from('questions').upsert({
      id: q.id,
      question: q.question,
      options: q.options,
      correct_answer: q.correctAnswer,
      category: q.category,
      difficulty: q.difficulty,
      explanation: q.explanation || ''
    });
  } catch (e) {
    console.error('Supabase save question error:', e);
  }
}

async function saveQuestionsBulkToSupabaseServer(questions: Question[]) {
  const sb = getSupabaseServer();
  if (!sb || questions.length === 0) return;
  try {
    const rows = questions.map(q => ({
      id: q.id,
      question: q.question,
      options: q.options,
      correct_answer: q.correctAnswer,
      category: q.category,
      difficulty: q.difficulty,
      explanation: q.explanation || ''
    }));
    const { error } = await sb.from('questions').upsert(rows);
    if (error) {
      if (error.code === '42P01') {
        console.warn('Supabase table "questions" missing. Run the SQL schema script in Supabase SQL Editor.');
      } else if (error.code === '42501') {
        console.warn('Supabase RLS policy issue on "questions". Allow public access or disable RLS.');
      } else {
        console.warn('Supabase bulk save questions error:', error.message || error);
      }
    }
  } catch (e) {
    console.warn('Supabase bulk save questions exception:', e);
  }
}

async function saveSessionToSupabaseServer(session: GameSession) {
  const sb = getSupabaseServer();
  if (!sb) return;

  const roomData = {
    id: session.id,
    title: session.title,
    host_id: session.hostId || 'host',
    status: session.status,
    current_question_index: session.currentQuestionIndex,
    timer_duration_sec: session.settings.timerDurationSec || 20,
    settings: session.settings,
    questions: session.questions,
    updated_at: new Date().toISOString()
  };

  try {
    const res = await safeInsertQuizRoom(sb, roomData);
    if (!res.success) {
      console.error('Server Quiz Room Insert Cancelled:', res.error);
    }
  } catch (e) {
    console.error('Supabase save session error:', e);
  }
}

async function saveParticipantToSupabaseServer(roomId: string, p: Participant) {
  const sb = getSupabaseServer();
  if (!sb) return;
  try {
    await sb.from('participants').upsert({
      id: p.id,
      room_id: roomId,
      name: p.name,
      avatar: p.avatar,
      score: p.score,
      streak: p.streak
    });
  } catch (e) {
    console.error('Supabase save participant error:', e);
  }
}

async function saveAnswerToSupabaseServer(roomId: string, participantId: string, questionIndex: number, selectedOption: number, isCorrect: boolean, pointsAwarded: number, timeTakenMs: number) {
  const sb = getSupabaseServer();
  if (!sb) return;
  try {
    await sb.from('answers').insert({
      id: `ans_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      room_id: roomId,
      participant_id: participantId,
      question_index: questionIndex,
      selected_option: selectedOption,
      is_correct: isCorrect,
      points_awarded: pointsAwarded,
      time_taken_ms: timeTakenMs
    });
  } catch (e) {
    console.error('Supabase save answer error:', e);
  }
}

async function fetchSessionFromSupabaseServer(roomId: string): Promise<GameSession | null> {
  const sb = getSupabaseServer();
  if (!sb) return null;
  try {
    const { data: roomData, error: roomError } = await sb.from('quiz_rooms').select('*').eq('id', roomId.toUpperCase()).single();
    if (roomError || !roomData) return null;

    const { data: pData } = await sb.from('participants').select('*').eq('room_id', roomId.toUpperCase());
    const participantsObj: Record<string, Participant> = {};
    if (pData) {
      pData.forEach((p: any) => {
        participantsObj[p.id] = {
          id: p.id,
          name: p.name,
          avatar: p.avatar || '⚡',
          score: p.score || 0,
          streak: p.streak || 0,
          correctCount: 0,
          totalResponseTime: 0,
          answers: {},
          joinedAt: Date.now(),
          isOnline: true
        };
      });
    }

    return {
      id: roomData.id,
      title: roomData.title,
      createdAt: new Date(roomData.created_at || Date.now()).getTime(),
      status: roomData.status,
      hostId: roomData.host_id,
      settings: roomData.settings || {},
      questions: roomData.questions || [],
      currentQuestionIndex: roomData.current_question_index || 0,
      questionStartTime: Date.now(),
      timerRemaining: roomData.timer_duration_sec || 20,
      isTimerPaused: false,
      participants: participantsObj
    };
  } catch (e) {
    console.error('Supabase fetch session server error:', e);
    return null;
  }
}

async function saveHistoryToSupabaseServer(record: GameHistoryRecord) {
  const sb = getSupabaseServer();
  if (!sb) return;
  try {
    await sb.from('game_results').insert({
      id: record.id,
      room_id: record.id.replace('hist_', ''),
      title: record.title,
      participant_count: record.totalParticipants,
      leaderboard: record.participants,
      completed_at: new Date(record.timestamp || Date.now()).toISOString()
    });
  } catch (e) {
    console.error('Supabase save history server error:', e);
  }
}

async function fetchHistoryFromSupabaseServer(): Promise<GameHistoryRecord[]> {
  const sb = getSupabaseServer();
  if (!sb) return [];
  try {
    const { data, error } = await sb.from('game_results').select('*').order('completed_at', { ascending: false });
    if (error || !data) return [];

    return data.map((row: any) => ({
      id: row.id,
      title: row.title,
      date: new Date(row.completed_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      timestamp: new Date(row.completed_at).getTime(),
      totalParticipants: row.participant_count || 0,
      totalQuestions: 10,
      averageScore: 0,
      averageAccuracy: 0,
      winnerName: row.leaderboard?.[0]?.name || 'N/A',
      winnerScore: row.leaderboard?.[0]?.score || 0,
      category: 'General',
      participants: row.leaderboard || []
    }));
  } catch (e) {
    console.error('Supabase fetch history server error:', e);
    return [];
  }
}

// Initial sync on startup
syncQuestionsFromSupabase();

// WebSocket Client Store
interface ClientInfo {
  ws: WebSocket;
  sessionId: string;
  participantId?: string;
  isHost: boolean;
}
const connectedClients: Set<ClientInfo> = new Set();

// Gemini AI Client (Lazy initialization on server)
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

function generateFallbackQuestions(rawText?: string, topic?: string, count: number = 5, difficulty: string = 'Medium', category: string = 'General Knowledge'): Question[] {
  const questions: Question[] = [];
  
  if (rawText && rawText.trim().length > 0) {
    const lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    const questionLines = lines.filter(l => l.endsWith('?') || /^\d+[\.\)]/.test(l) || l.includes(':'));
    
    if (questionLines.length > 0) {
      for (let i = 0; i < Math.min(count, questionLines.length); i++) {
        const rawQ = questionLines[i].replace(/^\d+[\.\)]\s*/, '').trim();
        questions.push({
          id: `ai_${Date.now()}_${i}`,
          category: category as any,
          difficulty: difficulty as any,
          question: rawQ.endsWith('?') ? rawQ : `What key fact is described by: "${rawQ.slice(0, 60)}"?`,
          options: [
            `Primary principle of ${category}`,
            `Secondary factor in ${topic || category}`,
            `Alternative standard method`,
            `None of the above`
          ],
          correctAnswer: 0,
          explanation: `Extracted from study notes: "${rawQ.slice(0, 100)}"`,
          tags: [category, difficulty],
          estimatedTimeSec: 20,
          status: 'active'
        });
      }
    } else {
      const paragraphs = rawText.split(/\n\s*\n/).filter(p => p.trim().length > 10);
      for (let i = 0; i < Math.min(count, Math.max(1, paragraphs.length)); i++) {
        const pSnippet = (paragraphs[i] || rawText).slice(0, 70).trim();
        questions.push({
          id: `ai_${Date.now()}_${i}`,
          category: category as any,
          difficulty: difficulty as any,
          question: `Based on your notes: What is the main significance of "${pSnippet}..."?`,
          options: [
            `Core concept in ${category}`,
            `Experimental hypothesis`,
            `Historical background detail`,
            `Unrelated control metric`
          ],
          correctAnswer: 0,
          explanation: `Derived from pasted study material.`,
          tags: [category, difficulty],
          estimatedTimeSec: 20,
          status: 'active'
        });
      }
    }
  }

  const targetTopic = topic || category || 'General Quiz';
  while (questions.length < count) {
    const idx = questions.length + 1;
    questions.push({
      id: `ai_${Date.now()}_${idx}`,
      category: category as any,
      difficulty: difficulty as any,
      question: `Question ${idx}: Which of the following best defines a fundamental concept in ${targetTopic}?`,
      options: [
        `The standard core specification for ${targetTopic}`,
        `An obsolete legacy practice`,
        `A rare edge case scenario`,
        `An unverified theoretical model`
      ],
      correctAnswer: 0,
      explanation: `Option A accurately states the core definition in ${targetTopic}.`,
      tags: [targetTopic, difficulty],
      estimatedTimeSec: 20,
      status: 'active'
    });
  }

  return questions;
}

// REST API Endpoints

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', serverTime: new Date().toISOString() });
});

// Questions CRUD
app.get('/api/questions', async (req, res) => {
  await syncQuestionsFromSupabase();
  res.json(questionBank);
});

app.post('/api/questions', async (req, res) => {
  const newQ: Question = {
    ...req.body,
    id: req.body.id || `q_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    status: 'active'
  };
  questionBank.push(newQ);
  await saveQuestionToSupabaseServer(newQ);
  res.status(201).json(newQ);
});

app.put('/api/questions/:id', async (req, res) => {
  const { id } = req.params;
  const index = questionBank.findIndex(q => q.id === id);
  if (index !== -1) {
    questionBank[index] = { ...questionBank[index], ...req.body };
    await saveQuestionToSupabaseServer(questionBank[index]);
    res.json(questionBank[index]);
  } else {
    res.status(404).json({ error: 'Question not found' });
  }
});

app.delete('/api/questions/:id', (req, res) => {
  const { id } = req.params;
  questionBank = questionBank.filter(q => q.id !== id);
  res.json({ success: true, id });
});

// Bulk Import Questions
app.post('/api/questions/import', async (req, res) => {
  const imported: Question[] = req.body;
  if (Array.isArray(imported)) {
    const newQuestions: Question[] = [];
    imported.forEach(q => {
      const newQ: Question = {
        id: q.id || `q_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        category: q.category || 'General Knowledge',
        difficulty: q.difficulty || 'Medium',
        question: q.question,
        options: q.options || ['A', 'B', 'C', 'D'],
        correctAnswer: q.correctAnswer ?? 0,
        explanation: q.explanation || '',
        tags: q.tags || [],
        estimatedTimeSec: q.estimatedTimeSec || 20,
        status: 'active'
      };
      questionBank.push(newQ);
      newQuestions.push(newQ);
    });
    await saveQuestionsBulkToSupabaseServer(newQuestions);
    return res.json({ success: true, added: imported.length, total: questionBank.length });
  }
  res.status(400).json({ error: 'Invalid payload' });
});


// AI Question Generator Endpoint (Server-Side Gemini with Smart Fallback)
app.post('/api/generate-questions', async (req, res) => {
  try {
    const { rawText, topic, count = 5, difficulty = 'Medium', category = 'General Knowledge' } = req.body;
    
    if (!rawText && !topic) {
      return res.status(400).json({ error: 'Please provide either raw text/pasted questions or a topic.' });
    }

    const ai = getGeminiClient();

    if (ai) {
      try {
        let systemInstruction = `You are an expert quiz creator and content parser. 
Convert the input into structured, high-quality multiple choice quiz questions.
Category: ${category}
Difficulty: ${difficulty}`;

        let prompt = '';
        if (rawText && rawText.trim().length > 0) {
          prompt = `Parse and extract structured multiple choice quiz questions from the following pasted text/notes/questions:
"""
${rawText}
"""
If the pasted content has explicit questions and answers, standardize them into 4 distinct options with one correct answer.
If the pasted text is general notes or study material, generate ${count} clear multiple-choice questions testing key facts.

Return ONLY a valid JSON array of objects. Do not include markdown formatting or backticks around the JSON.
Each object must have:
- "question": string
- "options": array of 4 distinct strings
- "correctAnswer": integer (0, 1, 2, or 3)
- "explanation": string explaining why the answer is correct
- "tags": array of 2-3 short keyword strings
- "estimatedTimeSec": integer (between 15 and 30)`;
        } else {
          prompt = `Generate ${count} multiple choice quiz questions about "${topic}".
Category: ${category}
Difficulty: ${difficulty}

Return ONLY a valid JSON array of objects. Do not include markdown formatting or backticks around the JSON.
Each object must have:
- "question": string
- "options": array of 4 distinct strings
- "correctAnswer": integer (0, 1, 2, or 3)
- "explanation": string explaining why the answer is correct
- "tags": array of 2-3 short keyword strings
- "estimatedTimeSec": integer (between 15 and 30)`;
        }

        const response = await ai.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: prompt,
          config: {
            systemInstruction,
            responseMimeType: 'application/json'
          }
        });

        let jsonStr = response.text || '';
        jsonStr = jsonStr.replace(/```json/gi, '').replace(/```/g, '').trim();

        const generatedItems = JSON.parse(jsonStr);
        
        const formattedQuestions: Question[] = generatedItems.map((item: any, idx: number) => ({
          id: `ai_${Date.now()}_${idx}`,
          category: category as any,
          difficulty: difficulty as any,
          question: item.question,
          options: Array.isArray(item.options) && item.options.length === 4 ? item.options : ['Option A', 'Option B', 'Option C', 'Option D'],
          correctAnswer: typeof item.correctAnswer === 'number' && item.correctAnswer >= 0 && item.correctAnswer <= 3 ? item.correctAnswer : 0,
          explanation: item.explanation || '',
          tags: Array.isArray(item.tags) ? item.tags : [topic || category],
          estimatedTimeSec: item.estimatedTimeSec || 20,
          status: 'active'
        }));

        questionBank.push(...formattedQuestions);
        await saveQuestionsBulkToSupabaseServer(formattedQuestions);
        return res.json({ success: true, questions: formattedQuestions });
      } catch (geminiError) {
        console.warn('Gemini API call warning, falling back to smart question builder:', geminiError);
      }
    }

    // Fallback when GEMINI_API_KEY is not configured or API call encounters an error
    const fallbackQuestions = generateFallbackQuestions(rawText, topic, count, difficulty, category);
    questionBank.push(...fallbackQuestions);
    await saveQuestionsBulkToSupabaseServer(fallbackQuestions);

    res.json({
      success: true,
      questions: fallbackQuestions,
      note: 'Generated using local smart quiz parser. (Add GEMINI_API_KEY in Settings secrets to enable live Gemini AI parsing)'
    });
  } catch (error: any) {
    console.error('AI Generation Route Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate questions' });
  }
});

// Create Game Session
app.post('/api/sessions', async (req, res) => {
  const { title, settings, selectedQuestionIds } = req.body;
  
  // Generate 6-character uppercase room code (e.g. A7KX92)
  const roomChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += roomChars.charAt(Math.floor(Math.random() * roomChars.length));
  }

  // Pick questions
  let selectedQuestions: Question[] = [];
  if (selectedQuestionIds && Array.isArray(selectedQuestionIds) && selectedQuestionIds.length > 0) {
    selectedQuestions = questionBank.filter(q => selectedQuestionIds.includes(q.id));
  } else {
    // Filter by categories if specified in settings
    let pool = [...questionBank].filter(q => q.status === 'active');
    if (settings?.categories && settings.categories.length > 0) {
      pool = pool.filter(q => settings.categories.includes(q.category));
    }
    if (settings?.isRandom) {
      pool = pool.sort(() => 0.5 - Math.random());
    }
    const count = settings?.questionCount || 10;
    selectedQuestions = pool.slice(0, count);
  }

  if (selectedQuestions.length === 0) {
    // Fallback if empty pool
    selectedQuestions = questionBank.slice(0, 5);
  }

  const session: GameSession = {
    id: code,
    title: title || 'Live Event Quiz',
    createdAt: Date.now(),
    status: 'LOBBY',
    hostId: `host_${Date.now()}`,
    settings: {
      questionBankId: 'default',
      categories: settings?.categories || [],
      questionCount: selectedQuestions.length,
      isRandom: settings?.isRandom ?? true,
      timerDurationSec: settings?.timerDurationSec || 20,
      showCorrectAnswer: settings?.showCorrectAnswer ?? true,
      enableLeaderboard: settings?.enableLeaderboard ?? true,
      enableSoundEffects: settings?.enableSoundEffects ?? true,
      enableCelebrations: settings?.enableCelebrations ?? true,
      enableFeedback: settings?.enableFeedback ?? true,
      enableBonusSpeedPoints: settings?.enableBonusSpeedPoints ?? true,
      allowAnswerChange: settings?.allowAnswerChange ?? false,
      maxParticipants: settings?.maxParticipants || 100
    },
    questions: selectedQuestions,
    currentQuestionIndex: 0,
    questionStartTime: null,
    timerRemaining: settings?.timerDurationSec || 20,
    isTimerPaused: false,
    participants: {}
  };

  activeSessions.set(code, session);
  await saveSessionToSupabaseServer(session);

  res.status(201).json(session);
});

// Debug Quiz Room Payload & Schema Inspector Endpoint
app.post('/api/quiz-rooms/debug-insert', async (req, res) => {
  const roomData = req.body || {};

  // 1. Log payload BEFORE insert
  console.log("Quiz Room Payload", roomData);

  const sb = getSupabaseServer();
  if (!sb) {
    return res.status(500).json({
      success: false,
      error: 'Supabase server client not initialized. Please check env variables.'
    });
  }

  // 2. Inspect database schema and compare payload
  const inspection = await inspectQuizRoomSchema(sb, roomData);

  // 3. If payload contains fields that do not exist in the table: do not insert, log mismatched fields, display clear error
  if (!inspection.valid) {
    console.error("Unknown fields:", inspection.unknownFields);
    console.error("Database columns:", inspection.dbColumns);

    return res.status(400).json({
      success: false,
      error: inspection.errorMessage,
      mismatchedFields: inspection.unknownFields,
      databaseColumns: inspection.dbColumns
    });
  }

  // 4. Only insert columns that exist
  const result = await safeInsertQuizRoom(sb, roomData);
  if (!result.success) {
    return res.status(500).json({
      success: false,
      error: result.error
    });
  }

  return res.status(200).json({
    success: true,
    message: 'Quiz Room inserted successfully after schema verification.',
    databaseColumns: inspection.dbColumns
  });
});

// Get Session Info
app.get('/api/sessions/:id', async (req, res) => {
  const roomId = req.params.id;
  let session = activeSessions.get(roomId);
  
  if (!session) {
    session = await fetchSessionFromSupabaseServer(roomId) || undefined;
    if (session) {
      activeSessions.set(session.id, session);
    }
  }

  if (session) {
    res.json(session);
  } else {
    res.status(404).json({ error: 'Session not found' });
  }
});

// History Endpoints
app.get('/api/history', async (req, res) => {
  const sbHistory = await fetchHistoryFromSupabaseServer();
  if (sbHistory && sbHistory.length > 0) {
    res.json(sbHistory);
  } else {
    res.json(gameHistory);
  }
});


// Real-Time WebSockets Engine
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

function broadcastToSession(sessionId: string, message: any) {
  const jsonStr = JSON.stringify(message);
  for (const client of connectedClients) {
    if (client.sessionId === sessionId && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(jsonStr);
    }
  }
}

wss.on('connection', (ws: WebSocket) => {
  let clientInfo: ClientInfo | null = null;

  ws.on('message', (rawMessage: string) => {
    try {
      const msg = JSON.parse(rawMessage.toString());
      const { type, sessionId, participantId, payload } = msg;

      if (!sessionId) return;

      const session = activeSessions.get(sessionId);

      if (type === 'JOIN_ROOM') {
        const isHost = payload?.isHost ?? false;
        const name = payload?.name || (isHost ? 'Host' : 'Player');
        const pId = participantId || (isHost ? session?.hostId || 'host' : `p_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`);

        clientInfo = { ws, sessionId, participantId: pId, isHost };
        connectedClients.add(clientInfo);

        if (session) {
          if (!isHost && !session.participants[pId]) {
            const avatarList = ['🦊', '🐯', '🦁', '🦉', '🚀', '⚡', '🧠', '🦄', '🐼', '🎨', '🔥', '👑'];
            const randomAvatar = avatarList[Math.floor(Math.random() * avatarList.length)];

            const newParticipant: Participant = {
              id: pId,
              name,
              avatar: payload?.avatar || randomAvatar,
              score: 0,
              streak: 0,
              correctCount: 0,
              totalResponseTime: 0,
              answers: {},
              joinedAt: Date.now(),
              isOnline: true
            };
            session.participants[pId] = newParticipant;
          } else if (session.participants[pId]) {
            session.participants[pId].isOnline = true;
          }

          // Save participant to Supabase
          if (!isHost && session.participants[pId]) {
            saveParticipantToSupabaseServer(sessionId, session.participants[pId]);
          }

          // Acknowledge join
          ws.send(JSON.stringify({
            type: 'ROOM_JOINED',
            sessionId,
            participantId: pId,
            payload: { session, isHost }
          }));

          // Notify everyone in session of state change
          broadcastToSession(sessionId, {
            type: 'SYNC_STATE',
            sessionId,
            payload: { session }
          });
        } else {
          ws.send(JSON.stringify({
            type: 'ERROR',
            sessionId,
            payload: { message: 'Game session not found. Check your join code.' }
          }));
        }
      } else if (type === 'SUBMIT_ANSWER') {
        if (!session || !participantId) return;

        const participant = session.participants[participantId];
        if (!participant) return;

        const currentQ = session.questions[session.currentQuestionIndex];
        if (!currentQ) return;

        const { selectedOption, timeTakenSec } = payload;
        
        // Prevent changing answer if settings forbid it
        if (!session.settings.allowAnswerChange && participant.answers[currentQ.id]) {
          return;
        }

        const isCorrect = selectedOption === currentQ.correctAnswer;
        let scoreGained = 0;
        let speedBonus = 0;

        if (isCorrect) {
          scoreGained = 100;
          if (session.settings.enableBonusSpeedPoints) {
            // Speed bonus: up to 50 extra points if answered within the first half of duration
            const totalDuration = session.settings.timerDurationSec || 20;
            const remainingFraction = Math.max(0, (totalDuration - timeTakenSec) / totalDuration);
            speedBonus = Math.round(remainingFraction * 50);
            scoreGained += speedBonus;
          }
          participant.streak = (participant.streak || 0) + 1;
          participant.correctCount = (participant.correctCount || 0) + 1;
        } else {
          participant.streak = 0;
        }

        participant.score = (participant.score || 0) + scoreGained;
        participant.totalResponseTime = (participant.totalResponseTime || 0) + timeTakenSec;

        participant.answers[currentQ.id] = {
          questionId: currentQ.id,
          selectedOption,
          timeTakenSec,
          isCorrect,
          scoreGained,
          speedBonus,
          timestamp: Date.now()
        };

        // Save answer and updated participant stats to Supabase
        saveAnswerToSupabaseServer(sessionId, participantId, session.currentQuestionIndex, selectedOption, isCorrect, scoreGained, Math.round(timeTakenSec * 1000));
        saveParticipantToSupabaseServer(sessionId, participant);

        broadcastToSession(sessionId, {
          type: 'SYNC_STATE',
          sessionId,
          payload: { session }
        });
      } else if (type === 'SEND_REACTION') {
        const { emoji, senderName } = payload;
        broadcastToSession(sessionId, {
          type: 'SEND_REACTION',
          sessionId,
          payload: { emoji, senderName, participantId }
        });
      } else if (type === 'HOST_ACTION') {
        if (!session || !clientInfo?.isHost) return;

        const { action } = payload;

        if (action === 'START_GAME') {
          session.status = 'QUESTION';
          session.currentQuestionIndex = 0;
          session.timerRemaining = session.questions[0]?.estimatedTimeSec || session.settings.timerDurationSec;
          session.revealTimerRemaining = 5;
          session.questionStartTime = Date.now();
          session.isTimerPaused = false;
        } else if (action === 'NEXT_QUESTION') {
          if (session.currentQuestionIndex < session.questions.length - 1) {
            session.currentQuestionIndex++;
            session.status = 'QUESTION';
            const nextQ = session.questions[session.currentQuestionIndex];
            session.timerRemaining = nextQ?.estimatedTimeSec || session.settings.timerDurationSec;
            session.revealTimerRemaining = 5;
            session.questionStartTime = Date.now();
            session.isTimerPaused = false;
          } else {
            session.status = 'ENDED';
            saveSessionToHistory(session);
          }
        } else if (action === 'PREV_QUESTION') {
          if (session.currentQuestionIndex > 0) {
            session.currentQuestionIndex--;
            session.status = 'QUESTION';
            const prevQ = session.questions[session.currentQuestionIndex];
            session.timerRemaining = prevQ?.estimatedTimeSec || session.settings.timerDurationSec;
            session.revealTimerRemaining = 5;
            session.questionStartTime = Date.now();
            session.isTimerPaused = false;
          }
        } else if (action === 'REVEAL_ANSWER' || action === 'SKIP_QUESTION') {
          session.status = 'ANSWER_REVEAL';
          session.revealTimerRemaining = 5;
        } else if (action === 'SHOW_LEADERBOARD') {
          session.status = 'LEADERBOARD';
        } else if (action === 'PAUSE_TIMER') {
          session.isTimerPaused = !session.isTimerPaused;
        } else if (action === 'ADJUST_TIMER') {
          const deltaSec = payload?.deltaSec || 0;
          session.timerRemaining = Math.max(1, session.timerRemaining + deltaSec);
        } else if (action === 'ADD_TEST_BOT') {
          const botAvatars = ['🤖', '🦊', '⚡', '🦉', '🚀', '🧠', '🦁', '🎯', '🦄', '💎'];
          const botNames = ['CyberAlex', 'QuizMasterBot', 'ByteNinja', 'NovaPlayer', 'PixelChamp', 'QuantumLearner', 'AIBrainiac', 'TurboTutor'];
          const randomName = `${botNames[Math.floor(Math.random() * botNames.length)]} ${Math.floor(Math.random() * 90 + 10)}`;
          const randomAvatar = botAvatars[Math.floor(Math.random() * botAvatars.length)];
          const botId = `bot_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

          const newBot: Participant = {
            id: botId,
            name: randomName,
            avatar: randomAvatar,
            score: 0,
            streak: 0,
            correctCount: 0,
            totalResponseTime: 0,
            answers: {},
            joinedAt: Date.now(),
            isOnline: true
          };
          session.participants[botId] = newBot;
          saveParticipantToSupabaseServer(sessionId, newBot);
        } else if (action === 'CLEAR_TEST_BOTS') {
          Object.keys(session.participants).forEach(pId => {
            if (pId.startsWith('bot_')) {
              delete session.participants[pId];
            }
          });
        } else if (action === 'END_GAME') {
          session.status = 'ENDED';
          saveSessionToHistory(session);
        } else if (action === 'RESTART_GAME') {
          session.status = 'LOBBY';
          session.currentQuestionIndex = 0;
          session.timerRemaining = session.settings.timerDurationSec;
          session.revealTimerRemaining = 5;
          session.isTimerPaused = false;
          // Reset participant scores
          Object.values(session.participants).forEach(p => {
            p.score = 0;
            p.streak = 0;
            p.correctCount = 0;
            p.totalResponseTime = 0;
            p.answers = {};
          });
        }

        saveSessionToSupabaseServer(session);

        broadcastToSession(sessionId, {
          type: 'SYNC_STATE',
          sessionId,
          payload: { session }
        });
      }

    } catch (err) {
      console.error('WS Error:', err);
    }
  });

  ws.on('close', () => {
    if (clientInfo) {
      connectedClients.delete(clientInfo);
      const session = activeSessions.get(clientInfo.sessionId);
      if (session && clientInfo.participantId && session.participants[clientInfo.participantId]) {
        session.participants[clientInfo.participantId].isOnline = false;
        broadcastToSession(clientInfo.sessionId, {
          type: 'SYNC_STATE',
          sessionId: clientInfo.sessionId,
          payload: { session }
        });
      }
    }
  });
});

function saveSessionToHistory(session: GameSession) {
  const participantsList = Object.values(session.participants).sort((a, b) => b.score - a.score);
  const winner = participantsList[0];
  const totalP = participantsList.length;
  const totalQ = session.questions.length;
  
  let totalScoreSum = 0;
  let totalCorrectSum = 0;

  participantsList.forEach(p => {
    totalScoreSum += p.score;
    totalCorrectSum += p.correctCount;
  });

  const avgScore = totalP > 0 ? Math.round(totalScoreSum / totalP) : 0;
  const avgAccuracy = (totalP > 0 && totalQ > 0) ? Math.round((totalCorrectSum / (totalP * totalQ)) * 100) : 0;

  const historyRecord: GameHistoryRecord = {
    id: `hist_${Date.now()}`,
    title: session.title,
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    timestamp: Date.now(),
    totalParticipants: totalP,
    totalQuestions: totalQ,
    averageScore: avgScore,
    averageAccuracy: avgAccuracy,
    winnerName: winner ? winner.name : 'N/A',
    winnerScore: winner ? winner.score : 0,
    category: session.settings.categories.join(', ') || 'Mixed Categories',
    participants: participantsList.map((p, idx) => ({
      name: p.name,
      score: p.score,
      correctCount: p.correctCount,
      avgTime: p.correctCount > 0 ? Number((p.totalResponseTime / p.correctCount).toFixed(1)) : 0,
      rank: idx + 1
    }))
  };

  gameHistory.unshift(historyRecord);
  session.historyId = historyRecord.id;
  saveHistoryToSupabaseServer(historyRecord);
}

// Server Authoritative 1-Second Countdown Loop
setInterval(() => {
  for (const [sessionId, session] of activeSessions.entries()) {
    if (!session.isTimerPaused) {
      if (session.status === 'QUESTION') {
        const currentQ = session.questions[session.currentQuestionIndex];
        if (currentQ) {
          const totalDuration = session.settings.timerDurationSec || 20;
          const elapsedTime = totalDuration - session.timerRemaining;

          if (elapsedTime >= 1) {
            Object.values(session.participants).forEach(p => {
              if (p.id.startsWith('bot_') && p.answers && !p.answers[currentQ.id]) {
                if (Math.random() < 0.35) {
                  let chosen: 0 | 1 | 2 | 3 = (currentQ.correctAnswer ?? 0) as any;
                  if (Math.random() > 0.65) {
                    chosen = Math.floor(Math.random() * 4) as 0 | 1 | 2 | 3;
                  }
                  const isCorrect = chosen === currentQ.correctAnswer;
                  const timeTakenSec = Math.min(totalDuration, Math.max(1, elapsedTime));

                  let scoreGained = 0;
                  let speedBonus = 0;
                  if (isCorrect) {
                    scoreGained = 100;
                    if (session.settings.enableBonusSpeedPoints) {
                      const remainingFraction = Math.max(0, (totalDuration - timeTakenSec) / totalDuration);
                      speedBonus = Math.round(remainingFraction * 50);
                      scoreGained += speedBonus;
                    }
                    p.streak = (p.streak || 0) + 1;
                    p.correctCount = (p.correctCount || 0) + 1;
                  } else {
                    p.streak = 0;
                  }

                  p.score = (p.score || 0) + scoreGained;
                  p.totalResponseTime = (p.totalResponseTime || 0) + timeTakenSec;
                  p.answers[currentQ.id] = {
                    questionId: currentQ.id,
                    selectedOption: chosen,
                    timeTakenSec,
                    isCorrect,
                    scoreGained,
                    speedBonus,
                    timestamp: Date.now()
                  };
                }
              }
            });
          }
        }

        if (session.timerRemaining > 0) {
          session.timerRemaining--;
          broadcastToSession(sessionId, {
            type: 'SYNC_STATE',
            sessionId,
            payload: { session }
          });
        } else {
          // Time expired! Transition to answer reveal automatically
          session.status = 'ANSWER_REVEAL';
          session.revealTimerRemaining = 3;
          broadcastToSession(sessionId, {
            type: 'SYNC_STATE',
            sessionId,
            payload: { session }
          });
        }
      } else if (session.status === 'ANSWER_REVEAL') {
        const currentRevealTime = session.revealTimerRemaining !== undefined ? session.revealTimerRemaining : 3;
        if (currentRevealTime > 0) {
          session.revealTimerRemaining = currentRevealTime - 1;
          broadcastToSession(sessionId, {
            type: 'SYNC_STATE',
            sessionId,
            payload: { session }
          });
        } else {
          // Reveal timer expired! Automatically advance to next question or end game
          if (session.currentQuestionIndex < session.questions.length - 1) {
            session.currentQuestionIndex++;
            session.status = 'QUESTION';
            const nextQ = session.questions[session.currentQuestionIndex];
            session.timerRemaining = nextQ?.estimatedTimeSec || session.settings.timerDurationSec || 20;
            session.revealTimerRemaining = 3;
            session.questionStartTime = Date.now();
          } else {
            session.status = 'ENDED';
            saveSessionToHistory(session);
          }
          broadcastToSession(sessionId, {
            type: 'SYNC_STATE',
            sessionId,
            payload: { session }
          });
        }
      }
    }
  }
}, 1000);

// Vite middleware for development vs static build serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`QuizPulse Live server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
