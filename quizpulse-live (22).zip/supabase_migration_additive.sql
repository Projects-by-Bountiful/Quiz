-- QuizPulse Additive Supabase Migration Script
-- Safe additive tables and columns for QuizPulse feedback & analytics

CREATE TABLE IF NOT EXISTS quiz_feedback (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL,
  participant_id TEXT,
  participant_name TEXT,
  participant_avatar TEXT,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast room_id feedback lookups
CREATE INDEX IF NOT EXISTS idx_quiz_feedback_room_id ON quiz_feedback(room_id);

-- Disable Row-Level Security on quiz_feedback to ensure seamless public insert/read
ALTER TABLE quiz_feedback DISABLE ROW LEVEL SECURITY;
