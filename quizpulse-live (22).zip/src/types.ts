export type Role = 
  | 'landing' 
  | 'participant' 
  | 'login' 
  | 'signup' 
  | 'verify-email'
  | 'forgot-password'
  | 'reset-password'
  | 'pricing'
  | 'host_dashboard' 
  | 'host_questions' 
  | 'host_categories' 
  | 'host_quizzes' 
  | 'host_participants' 
  | 'host_analytics' 
  | 'host_history' 
  | 'host_profile' 
  | 'host_settings'
  | 'host_payments';

export interface HostProfile {
  id: string;
  user_id?: string;
  full_name: string;
  email: string;
  phone?: string;
  location?: string;
  industry?: string;
  company?: string;
  job_title?: string;
  timezone?: string;
  created_at?: string;
  updated_at?: string;
}

export type Category = string;

export const DEFAULT_CATEGORIES: Category[] = [
  'Freelancing',
  'Web Development',
  'UI/UX Design',
  'AI Tools',
  'Virtual Assistant',
  'Project Management',
  'JavaScript & React',
  'Cybersecurity',
  'General Knowledge'
];

export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export type QuestionType =
  | 'multiple_choice'
  | 'fastest_fingers'
  | 'fill_blank'
  | 'ordering'
  | 'matching';

export type FastestFingerFormat =
  | 'true_false'
  | 'yes_no'
  | 'this_that'
  | 'higher_lower'
  | 'more_less'
  | 'before_after'
  | 'agree_disagree'
  | 'custom';

export const FASTEST_FINGER_FORMAT_LABELS: Record<FastestFingerFormat, string> = {
  true_false: 'True / False',
  yes_no: 'Yes / No',
  this_that: 'This / That',
  higher_lower: 'Higher / Lower',
  more_less: 'More / Less',
  before_after: 'Before / After',
  agree_disagree: 'Agree / Disagree',
  custom: 'Custom'
};

export const FASTEST_FINGER_PRESETS: Record<FastestFingerFormat, [string, string]> = {
  true_false: ['TRUE', 'FALSE'],
  yes_no: ['YES', 'NO'],
  this_that: ['ONE-OFF PROJECTS', 'RECURRING CLIENTS'],
  higher_lower: ['HIGHER', 'LOWER'],
  more_less: ['MORE', 'LESS'],
  before_after: ['BEFORE', 'AFTER'],
  agree_disagree: ['AGREE', 'DISAGREE'],
  custom: ['', '']
};

export interface MatchingPair {
  id: string;
  left: string;
  right: string;
}

export interface Question {
  id: string;
  type?: QuestionType; // Defaults to 'multiple_choice'
  fastestFingerFormat?: FastestFingerFormat; // Format metadata for Fastest Fingers (True/False, Yes/No, etc.)
  category: Category;
  difficulty: Difficulty;
  question: string;
  // Multiple Choice (4 options: A, B, C, D) & Fastest Fingers (exactly 2 options: A, B)
  options?: string[]; 
  correctAnswer?: number; // Index: 0-3 for MC, 0-1 for Fastest Fingers
  // Fill in the Blank
  acceptedAnswers?: string[];
  // Ordering / Ranking
  orderItems?: string[]; // The items in correct sequence
  // Matching
  matchingPairs?: MatchingPair[]; // Pairs to match
  explanation: string;
  tags: string[];
  estimatedTimeSec: number;
  status: 'active' | 'inactive';
}

export interface ParticipantAnswer {
  questionId: string;
  type?: QuestionType;
  selectedOption?: number; // For MC / Fastest Fingers
  textAnswer?: string; // For Fill in the Blank
  orderAnswer?: number[] | string[]; // For Ordering
  matchingAnswer?: Record<string, string>; // For Matching
  rawAnswer?: any;
  timeTakenSec: number;
  isCorrect: boolean;
  scoreGained: number;
  speedBonus: number;
  timestamp: number;
}

export interface Participant {
  id: string;
  name: string;
  avatar: string;
  score: number;
  streak: number;
  correctCount: number;
  totalResponseTime: number; // in seconds
  answers: Record<string, ParticipantAnswer>; // questionId -> answer
  joinedAt: number;
  isOnline: boolean;
  lastReaction?: string;
  maxStreak?: number;
  fastestResponseSec?: number;
}

export type SessionStatus = 
  | 'LOBBY'
  | 'QUESTION'
  | 'ANSWER_REVEAL'
  | 'LEADERBOARD'
  | 'ENDED';

export interface SoundConfig {
  countdownSound?: boolean;
  correctAnswerSound?: boolean;
  bonusSound?: boolean;
  leaderboardSound?: boolean;
  winnerSound?: boolean;
}

export interface SessionFeedback {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar: string;
  rating: number; // 1 to 5 stars
  comment?: string;
  timestamp: number;
}

export interface SessionSettings {
  questionBankId: string;
  categories: Category[];
  questionCount: number;
  isRandom: boolean;
  timerDurationSec: number;
  showCorrectAnswer: boolean;
  enableLeaderboard: boolean;
  enableSoundEffects: boolean; // Master Sound ON / OFF
  enableCelebrations: boolean; // Master Celebrations ON / OFF
  soundConfig?: SoundConfig;
  enableFeedback?: boolean; // Feedback collection ON / OFF
  enableBonusSpeedPoints: boolean;
  allowAnswerChange: boolean;
  maxParticipants: number;
  questionStartTime?: number;
}

export interface GameSession {
  id: string; // Session ID / Code (e.g. 849201)
  title: string;
  createdAt: number;
  status: SessionStatus;
  hostId: string;
  settings: SessionSettings;
  questions: Question[];
  currentQuestionIndex: number;
  questionStartTime: number | null; // Server timestamp when current question started
  timerRemaining: number; // Seconds remaining
  revealTimerRemaining?: number; // Seconds remaining during answer reveal auto-countdown
  isTimerPaused: boolean;
  participants: Record<string, Participant>;
  feedback?: Record<string, SessionFeedback>;
  historyId?: string;
}

export interface GameHistoryRecord {
  id: string;
  title: string;
  date: string;
  timestamp: number;
  totalParticipants: number;
  totalQuestions: number;
  averageScore: number;
  averageAccuracy: number;
  winnerName: string;
  winnerScore: number;
  category: string;
  participants: Array<{
    name: string;
    score: number;
    correctCount: number;
    avgTime: number;
    rank: number;
  }>;
  feedbackList?: SessionFeedback[];
  fullSession?: GameSession;
  questions?: Question[];
}

// WebSocket Event Payloads
export type WSMessageType =
  | 'JOIN_ROOM'
  | 'ROOM_JOINED'
  | 'LEAVE_ROOM'
  | 'UPDATE_SESSION'
  | 'SUBMIT_ANSWER'
  | 'SUBMIT_FEEDBACK'
  | 'SEND_REACTION'
  | 'HOST_ACTION'
  | 'SYNC_STATE'
  | 'ERROR';

export interface WSMessage {
  type: WSMessageType;
  sessionId: string;
  participantId?: string;
  payload?: any;
}

export interface AIQuestionPrompt {
  topic: string;
  count: number;
  difficulty: Difficulty;
  category: Category;
}
