import { Question, Difficulty, QuestionType, MatchingPair, FastestFingerFormat } from '../types';

export interface ParsedQuestionItem {
  id: string;
  blockNumber: number;
  type: QuestionType;
  fastestFingerFormat?: FastestFingerFormat;
  questionText: string;
  options: [string, string, string, string] | [string, string] | string[];
  correctAnswer: number; // 0=A, 1=B, 2=C, 3=D
  rawCorrectLetter: string;
  acceptedAnswers?: string[];
  orderItems?: string[];
  matchingPairs?: MatchingPair[];
  explanation: string;
  category: string;
  difficulty: Difficulty;
  status: 'VALID' | 'NEEDS_REVIEW' | 'INVALID';
  validationMessage?: string;
  suggestedAnswer?: number;
}

export interface ParseResult {
  items: ParsedQuestionItem[];
  validCount: number;
  reviewCount: number;
  invalidCount: number;
  totalDetected: number;
  errors: string[];
}

export function parseBulkQuestions(
  text: string,
  targetType: QuestionType = 'multiple_choice',
  defaultCategory: string = 'General Knowledge',
  defaultDifficulty: Difficulty = 'Medium',
  defaultFastestFingerFormat: FastestFingerFormat = 'true_false'
): ParseResult {
  const errors: string[] = [];
  const items: ParsedQuestionItem[] = [];

  if (!text || text.trim().length === 0) {
    return {
      items: [],
      validCount: 0,
      reviewCount: 0,
      invalidCount: 0,
      totalDetected: 0,
      errors: ['Pasted content is empty.']
    };
  }

  // Split into question blocks using '===' delimiter if present, or double newlines fallback
  let rawBlocks: string[];
  if (text.includes('===')) {
    rawBlocks = text.split(/(?:\r?\n)?===(?:\r?\n)?/).map(b => b.trim()).filter(b => b.length > 0);
  } else {
    rawBlocks = text.split(/(?:\r?\n\s*\r?\n)+/).map(b => b.trim()).filter(b => b.length > 0);
  }

  rawBlocks.forEach((block, idx) => {
    const lines = block.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    const blockNum = idx + 1;

    let questionType: QuestionType = targetType;
    let questionText = '';
    const rawOptionsMap: { [key: string]: string } = { A: '', B: '', C: '', D: '' };
    let parsedCorrectIdx: number | null = null;
    let rawCorrectLetter = '';
    let explanation = '';
    let category = defaultCategory;
    let difficulty = defaultDifficulty;
    let acceptedAnswers: string[] = [];
    let orderItems: string[] = [];
    let matchingPairs: MatchingPair[] = [];

    let currentMode: string | null = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Check for explicit TYPE line
      const typeMatch = line.match(/^(?:TYPE|Question\s*Type)\s*[:=]?\s*(.*)$/i);
      if (typeMatch) {
        const tVal = typeMatch[1].trim().toLowerCase().replace(/[\s\-_]/g, '');
        if (tVal.includes('fast') || tVal.includes('finger')) questionType = 'fastest_fingers';
        else if (tVal.includes('blank') || tVal.includes('fill')) questionType = 'fill_blank';
        else if (tVal.includes('order') || tVal.includes('rank') || tVal.includes('sequence')) questionType = 'ordering';
        else if (tVal.includes('match') || tVal.includes('pair')) questionType = 'matching';
        else questionType = 'multiple_choice';
        continue;
      }

      // Match explicit headers
      const questionMatch = line.match(/^(?:QUESTION|Question|Q)\s*[:=]?\s*(.*)$/i);
      const optMatch = line.match(/^(?:Option\s*)?([A-D1-4])[\.\)\:\-]\s*(.*)$/i) || line.match(/^([A-D])\s*[:=]\s*(.*)$/i);
      const standaloneOpt = line.match(/^([A-D])$/i);
      const ansMatch = line.match(/^(?:ANSWER|Answer|Correct\s*Answer|Correct\s*Option|Correct|Ans)\s*[:=]?\s*(.*)$/i);
      const explMatch = line.match(/^(?:EXPLANATION|Explanation|Note|Desc|Reason|💡)\s*[:=]?\s*(.*)$/i);
      const catMatch = line.match(/^(?:CATEGORY|Category|Topic)\s*[:=]?\s*(.*)$/i);
      const diffMatch = line.match(/^(?:DIFFICULTY|Difficulty|Level)\s*[:=]?\s*(Easy|Medium|Hard)$/i);
      const itemsMatch = line.match(/^(?:ITEMS|Order\s*Items|List)\s*[:=]?\s*(.*)$/i);
      const pairsMatch = line.match(/^(?:PAIRS|Pairs|Matches|Matching\s*Pairs)\s*[:=]?\s*(.*)$/i);

      if (catMatch) {
        currentMode = 'CATEGORY';
        category = catMatch[1].trim() || defaultCategory;
      } else if (diffMatch) {
        currentMode = 'DIFFICULTY';
        const d = diffMatch[1].trim();
        if (d === 'Easy' || d === 'Medium' || d === 'Hard') difficulty = d as Difficulty;
      } else if (explMatch) {
        currentMode = 'EXPLANATION';
        const expContent = explMatch[1] ? explMatch[1].trim() : line.replace(/^💡\s*/, '').trim();
        if (expContent) {
          explanation = explanation ? `${explanation} ${expContent}` : expContent;
        }
      } else if (ansMatch) {
        currentMode = 'ANSWER';
        const ansRaw = ansMatch[1].trim();
        
        if (questionType === 'multiple_choice' || questionType === 'fastest_fingers') {
          const charMatch = ansRaw.match(/^(?:Option\s*)?([A-D1-4])\b/i);
          if (charMatch) {
            const char = charMatch[1].toUpperCase();
            rawCorrectLetter = char;
            if (/^[A-D]$/.test(char)) {
              parsedCorrectIdx = char.charCodeAt(0) - 65;
            } else if (/^[1-4]$/.test(char)) {
              parsedCorrectIdx = parseInt(char, 10) - 1;
            }
          }
        } else if (questionType === 'fill_blank') {
          // Accepted answers separated by commas or pipes
          const split = ansRaw.split(/[,|;]/).map(s => s.trim()).filter(s => s.length > 0);
          if (split.length > 0) {
            acceptedAnswers = split;
          } else if (ansRaw) {
            acceptedAnswers = [ansRaw];
          }
        } else if (questionType === 'ordering') {
          // If answer line provides the correct sequence e.g. "1, 3, 2, 4" or "A, C, B, D" or full text
          if (ansRaw) {
            const split = ansRaw.split(/[,>→|]/).map(s => s.trim()).filter(s => s.length > 0);
            if (split.length > 0) {
              orderItems = split;
            }
          }
        }
      } else if (itemsMatch) {
        currentMode = 'ITEMS';
        const itemsRaw = itemsMatch[1].trim();
        if (itemsRaw) {
          const split = itemsRaw.split(/[,>→|]/).map(s => s.trim()).filter(s => s.length > 0);
          if (split.length > 0) orderItems = split;
        }
      } else if (pairsMatch) {
        currentMode = 'PAIRS';
        const pRaw = pairsMatch[1].trim();
        if (pRaw.includes('->') || pRaw.includes(':') || pRaw.includes('=')) {
          const parts = pRaw.split(/->|:|=/).map(s => s.trim());
          if (parts.length >= 2) {
            matchingPairs.push({ id: `pair_${matchingPairs.length + 1}`, left: parts[0], right: parts[1] });
          }
        }
      } else if (optMatch && (questionType === 'multiple_choice' || questionType === 'fastest_fingers')) {
        let key = optMatch[1].toUpperCase();
        if (/^[1-4]$/.test(key)) {
          key = String.fromCharCode(64 + parseInt(key, 10));
        }
        if (['A', 'B', 'C', 'D'].includes(key)) {
          currentMode = key as 'A' | 'B' | 'C' | 'D';
          rawOptionsMap[key] = optMatch[2].trim();
        }
      } else if (standaloneOpt && (questionType === 'multiple_choice' || questionType === 'fastest_fingers')) {
        const key = standaloneOpt[1].toUpperCase();
        if (['A', 'B', 'C', 'D'].includes(key)) {
          currentMode = key as 'A' | 'B' | 'C' | 'D';
        }
      } else if (questionMatch) {
        currentMode = 'QUESTION';
        const content = questionMatch[1].trim();
        if (content) {
          questionText = questionText ? `${questionText} ${content}` : content;
        }
      } else {
        // Appending text based on current mode
        if (currentMode === 'QUESTION') {
          questionText = questionText ? `${questionText} ${line}` : line;
        } else if (currentMode === 'EXPLANATION') {
          explanation = explanation ? `${explanation} ${line}` : line;
        } else if (currentMode === 'ITEMS') {
          // Line item for ordering
          const cleaned = line.replace(/^\d+[\.\)\-]\s*/, '').trim();
          if (cleaned) orderItems.push(cleaned);
        } else if (currentMode === 'PAIRS') {
          // Line item for matching pair (e.g. "Paris -> France" or "Paris : France")
          if (line.includes('->') || line.includes(':') || line.includes('=')) {
            const parts = line.split(/->|:|=/).map(s => s.trim());
            if (parts.length >= 2) {
              matchingPairs.push({ id: `pair_${matchingPairs.length + 1}`, left: parts[0], right: parts[1] });
            }
          }
        } else if (['A', 'B', 'C', 'D'].includes(currentMode || '')) {
          rawOptionsMap[currentMode!] = rawOptionsMap[currentMode!]
            ? `${rawOptionsMap[currentMode!]} ${line}`
            : line;
        } else if (currentMode === 'ANSWER') {
          if (questionType === 'fill_blank') {
            const split = line.split(/[,|;]/).map(s => s.trim()).filter(s => s.length > 0);
            acceptedAnswers.push(...split);
          } else if (questionType === 'multiple_choice' || questionType === 'fastest_fingers') {
            const char = line.trim().toUpperCase();
            if (/^[A-D]$/.test(char)) {
              rawCorrectLetter = char;
              parsedCorrectIdx = char.charCodeAt(0) - 65;
            } else if (/^[1-4]$/.test(char)) {
              parsedCorrectIdx = parseInt(char, 10) - 1;
              rawCorrectLetter = String.fromCharCode(65 + parsedCorrectIdx);
            }
          }
        } else {
          // Line without explicit header
          if (questionType === 'ordering' && /^\d+[\.\)]\s*/.test(line)) {
            orderItems.push(line.replace(/^\d+[\.\)]\s*/, '').trim());
          } else if (questionType === 'matching' && (line.includes('->') || line.includes(':'))) {
            const parts = line.split(/->|:/).map(s => s.trim());
            if (parts.length >= 2) {
              matchingPairs.push({ id: `pair_${matchingPairs.length + 1}`, left: parts[0], right: parts[1] });
            }
          } else if (!questionText) {
            questionText = line.replace(/^(?:Q(?:uestion)?\s*\d*[\.\:]?|\d+[\.\)]\s*)/i, '').trim();
            currentMode = 'QUESTION';
          } else {
            questionText = `${questionText} ${line}`;
          }
        }
      }
    }

    // Validation according to selected question type
    let status: 'VALID' | 'NEEDS_REVIEW' | 'INVALID' = 'VALID';
    let validationMessage: string | undefined = undefined;
    let suggestedAnswer: number | undefined = undefined;

    if (!questionText || questionText.trim().length === 0) {
      status = 'INVALID';
      validationMessage = `Block #${blockNum} is missing question text.`;
    }

    if (questionType === 'fastest_fingers') {
      // Fastest Fingers: Strict 2-choice requirement (Option A and Option B only)
      const hasC = Boolean(rawOptionsMap['C'] && rawOptionsMap['C'].trim().length > 0);
      const hasD = Boolean(rawOptionsMap['D'] && rawOptionsMap['D'].trim().length > 0);

      if (hasC || hasD) {
        status = 'INVALID';
        validationMessage = `Fastest Fingers questions can only contain two answer options (A and B). Block #${blockNum} contains extra option(s) ${hasC ? 'C ' : ''}${hasD ? 'D' : ''}.`;
      } else {
        const optA = rawOptionsMap['A'] || '';
        const optB = rawOptionsMap['B'] || '';

        if (!optA.trim() || !optB.trim()) {
          status = 'INVALID';
          validationMessage = `Block #${blockNum} must contain both Option A and Option B.`;
        } else if (parsedCorrectIdx === null) {
          status = 'NEEDS_REVIEW';
          suggestedAnswer = 0;
          validationMessage = `Block #${blockNum} is missing ANSWER line (e.g. ANSWER: A). Defaulting to A for review.`;
          parsedCorrectIdx = 0;
          rawCorrectLetter = 'A';
        } else if (parsedCorrectIdx > 1) {
          status = 'INVALID';
          validationMessage = `Block #${blockNum} specifies "${rawCorrectLetter}" as answer, but Fastest Fingers only allows answer A or B.`;
        }
      }

      // Infer or assign format metadata without mutating explicit choices
      let format = defaultFastestFingerFormat;
      const optAUpper = (rawOptionsMap['A'] || '').trim().toUpperCase();
      const optBUpper = (rawOptionsMap['B'] || '').trim().toUpperCase();
      if ((optAUpper === 'TRUE' && optBUpper === 'FALSE') || (optAUpper === 'FALSE' && optBUpper === 'TRUE')) {
        format = 'true_false';
      } else if ((optAUpper === 'YES' && optBUpper === 'NO') || (optAUpper === 'NO' && optBUpper === 'YES')) {
        format = 'yes_no';
      } else if ((optAUpper === 'HIGHER' && optBUpper === 'LOWER') || (optAUpper === 'LOWER' && optBUpper === 'HIGHER')) {
        format = 'higher_lower';
      } else if ((optAUpper === 'MORE' && optBUpper === 'LESS') || (optAUpper === 'LESS' && optBUpper === 'MORE')) {
        format = 'more_less';
      } else if ((optAUpper === 'BEFORE' && optBUpper === 'AFTER') || (optAUpper === 'AFTER' && optBUpper === 'BEFORE')) {
        format = 'before_after';
      } else if ((optAUpper === 'AGREE' && optBUpper === 'DISAGREE') || (optAUpper === 'DISAGREE' && optBUpper === 'AGREE')) {
        format = 'agree_disagree';
      }

      items.push({
        id: `parsed_${blockNum}_${Date.now()}`,
        blockNumber: blockNum,
        type: 'fastest_fingers',
        fastestFingerFormat: format,
        questionText,
        options: [rawOptionsMap['A'] || '', rawOptionsMap['B'] || ''],
        correctAnswer: parsedCorrectIdx !== null && parsedCorrectIdx <= 1 ? parsedCorrectIdx : 0,
        rawCorrectLetter: rawCorrectLetter || 'A',
        explanation,
        category,
        difficulty,
        status,
        validationMessage,
        suggestedAnswer
      });
    } else if (questionType === 'multiple_choice') {
      const finalOptions: [string, string, string, string] = [
        rawOptionsMap['A'] || '',
        rawOptionsMap['B'] || '',
        rawOptionsMap['C'] || '',
        rawOptionsMap['D'] || ''
      ];

      const emptyOpts = finalOptions.filter(o => o.trim().length === 0).length;
      if (emptyOpts > 0 && status !== 'INVALID') {
        status = 'INVALID';
        validationMessage = `Block #${blockNum} must contain all 4 choices (A, B, C, D). Missing ${emptyOpts} option(s).`;
      }

      if (parsedCorrectIdx === null && status !== 'INVALID') {
        status = 'NEEDS_REVIEW';
        suggestedAnswer = 0;
        validationMessage = `Block #${blockNum} is missing ANSWER line (e.g. ANSWER: C). Defaulting to A for review.`;
        parsedCorrectIdx = 0;
        rawCorrectLetter = 'A';
      }

      items.push({
        id: `parsed_${blockNum}_${Date.now()}`,
        blockNumber: blockNum,
        type: 'multiple_choice',
        questionText,
        options: finalOptions,
        correctAnswer: parsedCorrectIdx !== null ? parsedCorrectIdx : 0,
        rawCorrectLetter: rawCorrectLetter || 'A',
        explanation,
        category,
        difficulty,
        status,
        validationMessage,
        suggestedAnswer
      });
    } else if (questionType === 'fill_blank') {
      if (acceptedAnswers.length === 0 && status !== 'INVALID') {
        status = 'NEEDS_REVIEW';
        validationMessage = `Block #${blockNum} is missing ANSWER line with accepted answers.`;
      }

      items.push({
        id: `parsed_${blockNum}_${Date.now()}`,
        blockNumber: blockNum,
        type: 'fill_blank',
        questionText,
        options: [],
        correctAnswer: 0,
        rawCorrectLetter: '',
        acceptedAnswers,
        explanation,
        category,
        difficulty,
        status,
        validationMessage
      });
    } else if (questionType === 'ordering') {
      if (orderItems.length < 2 && status !== 'INVALID') {
        status = 'INVALID';
        validationMessage = `Block #${blockNum} must contain at least 2 chronological / ranked items to order.`;
      }

      items.push({
        id: `parsed_${blockNum}_${Date.now()}`,
        blockNumber: blockNum,
        type: 'ordering',
        questionText,
        options: orderItems,
        orderItems,
        correctAnswer: 0,
        rawCorrectLetter: '',
        explanation,
        category,
        difficulty,
        status,
        validationMessage
      });
    } else if (questionType === 'matching') {
      if (matchingPairs.length < 2 && status !== 'INVALID') {
        status = 'INVALID';
        validationMessage = `Block #${blockNum} must contain at least 2 matching pairs (e.g. Left -> Right).`;
      }

      items.push({
        id: `parsed_${blockNum}_${Date.now()}`,
        blockNumber: blockNum,
        type: 'matching',
        questionText,
        options: [],
        matchingPairs,
        correctAnswer: 0,
        rawCorrectLetter: '',
        explanation,
        category,
        difficulty,
        status,
        validationMessage
      });
    }
  });

  const validCount = items.filter(i => i.status === 'VALID').length;
  const reviewCount = items.filter(i => i.status === 'NEEDS_REVIEW').length;
  const invalidCount = items.filter(i => i.status === 'INVALID').length;

  return {
    items,
    validCount,
    reviewCount,
    invalidCount,
    totalDetected: items.length,
    errors
  };
}
