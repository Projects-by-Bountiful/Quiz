import { supabase, getSupabase, isSupabaseConfigured } from '../lib/supabase';

export { supabase, getSupabase, isSupabaseConfigured };
export default supabase;
