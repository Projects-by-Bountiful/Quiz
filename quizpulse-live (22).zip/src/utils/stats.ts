import { Participant, GameSession, ParticipantAnswer } from '../types';

export interface CalculatedParticipantStats {
  score: number;
  correctAnswers: number;
  incorrectAnswers: number;
  questionsAnswered: number;
  questionsSkipped: number;
  accuracy: number; // 0 - 100 percentage
  averageResponseTime: number; // seconds
  fastestResponse: number; // seconds
  longestCorrectStreak: number;
  finalRank: number;
  rankDisplay: string;
}

export function calculateParticipantStats(
  participant: Participant,
  totalQuestions: number,
  allParticipantsSorted: Participant[] = []
): CalculatedParticipantStats {
  const answersObj = participant.answers || {};
  const ansList = Object.values(answersObj) as ParticipantAnswer[];

  const correctAnswers = participant.correctCount || ansList.filter(a => a.isCorrect).length;
  
  // Questions Answered = Correct Answers + Incorrect Answers
  let questionsAnswered = ansList.length;
  if (questionsAnswered === 0 && participant.correctCount) {
    questionsAnswered = participant.correctCount;
  }

  const incorrectAnswers = Math.max(0, questionsAnswered - correctAnswers);
  const questionsSkipped = Math.max(0, totalQuestions - questionsAnswered);

  // Accuracy = Correct Answers ÷ Questions Answered
  const accuracy = questionsAnswered > 0 ? Math.round((correctAnswers / questionsAnswered) * 100) : 0;

  // Average Response Time = Sum of Response Times ÷ Questions Answered
  const totalResponseTime = participant.totalResponseTime || ansList.reduce((sum, a) => sum + (a.timeTakenSec || 0), 0);
  const averageResponseTime = questionsAnswered > 0 ? Number((totalResponseTime / questionsAnswered).toFixed(2)) : 0;

  // Fastest Response
  let fastestResponse = participant.fastestResponseSec !== undefined ? participant.fastestResponseSec : 0;
  if (!fastestResponse && ansList.length > 0) {
    const times = ansList.map(a => a.timeTakenSec).filter(t => t > 0);
    if (times.length > 0) {
      fastestResponse = Math.min(...times);
    }
  }
  fastestResponse = Number(fastestResponse.toFixed(2));

  // Longest Correct Streak
  const longestCorrectStreak = participant.maxStreak || participant.streak || 0;

  // Final Rank
  const listToSort = allParticipantsSorted.length > 0 ? allParticipantsSorted : [participant];
  const sorted = [...listToSort].sort((a, b) => (b.score || 0) - (a.score || 0));
  let rankIndex = sorted.findIndex(p => p.id === participant.id || p.name === participant.name);
  if (rankIndex === -1) rankIndex = 0;

  const finalRank = rankIndex + 1;

  return {
    score: participant.score || 0,
    correctAnswers,
    incorrectAnswers,
    questionsAnswered,
    questionsSkipped,
    accuracy,
    averageResponseTime,
    fastestResponse,
    longestCorrectStreak,
    finalRank,
    rankDisplay: `#${finalRank}`
  };
}

export interface CalculatedSessionSummary {
  totalParticipants: number;
  totalQuestions: number;
  averageScore: number;
  averageAccuracy: number;
  averageResponseTime: number;
  highestScore: number;
  fastestResponse: number;
  sessionDurationSec: number;
  winnerName: string;
  winnerScore: number;
}

export function calculateSessionSummary(
  sessionOrParticipants: GameSession | Participant[],
  totalQuestionsOverride?: number
): CalculatedSessionSummary {
  let participants: Participant[] = [];
  let totalQuestions = 10;

  if (Array.isArray(sessionOrParticipants)) {
    participants = sessionOrParticipants;
    totalQuestions = totalQuestionsOverride || 10;
  } else if (sessionOrParticipants && typeof sessionOrParticipants === 'object') {
    participants = Object.values(sessionOrParticipants.participants || {});
    totalQuestions = totalQuestionsOverride || sessionOrParticipants.questions?.length || 10;
  }

  const sorted = [...participants].sort((a, b) => (b.score || 0) - (a.score || 0));
  const totalParticipants = sorted.length;

  if (totalParticipants === 0) {
    return {
      totalParticipants: 0,
      totalQuestions,
      averageScore: 0,
      averageAccuracy: 0,
      averageResponseTime: 0,
      highestScore: 0,
      fastestResponse: 0,
      sessionDurationSec: totalQuestions * 20,
      winnerName: 'N/A',
      winnerScore: 0
    };
  }

  let totalScoreSum = 0;
  let totalAccuracySum = 0;
  let totalAvgTimeSum = 0;
  let fastestRespMin = Infinity;

  sorted.forEach(p => {
    const stats = calculateParticipantStats(p, totalQuestions, sorted);
    totalScoreSum += stats.score;
    totalAccuracySum += stats.accuracy;
    totalAvgTimeSum += stats.averageResponseTime;
    if (stats.fastestResponse > 0 && stats.fastestResponse < fastestRespMin) {
      fastestRespMin = stats.fastestResponse;
    }
  });

  return {
    totalParticipants,
    totalQuestions,
    averageScore: Math.round(totalScoreSum / totalParticipants),
    averageAccuracy: Math.round(totalAccuracySum / totalParticipants),
    averageResponseTime: Number((totalAvgTimeSum / totalParticipants).toFixed(2)),
    highestScore: sorted[0]?.score || 0,
    fastestResponse: fastestRespMin === Infinity ? 0 : fastestRespMin,
    sessionDurationSec: totalQuestions * 20,
    winnerName: sorted[0]?.name || 'N/A',
    winnerScore: sorted[0]?.score || 0
  };
}
