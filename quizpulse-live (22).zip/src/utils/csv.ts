import { Question, Participant, Difficulty } from '../types';
import { calculateParticipantStats } from './stats';

export function downloadCSV(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportResultsToCSV(sessionTitle: string, participants: Participant[], totalQuestions: number) {
  const headers = ['Rank', 'Participant Name', 'Total Score', 'Correct Answers', 'Questions Answered', 'Questions Skipped', 'Accuracy (%)', 'Avg Response Time (s)', 'Fastest Response (s)', 'Streak'];
  const sorted = [...participants].sort((a, b) => b.score - a.score);

  const rows = sorted.map((p) => {
    const stats = calculateParticipantStats(p, totalQuestions, sorted);
    return [
      stats.finalRank,
      `"${p.name.replace(/"/g, '""')}"`,
      stats.score,
      `${stats.correctAnswers}/${totalQuestions}`,
      stats.questionsAnswered,
      stats.questionsSkipped,
      `${stats.accuracy}%`,
      `${stats.averageResponseTime}s`,
      `${stats.fastestResponse}s`,
      stats.longestCorrectStreak
    ];
  });

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const cleanTitle = sessionTitle.toLowerCase().replace(/[^a-z0-9]/g, '_');
  downloadCSV(`quiz_results_${cleanTitle}.csv`, csvContent);
}

export interface ExportFilterOptions {
  category?: string;
  difficulty?: Difficulty | 'All';
  selectedIds?: string[];
  filenamePrefix?: string;
}

export function exportQuestionsToCSV(questions: Question[], options?: ExportFilterOptions) {
  let filtered = [...questions];

  if (options?.category && options.category !== 'All') {
    filtered = filtered.filter(q => q.category.toLowerCase() === options.category!.toLowerCase());
  }

  if (options?.difficulty && options.difficulty !== 'All') {
    filtered = filtered.filter(q => q.difficulty === options.difficulty);
  }

  if (options?.selectedIds && options.selectedIds.length > 0) {
    filtered = filtered.filter(q => options.selectedIds!.includes(q.id));
  }

  const headers = ['Category', 'Difficulty', 'Question', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Answer', 'Explanation', 'Tags'];
  
  const rows = filtered.map(q => {
    const letterAnswer = ['A', 'B', 'C', 'D'][q.correctAnswer] || 'A';
    return [
      `"${q.category.replace(/"/g, '""')}"`,
      q.difficulty,
      `"${q.question.replace(/"/g, '""')}"`,
      `"${q.options[0].replace(/"/g, '""')}"`,
      `"${q.options[1].replace(/"/g, '""')}"`,
      `"${q.options[2].replace(/"/g, '""')}"`,
      `"${q.options[3].replace(/"/g, '""')}"`,
      `"${letterAnswer}"`,
      `"${(q.explanation || '').replace(/"/g, '""')}"`,
      `"${q.tags.join(';')}"`
    ];
  });

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const prefix = options?.filenamePrefix || 'question_bank';
  downloadCSV(`${prefix}_export_${Date.now()}.csv`, csvContent);
}

export interface CSVRowItem {
  rowNumber: number;
  question?: Question;
  status: 'VALID' | 'INVALID' | 'DUPLICATE';
  errorMessage?: string;
  rawCategory?: string;
  rawDifficulty?: string;
  rawQuestion?: string;
  rawOptions?: [string, string, string, string];
  rawAnswer?: string;
}

export interface CSVImportReport {
  items: CSVRowItem[];
  questions: Question[];
  errors: string[];
  totalRows: number;
  importedCount: number;
  failedCount: number;
  skippedDuplicatesCount: number;
}

export function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

export function parseQuestionsCSV(
  csvText: string,
  existingQuestions: Question[] = [],
  preventDuplicates: boolean = true
): CSVImportReport {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length === 0) {
    return {
      items: [],
      questions: [],
      errors: ['CSV file is empty.'],
      totalRows: 0,
      importedCount: 0,
      failedCount: 0,
      skippedDuplicatesCount: 0
    };
  }

  const items: CSVRowItem[] = [];
  const questions: Question[] = [];
  const errors: string[] = [];
  let skippedDuplicatesCount = 0;
  let failedCount = 0;

  const existingTextSet = new Set(existingQuestions.map(q => q.question.toLowerCase().trim()));

  // Check if line 0 is header row
  const firstLineCols = parseCSVLine(lines[0]);
  const isHeader = firstLineCols.some(c => 
    /^(category|difficulty|question|option|correct|answer|explanation|tags|id)$/i.test(c.replace(/[^a-z0-9]/gi, ''))
  );

  const startIdx = isHeader ? 1 : 0;
  const totalRows = lines.length - startIdx;

  for (let i = startIdx; i < lines.length; i++) {
    const rowNum = i + 1;
    const line = lines[i];
    const cols = parseCSVLine(line);

    if (cols.length < 3) {
      const msg = `Row ${rowNum}: Insufficient columns in CSV line.`;
      errors.push(msg);
      failedCount++;
      items.push({ rowNumber: rowNum, status: 'INVALID', errorMessage: msg });
      continue;
    }

    let colOffset = 0;
    if (cols.length >= 11) {
      colOffset = 1; // legacy format with ID in col 0
    }

    const category = cols[0 + colOffset] || 'General Knowledge';
    const difficultyStr = cols[1 + colOffset] || 'Medium';
    const questionText = cols[2 + colOffset] || '';
    const optA = cols[3 + colOffset] || '';
    const optB = cols[4 + colOffset] || '';
    const optC = cols[5 + colOffset] || '';
    const optD = cols[6 + colOffset] || '';
    const rawAnswer = cols[7 + colOffset] || 'A';
    const explanation = cols[8 + colOffset] || '';
    const rawTags = cols[9 + colOffset] || '';

    const rawOptionsTuple: [string, string, string, string] = [optA, optB, optC, optD];

    if (!questionText.trim()) {
      const msg = `Row ${rowNum}: Question text is missing.`;
      errors.push(msg);
      failedCount++;
      items.push({
        rowNumber: rowNum,
        status: 'INVALID',
        errorMessage: msg,
        rawCategory: category,
        rawDifficulty: difficultyStr,
        rawQuestion: questionText,
        rawOptions: rawOptionsTuple,
        rawAnswer
      });
      continue;
    }

    if (!optA.trim() || !optB.trim() || !optC.trim() || !optD.trim()) {
      const msg = `Row ${rowNum}: One or more required options (A, B, C, D) are empty.`;
      errors.push(msg);
      failedCount++;
      items.push({
        rowNumber: rowNum,
        status: 'INVALID',
        errorMessage: msg,
        rawCategory: category,
        rawDifficulty: difficultyStr,
        rawQuestion: questionText,
        rawOptions: rawOptionsTuple,
        rawAnswer
      });
      continue;
    }

    if (preventDuplicates && existingTextSet.has(questionText.toLowerCase().trim())) {
      const msg = `Row ${rowNum}: Duplicate question skipped.`;
      skippedDuplicatesCount++;
      items.push({
        rowNumber: rowNum,
        status: 'DUPLICATE',
        errorMessage: msg,
        rawCategory: category,
        rawDifficulty: difficultyStr,
        rawQuestion: questionText,
        rawOptions: rawOptionsTuple,
        rawAnswer
      });
      continue;
    }

    // Convert Answer letter ('A','B','C','D' or 0-3) to index
    let correctAnswerIdx: 0 | 1 | 2 | 3 = 0;
    const upperAns = rawAnswer.trim().toUpperCase();
    if (['A', '0', '1'].includes(upperAns)) {
      if (upperAns === '1') correctAnswerIdx = 0;
      else if (upperAns === '0') correctAnswerIdx = 0;
      else correctAnswerIdx = 0;
    } else if (['B', '2'].includes(upperAns)) {
      correctAnswerIdx = 1;
    } else if (['C', '3'].includes(upperAns)) {
      correctAnswerIdx = 2;
    } else if (['D', '4'].includes(upperAns)) {
      correctAnswerIdx = 3;
    }

    const difficulty: Difficulty = ['Easy', 'Medium', 'Hard'].includes(difficultyStr) ? (difficultyStr as Difficulty) : 'Medium';

    const newQ: Question = {
      id: `csv_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 6)}`,
      category: category || 'General Knowledge',
      difficulty,
      question: questionText,
      options: [optA, optB, optC, optD],
      correctAnswer: correctAnswerIdx,
      explanation,
      tags: rawTags ? rawTags.split(';') : [category, difficulty],
      estimatedTimeSec: 20,
      status: 'active'
    };

    questions.push(newQ);
    existingTextSet.add(questionText.toLowerCase().trim());

    items.push({
      rowNumber: rowNum,
      question: newQ,
      status: 'VALID',
      rawCategory: category,
      rawDifficulty: difficulty,
      rawQuestion: questionText,
      rawOptions: rawOptionsTuple,
      rawAnswer
    });
  }

  return {
    items,
    questions,
    errors,
    totalRows,
    importedCount: questions.length,
    failedCount,
    skippedDuplicatesCount
  };
}
