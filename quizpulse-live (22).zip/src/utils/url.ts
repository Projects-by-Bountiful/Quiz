export const DEFAULT_APP_URL = "https://thequizpulse.netlify.app";

/**
 * Returns the configured production application base URL.
 * Prefers VITE_APP_URL environment variable if present.
 * If running on Netlify or a custom production domain, uses window.location.origin.
 * Fallbacks to "https://thequizpulse.netlify.app" for localhost, preview, and AI Studio environments
 * to ensure generated QR codes and share links always use production URLs.
 */
export function getAppUrl(): string {
  const metaEnv = (import.meta as any).env;
  if (metaEnv && metaEnv.VITE_APP_URL) {
    return metaEnv.VITE_APP_URL.replace(/\/$/, '');
  }
  if (typeof window !== 'undefined') {
    const origin = window.location.origin;
    if (
      origin.includes('netlify.app') ||
      (!origin.includes('localhost') && !origin.includes('127.0.0.1') && !origin.includes('run.app'))
    ) {
      return origin;
    }
  }
  return DEFAULT_APP_URL;
}

/**
 * Generates the clean participant join URL for QR code and copy link.
 * Example: https://thequizpulse.netlify.app/join/A7KX92
 */
export function getParticipantJoinUrl(roomId: string): string {
  return `${getAppUrl()}/join/${roomId}`;
}

/**
 * Generates the host URL for room management.
 * Example: https://thequizpulse.netlify.app/host/A7KX92
 */
export function getHostUrl(roomId: string): string {
  return `${getAppUrl()}/host/${roomId}`;
}
