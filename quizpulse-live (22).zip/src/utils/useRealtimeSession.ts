import { useState, useEffect, useRef, useCallback } from 'react';
import { GameSession, WSMessage, Participant, ParticipantAnswer, Question } from '../types';
import { calculateSessionSummary } from './stats';
import { evaluateAnswer, scoreAnswer } from './questionEngine';
import { getSupabase, isSupabaseConfigured } from '../lib/supabase';
import {
  subscribeToSupabaseRoom,
  fetchQuizRoomFromSupabase,
  addParticipantToSupabase,
  recordAnswerInSupabase,
  saveGameResultToSupabase,
  saveFeedbackToSupabase
} from '../lib/supabaseService';

// Storage keys for session persistence & recovery
export const getParticipantStorageKey = (roomId: string) => `quizpulse_participant_${roomId.toUpperCase()}`;
export const ACTIVE_ROOM_KEY = 'quizpulse_active_room';
export const ACTIVE_ROLE_KEY = 'quizpulse_active_role';

/**
 * Deterministically merges incoming session updates without destroying established
 * questionStartTime, answers, or local participant state.
 */
function mergeSessionState(prev: GameSession | null, updated: GameSession): GameSession {
  if (!prev) return updated;

  const sameQuestion = prev.currentQuestionIndex === updated.currentQuestionIndex && prev.status === updated.status;
  const updatedSettingStartTime = updated.settings?.questionStartTime;

  // Authoritative questionStartTime preservation
  let questionStartTime = updated.questionStartTime;
  if (sameQuestion && prev.questionStartTime) {
    questionStartTime = prev.questionStartTime;
  } else if (updatedSettingStartTime) {
    questionStartTime = updatedSettingStartTime;
  } else if (updated.questionStartTime) {
    questionStartTime = updated.questionStartTime;
  } else if (prev.questionStartTime) {
    questionStartTime = prev.questionStartTime;
  }

  // Preserve and merge participants without dropping answers
  const mergedParticipants = { ...prev.participants, ...updated.participants };
  Object.keys(mergedParticipants).forEach(pid => {
    const prevP = prev.participants[pid];
    const updatedP = updated.participants[pid];
    if (prevP && updatedP) {
      mergedParticipants[pid] = {
        ...updatedP,
        score: Math.max(prevP.score || 0, updatedP.score || 0),
        streak: updatedP.streak !== undefined ? updatedP.streak : (prevP.streak || 0),
        answers: { ...(prevP.answers || {}), ...(updatedP.answers || {}) }
      };
    }
  });

  // Preserve preloaded questions
  const questions = (updated.questions && updated.questions.length > 0)
    ? updated.questions
    : (prev.questions || []);

  return {
    ...updated,
    questions,
    questionStartTime: questionStartTime || updated.questionStartTime || prev.questionStartTime,
    participants: mergedParticipants
  };
}

export function useRealtimeSession(initialSessionId?: string, initialParticipantId?: string, isHostRole: boolean = false) {
  const [session, setSession] = useState<GameSession | null>(null);
  const [sessionId, setSessionId] = useState<string | undefined>(initialSessionId);
  const [participantId, setParticipantId] = useState<string | undefined>(initialParticipantId);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'reconnecting' | 'disconnected'>('connected');
  const [showBackOnlineToast, setShowBackOnlineToast] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [reactions, setReactions] = useState<Array<{ id: string; emoji: string; senderName: string }>>([]);

  // High-performance clock offset calculation (Host Time vs Local Device Time)
  const clockOffsetRef = useRef<number>(0);

  // References to prevent stale closures and duplicate operations
  const socketRef = useRef<WebSocket | null>(null);
  const supabaseChannelRef = useRef<any>(null);
  const sessionRef = useRef<GameSession | null>(null);
  const isHostRef = useRef<boolean>(isHostRole);
  const answeredQuestionsRef = useRef<Set<string>>(new Set());
  const cdcDebounceTimeoutRef = useRef<any>(null);

  useEffect(() => {
    isHostRef.current = isHostRole;
  }, [isHostRole]);

  useEffect(() => {
    sessionRef.current = session;
  }, [session]);

  // Network online / offline recovery
  useEffect(() => {
    const handleOffline = () => {
      console.warn('[Realtime] Network Offline Detected');
      setConnectionStatus('reconnecting');
    };

    const handleOnline = async () => {
      console.log('[Realtime] Network Restored. Reconnecting & Resyncing...');
      setConnectionStatus('reconnecting');
      if (sessionId) {
        const cleanId = sessionId.toUpperCase();
        const room = await fetchQuizRoomFromSupabase(cleanId);
        if (room) {
          console.log('[Realtime] Resynced Room State', { roomId: cleanId, status: room.status });
          setSession(prev => mergeSessionState(prev, room));
        }
      }
      setConnectionStatus('connected');
      setShowBackOnlineToast(true);
      setTimeout(() => setShowBackOnlineToast(false), 3000);
    };

    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);

    return () => {
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, [sessionId]);

  // Broadcast Action Sender with structured logging
  const broadcastAction = useCallback((action: string, updatedSessionState?: GameSession | null, payloadData?: any) => {
    const cleanSessionId = (sessionId || updatedSessionState?.id || sessionRef.current?.id || '').toUpperCase();
    const now = Date.now();

    console.log(`[Realtime] Action Sent: ${action}`, {
      roomId: cleanSessionId,
      action,
      timestamp: now,
      sender: isHostRef.current ? 'HOST' : 'PARTICIPANT',
      questionIndex: updatedSessionState?.currentQuestionIndex ?? sessionRef.current?.currentQuestionIndex
    });

    if (supabaseChannelRef.current) {
      try {
        supabaseChannelRef.current.send({
          type: 'broadcast',
          event: 'game_event',
          payload: {
            action,
            session: updatedSessionState || undefined,
            payloadData,
            timestamp: now,
            senderId: isHostRef.current ? 'HOST' : participantId
          }
        });
      } catch (err) {
        console.warn('Realtime broadcast error:', err);
      }
    }
  }, [sessionId, participantId]);

  // Setup Single Shared Realtime Channel Subscription
  useEffect(() => {
    if (!sessionId || !isSupabaseConfigured()) return;
    const cleanSessionId = sessionId.toUpperCase();

    // 1. Initial Room Fetch
    fetchQuizRoomFromSupabase(cleanSessionId).then(room => {
      if (room) {
        console.log('[Realtime] Connected', { roomId: cleanSessionId, status: room.status });
        setSession(prev => mergeSessionState(prev, room));
        setIsConnected(true);
      }
    });

    // 2. Debounced CDC Handler to protect Supabase under 100 participants
    const handleDebouncedCDC = () => {
      if (cdcDebounceTimeoutRef.current) {
        clearTimeout(cdcDebounceTimeoutRef.current);
      }
      cdcDebounceTimeoutRef.current = setTimeout(async () => {
        const updated = await fetchQuizRoomFromSupabase(cleanSessionId);
        if (updated) {
          setSession(prev => mergeSessionState(prev, updated));
        }
      }, 350);
    };

    // 3. Realtime Broadcast Receiver (<150ms latency)
    const handleBroadcastEvent = (broadcastData: any) => {
      const payload = broadcastData.payload;
      if (!payload) return;

      const { action, session: broadcastSession, payloadData, timestamp } = payload;

      // Calculate clock offset from authoritative host timestamp
      if (timestamp && !isHostRef.current) {
        clockOffsetRef.current = timestamp - Date.now();
      }

      console.log(`[Realtime] Action Received: ${action}`, {
        roomId: cleanSessionId,
        action,
        timestamp: Date.now(),
        questionIndex: broadcastSession?.currentQuestionIndex ?? sessionRef.current?.currentQuestionIndex
      });

      if (action === 'START_GAME' || action === 'START_QUIZ' || action === 'NEXT_QUESTION') {
        console.log('[Realtime] Question Started', {
          roomId: cleanSessionId,
          questionIndex: broadcastSession?.currentQuestionIndex ?? payloadData?.questionIndex,
          questionStartTime: broadcastSession?.questionStartTime ?? payloadData?.questionStartTime,
          duration: broadcastSession?.settings?.timerDurationSec ?? payloadData?.timerDuration
        });
      } else if (action === 'REVEAL_ANSWER' || action === 'SKIP_QUESTION') {
        console.log('[Realtime] Reveal Triggered', {
          roomId: cleanSessionId,
          questionIndex: broadcastSession?.currentQuestionIndex
        });
      } else if (action === 'END_GAME' || action === 'END_QUIZ') {
        console.log('[Realtime] Game Completed', { roomId: cleanSessionId });
      }

      // Handle lightweight participant answer event without replacing whole session
      if (action === 'PARTICIPANT_ANSWERED' && payloadData) {
        const { participantId: pId, participantName, questionId } = payloadData;
        setSession(prev => {
          if (!prev) return null;
          const currentP = prev.participants[pId];
          if (!currentP) return prev;

          // Record placeholder answer mark for host view counter
          const updatedP = {
            ...currentP,
            answers: {
              ...(currentP.answers || {}),
              [questionId]: currentP.answers[questionId] || {
                questionId,
                type: 'multiple_choice',
                isCorrect: false,
                scoreGained: 0,
                speedBonus: 0,
                timeTakenSec: 0,
                timestamp: Date.now()
              }
            }
          };

          return {
            ...prev,
            participants: {
              ...prev.participants,
              [pId]: updatedP
            }
          };
        });
        return;
      }

      if (broadcastSession) {
        setSession(prev => {
          if (!prev) return broadcastSession;

          const activeIndex = prev.currentQuestionIndex ?? 0;
          const targetIndex = broadcastSession.currentQuestionIndex ?? 0;

          // Preserve questionStartTime if question has not changed
          if ((action === 'START_GAME' || action === 'START_QUIZ' || action === 'NEXT_QUESTION') &&
              prev.status === 'QUESTION' &&
              activeIndex === targetIndex) {
            return mergeSessionState(prev, {
              ...broadcastSession,
              questionStartTime: prev.questionStartTime
            });
          }

          return mergeSessionState(prev, broadcastSession);
        });
      }
    };

    const channel = subscribeToSupabaseRoom(
      cleanSessionId,
      handleDebouncedCDC,
      handleDebouncedCDC,
      handleBroadcastEvent
    );

    supabaseChannelRef.current = channel;
    console.log('[Realtime] Subscribed', { roomId: cleanSessionId });

    return () => {
      if (cdcDebounceTimeoutRef.current) {
        clearTimeout(cdcDebounceTimeoutRef.current);
      }
      if (supabaseChannelRef.current) {
        supabaseChannelRef.current.unsubscribe();
        supabaseChannelRef.current = null;
      }
    };
  }, [sessionId]);

  // Connect & Join with Idempotency
  const connect = useCallback(async (
    targetSessionId: string,
    pName?: string,
    isHost: boolean = false,
    initialSessionData?: GameSession,
    avatarOverride?: string
  ) => {
    const cleanId = targetSessionId.toUpperCase();
    setSessionId(cleanId);
    isHostRef.current = isHost;

    let room: GameSession | null = null;
    if (initialSessionData) {
      room = initialSessionData;
      setSession(initialSessionData);
    } else {
      room = await fetchQuizRoomFromSupabase(cleanId);
      if (room) setSession(room);
    }

    // Check Max Participants
    if (!isHost && room) {
      const maxAllowed = room.settings?.maxParticipants || 100;
      const currentCount = Object.keys(room.participants || {}).length;
      const alreadyInRoom = pName && Object.values(room.participants || {}).some(
        (p: any) => p.name?.toLowerCase() === pName.trim().toLowerCase()
      );

      if (!alreadyInRoom && currentCount >= maxAllowed) {
        setErrorMessage('This quiz room has reached its maximum capacity.');
        return;
      }
    }

    let currentPId = participantId;
    const storageKey = getParticipantStorageKey(cleanId);
    let savedIdentity: { participantId: string; name: string; avatar?: string } | null = null;
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) savedIdentity = JSON.parse(raw);
    } catch (e) {}

    if (!isHost) {
      const effectiveName = pName || savedIdentity?.name || 'Player';
      const effectiveAvatar = avatarOverride || savedIdentity?.avatar || '⚡';

      let existingPInRoom: Participant | undefined;
      if (room?.participants) {
        if (savedIdentity?.participantId && room.participants[savedIdentity.participantId]) {
          existingPInRoom = room.participants[savedIdentity.participantId];
        } else if (effectiveName) {
          existingPInRoom = Object.values(room.participants).find(
            p => p.name.trim().toLowerCase() === effectiveName.trim().toLowerCase()
          );
        }
      }

      if (existingPInRoom) {
        currentPId = existingPInRoom.id;
        setParticipantId(currentPId);
      } else {
        currentPId = savedIdentity?.participantId || participantId || `p_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        setParticipantId(currentPId);

        const newParticipant: Participant = {
          id: currentPId,
          name: effectiveName,
          avatar: effectiveAvatar,
          score: 0,
          streak: 0,
          correctCount: 0,
          totalResponseTime: 0,
          answers: {},
          joinedAt: Date.now(),
          isOnline: true
        };

        if (isSupabaseConfigured()) {
          const added = await addParticipantToSupabase(cleanId, newParticipant);
          if (added) {
            const updatedRoom = await fetchQuizRoomFromSupabase(cleanId);
            if (updatedRoom) {
              setSession(updatedRoom);
              broadcastAction('PARTICIPANT_JOINED', updatedRoom, { participantId: currentPId, name: effectiveName });
            }
          }
        }
      }

      try {
        localStorage.setItem(storageKey, JSON.stringify({
          participantId: currentPId,
          name: effectiveName,
          avatar: effectiveAvatar
        }));
        localStorage.setItem(ACTIVE_ROOM_KEY, cleanId);
        localStorage.setItem(ACTIVE_ROLE_KEY, 'participant');
      } catch (e) {}
    } else {
      try {
        localStorage.setItem(ACTIVE_ROOM_KEY, cleanId);
        localStorage.setItem(ACTIVE_ROLE_KEY, 'host');
      } catch (e) {}
    }

    if (isSupabaseConfigured()) {
      setIsConnected(true);
    }
  }, [participantId, broadcastAction]);

  // Idempotent Answer Submission
  const submitAnswer = useCallback(async (selectedOption: any, timeTakenSec: number) => {
    if (!sessionId || !participantId) return;

    const currentSession = sessionRef.current;
    if (!currentSession) return;

    const currentQIndex = currentSession.currentQuestionIndex || 0;
    const currentQ = currentSession.questions?.[currentQIndex];
    if (!currentQ) return;

    // Idempotency check: prevent duplicate submits per question
    const submissionKey = `${sessionId}_${participantId}_${currentQ.id}`;
    if (answeredQuestionsRef.current.has(submissionKey) && !currentSession.settings?.allowAnswerChange) {
      console.log('[Realtime] Duplicate Answer Submission Prevented', { submissionKey });
      return;
    }
    answeredQuestionsRef.current.add(submissionKey);

    console.log('[Realtime] Answer Submitted', {
      roomId: sessionId,
      participantId,
      questionIndex: currentQIndex,
      questionId: currentQ.id,
      selectedOption,
      timeTakenSec
    });

    const existingP = currentSession.participants?.[participantId];
    if (!existingP) return;

    // Deterministic Evaluation & Scoring
    const evaluation = evaluateAnswer(currentQ, selectedOption);
    const timerDuration = currentSession.settings?.timerDurationSec || currentQ.estimatedTimeSec || 20;
    const enableSpeed = currentSession.settings?.enableBonusSpeedPoints !== false;
    const { pointsAwarded, speedBonus } = scoreAnswer(
      currentQ,
      evaluation,
      timeTakenSec,
      timerDuration,
      enableSpeed
    );

    const qType = currentQ.type || 'multiple_choice';
    const newAnswer: ParticipantAnswer = {
      questionId: currentQ.id,
      type: qType,
      selectedOption: (qType === 'multiple_choice' || qType === 'fastest_fingers') && typeof selectedOption === 'number' ? selectedOption : undefined,
      textAnswer: qType === 'fill_blank' && typeof selectedOption === 'string' ? selectedOption : undefined,
      orderAnswer: qType === 'ordering' && Array.isArray(selectedOption) ? selectedOption : undefined,
      matchingAnswer: qType === 'matching' && typeof selectedOption === 'object' ? selectedOption : undefined,
      rawAnswer: selectedOption,
      timeTakenSec,
      isCorrect: evaluation.isCorrect,
      scoreGained: pointsAwarded,
      speedBonus,
      timestamp: Date.now()
    };

    const newAnswers = { ...(existingP.answers || {}), [currentQ.id]: newAnswer };
    const ansList: ParticipantAnswer[] = Object.values(newAnswers);
    const newCorrectCount = ansList.filter(a => a.isCorrect).length;
    const newTotalResponseTime = ansList.reduce((sum, a) => sum + (a.timeTakenSec || 0), 0);
    let fastestResp = ansList.length > 0 ? Math.min(...ansList.map(a => a.timeTakenSec)) : undefined;
    if (fastestResp === Infinity) fastestResp = undefined;

    let currentStreak = 0;
    let maxStreak = existingP.maxStreak || 0;
    currentSession.questions.forEach((q) => {
      const ans = newAnswers[q.id];
      if (ans) {
        if (ans.isCorrect) {
          currentStreak++;
          if (currentStreak > maxStreak) maxStreak = currentStreak;
        } else {
          currentStreak = 0;
        }
      }
    });

    const newScore = (existingP.score || 0) + pointsAwarded;

    const updatedP: Participant = {
      ...existingP,
      score: newScore,
      streak: currentStreak,
      maxStreak: maxStreak,
      correctCount: newCorrectCount,
      totalResponseTime: newTotalResponseTime,
      fastestResponseSec: fastestResp,
      answers: newAnswers
    };

    // 1. Instant local optimistic UI update
    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        participants: {
          ...prev.participants,
          [participantId]: updatedP
        }
      };
    });

    console.log('[Realtime] Answer Confirmed (Optimistic)', {
      participantId,
      questionId: currentQ.id,
      pointsAwarded,
      isCorrect: evaluation.isCorrect
    });

    // 2. Broadcast lightweight notification (Low network bandwidth)
    broadcastAction('PARTICIPANT_ANSWERED', null, {
      participantId,
      participantName: existingP.name,
      questionId: currentQ.id,
      timestamp: Date.now()
    });

    // 3. Persist answer asynchronously
    if (isSupabaseConfigured()) {
      recordAnswerInSupabase(
        sessionId,
        participantId,
        currentQIndex,
        selectedOption,
        evaluation.isCorrect,
        pointsAwarded,
        Math.round(timeTakenSec * 1000)
      ).catch(e => console.warn('Supabase answer save notice:', e));

      addParticipantToSupabase(sessionId, updatedP).catch(e => console.warn('Supabase participant update notice:', e));
    }
  }, [sessionId, participantId, broadcastAction]);

  // Host Action Controller (Host Authority)
  const hostAction = useCallback(async (action: string, payloadData?: any) => {
    const cleanSessionId = (sessionId || sessionRef.current?.id || '').toUpperCase();
    const now = Date.now();

    console.log(`[Realtime] Host Authority Action: ${action}`, {
      roomId: cleanSessionId,
      action,
      timestamp: now
    });

    let updatedLocalSession: GameSession | null = null;

    setSession(prev => {
      if (!prev) return null;
      let nextSession = { ...prev };

      if (action === 'PAUSE_TIMER') {
        nextSession.isTimerPaused = !nextSession.isTimerPaused;
      } else if (action === 'ADJUST_TIMER') {
        const delta = payloadData?.deltaSec || 5;
        nextSession.timerRemaining = Math.max(1, nextSession.timerRemaining + delta);
      } else if (action === 'START_QUIZ' || action === 'START_GAME') {
        const duration = nextSession.settings?.timerDurationSec || 20;
        nextSession.status = 'QUESTION';
        nextSession.currentQuestionIndex = 0;
        nextSession.questionStartTime = now;
        nextSession.settings = { ...(nextSession.settings || {}), questionStartTime: now };
        nextSession.timerRemaining = duration;
        nextSession.isTimerPaused = false;
      } else if (action === 'SKIP_QUESTION' || action === 'REVEAL_ANSWER') {
        nextSession.status = 'ANSWER_REVEAL';
        nextSession.revealTimerRemaining = 5;
      } else if (action === 'NEXT_QUESTION') {
        const nextIdx = (nextSession.currentQuestionIndex || 0) + 1;
        if (nextIdx < nextSession.questions.length) {
          const duration = nextSession.settings?.timerDurationSec || 20;
          nextSession.currentQuestionIndex = nextIdx;
          nextSession.status = 'QUESTION';
          nextSession.questionStartTime = now;
          nextSession.settings = { ...(nextSession.settings || {}), questionStartTime: now };
          nextSession.timerRemaining = duration;
          nextSession.isTimerPaused = false;
        } else {
          nextSession.status = 'ENDED';
          nextSession.timerRemaining = 0;
          nextSession.revealTimerRemaining = 0;
        }
      } else if (action === 'END_QUIZ' || action === 'END_GAME') {
        nextSession.status = 'ENDED';
        nextSession.timerRemaining = 0;
        nextSession.revealTimerRemaining = 0;
      }

      updatedLocalSession = nextSession;
      return nextSession;
    });

    // Broadcast authoritative state change immediately
    if (updatedLocalSession) {
      broadcastAction(action, updatedLocalSession, payloadData);
    }

    // Persist status change to Supabase
    if (cleanSessionId && isSupabaseConfigured()) {
      const sb = getSupabase();
      if (!sb) return;

      try {
        if (action === 'START_QUIZ' || action === 'START_GAME') {
          await sb.from('quiz_rooms').update({
            status: 'QUESTION',
            current_question_index: 0,
            settings: updatedLocalSession?.settings || {},
            updated_at: new Date().toISOString()
          }).eq('id', cleanSessionId);
        } else if (action === 'SKIP_QUESTION' || action === 'REVEAL_ANSWER') {
          await sb.from('quiz_rooms').update({
            status: 'ANSWER_REVEAL',
            updated_at: new Date().toISOString()
          }).eq('id', cleanSessionId);
        } else if (action === 'NEXT_QUESTION') {
          const current = sessionRef.current;
          const nextIdx = (current?.currentQuestionIndex || 0) + 1;
          const total = current?.questions?.length || 0;
          if (nextIdx < total) {
            await sb.from('quiz_rooms').update({
              current_question_index: nextIdx,
              status: 'QUESTION',
              settings: updatedLocalSession?.settings || {},
              updated_at: new Date().toISOString()
            }).eq('id', cleanSessionId);
          } else {
            await sb.from('quiz_rooms').update({
              status: 'ENDED',
              updated_at: new Date().toISOString()
            }).eq('id', cleanSessionId);
          }
        } else if (action === 'END_QUIZ' || action === 'END_GAME') {
          await sb.from('quiz_rooms').update({
            status: 'ENDED',
            updated_at: new Date().toISOString()
          }).eq('id', cleanSessionId);

          if (updatedLocalSession) {
            const summary = calculateSessionSummary(updatedLocalSession);
            const totalQCount = updatedLocalSession.questions?.length || 10;
            const leaderboardArr = Object.values(updatedLocalSession.participants || {})
              .sort((a, b) => (b.score || 0) - (a.score || 0))
              .map((p, idx) => ({
                id: p.id,
                name: p.name,
                avatar: p.avatar || '⚡',
                score: p.score || 0,
                correctCount: p.correctCount || 0,
                accuracy: totalQCount > 0 ? Math.round(((p.correctCount || 0) / totalQCount) * 100) : 0,
                avgTime: p.totalResponseTime ? Number((p.totalResponseTime / Math.max(1, p.correctCount || 1)).toFixed(1)) : 0,
                totalResponseTime: p.totalResponseTime || 0,
                fastestResponseSec: p.fastestResponseSec || 0,
                streak: p.streak || 0,
                maxStreak: p.maxStreak || 0,
                rank: idx + 1,
                answers: p.answers || {}
              }));

            saveGameResultToSupabase({
              id: `hist_${cleanSessionId}_${Date.now()}`,
              title: updatedLocalSession.title || 'Live Quiz Session',
              date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
              timestamp: Date.now(),
              totalParticipants: summary.totalParticipants,
              totalQuestions: summary.totalQuestions,
              averageScore: summary.averageScore,
              averageAccuracy: summary.averageAccuracy,
              winnerName: summary.winnerName,
              winnerScore: summary.winnerScore,
              category: updatedLocalSession.questions?.[0]?.category || 'General',
              participants: leaderboardArr,
              fullSession: updatedLocalSession,
              questions: updatedLocalSession.questions
            });
          }
        }
      } catch (err) {
        console.warn('Supabase host action persist notice:', err);
      }
    }
  }, [sessionId, broadcastAction]);

  // Synchronized Master Countdown without broadcasting ticks
  useEffect(() => {
    if (!session || session.status === 'LOBBY' || session.status === 'ENDED') return;

    const interval = setInterval(() => {
      setSession(prevSession => {
        if (!prevSession || prevSession.status === 'LOBBY' || prevSession.status === 'ENDED') return prevSession;

        const isHostClient = isHostRef.current || (prevSession.hostId && participantId && prevSession.hostId === participantId);

        // QUESTION PHASE
        if (prevSession.status === 'QUESTION') {
          if (prevSession.isTimerPaused) return prevSession;

          const totalLimit = prevSession.settings?.timerDurationSec || 20;
          const startTime = prevSession.questionStartTime || prevSession.settings?.questionStartTime || Date.now();
          const effectiveNow = Date.now() + clockOffsetRef.current;
          const elapsedSec = Math.floor((effectiveNow - startTime) / 1000);
          const remaining = Math.max(0, totalLimit - elapsedSec);

          if (remaining === 0 && prevSession.timerRemaining > 0) {
            // ONLY the host triggers reveal transition
            if (isHostClient) {
              setTimeout(() => {
                hostAction('REVEAL_ANSWER');
              }, 0);
            }

            return {
              ...prevSession,
              timerRemaining: 0,
              status: isHostClient ? 'ANSWER_REVEAL' : prevSession.status,
              revealTimerRemaining: 5
            };
          }

          return {
            ...prevSession,
            timerRemaining: remaining
          };
        }

        // ANSWER REVEAL PHASE
        if (prevSession.status === 'ANSWER_REVEAL') {
          const currentReveal = prevSession.revealTimerRemaining !== undefined ? prevSession.revealTimerRemaining : 5;
          const nextReveal = Math.max(0, currentReveal - 1);

          if (nextReveal === 0 && currentReveal > 0) {
            // ONLY the host triggers next question
            if (isHostClient) {
              setTimeout(() => {
                const currentIdx = prevSession.currentQuestionIndex || 0;
                if (currentIdx + 1 < prevSession.questions.length) {
                  hostAction('NEXT_QUESTION');
                } else {
                  hostAction('END_GAME');
                }
              }, 0);
            }

            return {
              ...prevSession,
              revealTimerRemaining: 0
            };
          }

          return {
            ...prevSession,
            revealTimerRemaining: nextReveal
          };
        }

        return prevSession;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [session?.status, session?.currentQuestionIndex, participantId, hostAction]);

  const sendReaction = useCallback((emoji: string, senderName: string) => {
    const newReaction = {
      id: `react_${Date.now()}_${Math.random()}`,
      emoji,
      senderName: senderName || 'Participant'
    };
    setReactions(prev => [...prev.slice(-15), newReaction]);
    broadcastAction('SEND_REACTION', null, { emoji, senderName });
  }, [broadcastAction]);

  const submitFeedback = useCallback(async (rating: number, comment?: string) => {
    if (!sessionId || !participantId) return;

    const currentSession = sessionRef.current;
    if (!currentSession) return;

    const existingP = currentSession.participants?.[participantId];
    const feedbackObj = {
      id: `fb_${participantId}_${Date.now()}`,
      participantId,
      participantName: existingP?.name || 'Participant',
      participantAvatar: existingP?.avatar || '⚡',
      rating,
      comment: comment?.trim() || '',
      timestamp: Date.now()
    };

    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        feedback: {
          ...(prev.feedback || {}),
          [participantId]: feedbackObj
        }
      };
    });

    broadcastAction('SUBMIT_FEEDBACK', null, { feedback: feedbackObj });

    saveFeedbackToSupabase(
      sessionId,
      rating,
      comment,
      participantId,
      existingP?.name,
      existingP?.avatar
    ).catch(() => {});
  }, [sessionId, participantId, broadcastAction]);

  return {
    session,
    sessionId,
    participantId,
    isConnected,
    connectionStatus,
    showBackOnlineToast,
    errorMessage,
    reactions,
    connect,
    submitAnswer,
    submitFeedback,
    sendReaction,
    hostAction,
    setSession
  };
}
