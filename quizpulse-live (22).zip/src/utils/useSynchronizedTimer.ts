import { useState, useEffect, useRef } from 'react';

interface SynchronizedTimerOptions {
  questionStartTime?: number;
  timerDurationSec: number;
  isPaused?: boolean;
  onExpire?: () => void;
  isHost?: boolean;
}

export function useSynchronizedTimer({
  questionStartTime,
  timerDurationSec,
  isPaused = false,
  onExpire,
  isHost = false
}: SynchronizedTimerOptions) {
  // Store the initial start time ref to detect true question transitions
  const lastStartTimeRef = useRef<number | undefined>(questionStartTime);
  const onExpireRef = useRef(onExpire);
  const isHostRef = useRef(isHost);
  const expiredRef = useRef(false);

  useEffect(() => {
    onExpireRef.current = onExpire;
  }, [onExpire]);

  useEffect(() => {
    isHostRef.current = isHost;
  }, [isHost]);

  // Calculate initial remaining
  const calculateRemaining = () => {
    if (!questionStartTime || questionStartTime <= 0) return timerDurationSec;
    const now = Date.now();
    const elapsedSec = Math.floor((now - questionStartTime) / 1000);
    return Math.max(0, timerDurationSec - Math.max(0, elapsedSec));
  };

  const [remainingTime, setRemainingTime] = useState<number>(calculateRemaining);

  // Check if questionStartTime has truly changed (new question started)
  useEffect(() => {
    if (questionStartTime && questionStartTime !== lastStartTimeRef.current) {
      lastStartTimeRef.current = questionStartTime;
      expiredRef.current = false;
      const initial = calculateRemaining();
      setRemainingTime(initial);
      console.log('[Realtime] Timer Initialized', {
        questionStartTime,
        timerDurationSec,
        remainingTime: initial
      });
    }
  }, [questionStartTime, timerDurationSec]);

  // Running interval for visual countdown
  useEffect(() => {
    if (isPaused || !questionStartTime || questionStartTime <= 0) return;

    const interval = setInterval(() => {
      const remaining = calculateRemaining();
      setRemainingTime(remaining);

      if (remaining === 0 && !expiredRef.current) {
        expiredRef.current = true;
        console.log('[Realtime] Timer Expired', {
          questionStartTime,
          isHost: isHostRef.current
        });
        if (isHostRef.current && onExpireRef.current) {
          onExpireRef.current();
        }
      }
    }, 250); // 250ms check ensures crisp visual countdown without lag

    return () => clearInterval(interval);
  }, [questionStartTime, timerDurationSec, isPaused]);

  return remainingTime;
}
