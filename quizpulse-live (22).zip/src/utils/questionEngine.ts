import { Question, QuestionType, MatchingPair, ParticipantAnswer } from '../types';

export function normalizeTextAnswer(text: string): string {
  if (!text) return '';
  return text
    .trim()
    .toLowerCase()
    // Remove punctuation at the end or around words
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"']/g, '')
    // Collapse multiple spaces into one
    .replace(/\s+/g, ' ');
}

export function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export interface AnswerEvaluationResult {
  isCorrect: boolean;
  accuracyRatio: number; // 0.0 to 1.0 (1.0 = fully correct)
  details?: string;
}

/**
 * Central evaluation function for all question types.
 * Evaluates any answer payload against the question definition deterministically.
 */
export function evaluateAnswer(question: Question, rawAnswer: any): AnswerEvaluationResult {
  const type: QuestionType = question.type || 'multiple_choice';

  switch (type) {
    case 'multiple_choice':
    case 'fastest_fingers': {
      const selectedIndex = typeof rawAnswer === 'number' ? rawAnswer : Number(rawAnswer);
      const isCorrect = selectedIndex === question.correctAnswer;
      return {
        isCorrect,
        accuracyRatio: isCorrect ? 1 : 0
      };
    }

    case 'fill_blank': {
      if (typeof rawAnswer !== 'string' || !rawAnswer.trim()) {
        return { isCorrect: false, accuracyRatio: 0 };
      }

      const normalizedInput = normalizeTextAnswer(rawAnswer);
      const acceptedAnswers = question.acceptedAnswers && question.acceptedAnswers.length > 0
        ? question.acceptedAnswers
        : (question.options && question.options.length > 0 ? [question.options[0]] : []);

      const isCorrect = acceptedAnswers.some(ans => {
        const normalizedTarget = normalizeTextAnswer(ans);
        return normalizedTarget.length > 0 && normalizedTarget === normalizedInput;
      });

      return {
        isCorrect,
        accuracyRatio: isCorrect ? 1 : 0
      };
    }

    case 'ordering': {
      // rawAnswer is an array of numbers representing item indices in submitted order
      // or array of strings matching the items
      if (!Array.isArray(rawAnswer) || rawAnswer.length === 0) {
        return { isCorrect: false, accuracyRatio: 0 };
      }

      const correctItems = question.orderItems && question.orderItems.length > 0
        ? question.orderItems
        : question.options || [];

      if (correctItems.length === 0) {
        return { isCorrect: false, accuracyRatio: 0 };
      }

      // Check if submitted order matches correct sequence [0, 1, 2, 3, ...]
      let matches = 0;
      for (let i = 0; i < correctItems.length; i++) {
        if (typeof rawAnswer[i] === 'number') {
          if (rawAnswer[i] === i) matches++;
        } else if (typeof rawAnswer[i] === 'string') {
          if (rawAnswer[i].trim().toLowerCase() === correctItems[i].trim().toLowerCase()) matches++;
        }
      }

      const accuracyRatio = matches / correctItems.length;
      const isCorrect = matches === correctItems.length;

      return {
        isCorrect,
        accuracyRatio
      };
    }

    case 'matching': {
      // rawAnswer is Record<string, string> (e.g. pairId -> rightId or leftText -> rightText)
      if (!rawAnswer || typeof rawAnswer !== 'object') {
        return { isCorrect: false, accuracyRatio: 0 };
      }

      const pairs = question.matchingPairs || [];
      if (pairs.length === 0) {
        return { isCorrect: false, accuracyRatio: 0 };
      }

      let correctMatches = 0;
      pairs.forEach(pair => {
        // Check by ID or text match
        const submittedRight = rawAnswer[pair.id] || rawAnswer[pair.left];
        if (submittedRight) {
          if (submittedRight === pair.id || submittedRight === pair.right || normalizeTextAnswer(submittedRight) === normalizeTextAnswer(pair.right)) {
            correctMatches++;
          }
        }
      });

      const accuracyRatio = correctMatches / pairs.length;
      const isCorrect = correctMatches === pairs.length;

      return {
        isCorrect,
        accuracyRatio
      };
    }

    default: {
      const selectedIndex = typeof rawAnswer === 'number' ? rawAnswer : Number(rawAnswer);
      const isCorrect = selectedIndex === question.correctAnswer;
      return { isCorrect, accuracyRatio: isCorrect ? 1 : 0 };
    }
  }
}

/**
 * Central scoring calculation for any question type.
 */
export function scoreAnswer(
  question: Question,
  evaluation: AnswerEvaluationResult,
  timeTakenSec: number,
  totalTimeLimit: number,
  enableBonusSpeed: boolean = true
): { pointsAwarded: number; speedBonus: number } {
  if (!evaluation.isCorrect && evaluation.accuracyRatio === 0) {
    return { pointsAwarded: 0, speedBonus: 0 };
  }

  const type: QuestionType = question.type || 'multiple_choice';
  const effectiveTimeLimit = Math.max(5, totalTimeLimit || question.estimatedTimeSec || 20);
  const clampedTimeTaken = Math.min(effectiveTimeLimit, Math.max(0.2, timeTakenSec));
  const timeRatio = Math.max(0, 1 - (clampedTimeTaken / effectiveTimeLimit));

  // Fastest Fingers question type strongly emphasizes speed
  if (type === 'fastest_fingers') {
    if (!evaluation.isCorrect) return { pointsAwarded: 0, speedBonus: 0 };
    const basePoints = 500;
    const speedPoints = Math.round(1000 * Math.pow(timeRatio, 1.2));
    const totalPoints = basePoints + speedPoints;
    return {
      pointsAwarded: totalPoints,
      speedBonus: speedPoints
    };
  }

  // Standard Multi-Choice, Fill-Blank, Ordering, Matching
  const basePointsMax = 1000;
  if (evaluation.isCorrect) {
    if (!enableBonusSpeed) {
      return { pointsAwarded: basePointsMax, speedBonus: 0 };
    }
    const speedMultiplier = Math.max(0.1, timeRatio);
    const points = Math.max(200, Math.round(basePointsMax * speedMultiplier));
    const speedBonus = Math.max(0, points - 200);
    return {
      pointsAwarded: points,
      speedBonus
    };
  } else if (evaluation.accuracyRatio > 0) {
    // Partial points for ordering / matching
    const partialBase = Math.round(basePointsMax * evaluation.accuracyRatio * 0.7);
    return {
      pointsAwarded: Math.max(50, partialBase),
      speedBonus: 0
    };
  }

  return { pointsAwarded: 0, speedBonus: 0 };
}

export function getQuestionTypeLabel(type?: QuestionType): string {
  switch (type) {
    case 'fastest_fingers': return 'Fastest Fingers';
    case 'fill_blank': return 'Fill in the Blank';
    case 'ordering': return 'Ordering / Ranking';
    case 'matching': return 'Matching Pairs';
    case 'multiple_choice':
    default:
      return 'Multiple Choice';
  }
}

export function getQuestionTypeBadgeColor(type?: QuestionType): { bg: string; text: string; border: string } {
  switch (type) {
    case 'fastest_fingers':
      return { bg: 'bg-amber-500/20', text: 'text-amber-300', border: 'border-amber-500/40' };
    case 'fill_blank':
      return { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' };
    case 'ordering':
      return { bg: 'bg-cyan-500/20', text: 'text-cyan-300', border: 'border-cyan-500/40' };
    case 'matching':
      return { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/40' };
    case 'multiple_choice':
    default:
      return { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' };
  }
}
