/**
 * QuizPulse Pay-As-You-Go Central Pricing Configuration
 *
 * Single Source of Truth for game capacity tiers, pricing calculation,
 * and currency formatting.
 */

export interface PricingTier {
  minPlayers: number;
  maxPlayers: number;
  price: number; // in NGN (Naira)
  formattedPrice: string;
  label: string;
  isFree: boolean;
  badge?: string;
}

export const CURRENCY_SYMBOL = '₦';
export const CURRENCY_CODE = 'NGN';
export const MAX_SUPPORTED_PLAYERS = 100;
export const FREE_PLAYER_LIMIT = 5;

/**
 * Central Pricing Tiers Definition:
 * 0–5 players   → ₦0 (FREE)
 * 6–10 players  → ₦5,000
 * 11–20 players → ₦10,000
 * 21–50 players → ₦25,000
 * 51–100 players→ ₦50,000
 */
export const PRICING_TIERS: PricingTier[] = [
  {
    minPlayers: 0,
    maxPlayers: 5,
    price: 0,
    formattedPrice: 'FREE',
    label: '0–5 Players',
    isFree: true,
    badge: 'Free Forever'
  },
  {
    minPlayers: 6,
    maxPlayers: 10,
    price: 5000,
    formattedPrice: '₦5,000',
    label: '6–10 Players',
    isFree: false,
    badge: 'Micro Event'
  },
  {
    minPlayers: 11,
    maxPlayers: 20,
    price: 10000,
    formattedPrice: '₦10,000',
    label: '11–20 Players',
    isFree: false,
    badge: 'Small Group'
  },
  {
    minPlayers: 21,
    maxPlayers: 50,
    price: 25000,
    formattedPrice: '₦25,000',
    label: '21–50 Players',
    isFree: false,
    badge: 'Popular Choice'
  },
  {
    minPlayers: 51,
    maxPlayers: 100,
    price: 50000,
    formattedPrice: '₦50,000',
    label: '51–100 Players',
    isFree: false,
    badge: 'Large Gathering'
  }
];

export const ALLOWED_CAPACITY_PRESETS = [5, 10, 20, 50, 100] as const;

export interface PriceCalculationResult {
  playerCapacity: number;
  price: number;
  formattedPrice: string;
  isFree: boolean;
  tier: PricingTier;
  isValidCapacity: boolean;
  errorMessage?: string;
}

/**
 * Format a number as NGN currency (e.g. 5000 -> ₦5,000)
 */
export function formatPrice(amount: number): string {
  if (amount === 0) return 'FREE';
  return `${CURRENCY_SYMBOL}${amount.toLocaleString('en-NG')}`;
}

/**
 * Single source of truth to calculate the live game price from player capacity.
 *
 * @param playerCapacity The maximum number of players the host wants to allow.
 */
export function calculateGamePrice(playerCapacity: number): PriceCalculationResult {
  const capacity = Number(playerCapacity) || 0;

  if (capacity < 1) {
    const freeTier = PRICING_TIERS[0];
    return {
      playerCapacity: 5,
      price: freeTier.price,
      formattedPrice: freeTier.formattedPrice,
      isFree: true,
      tier: freeTier,
      isValidCapacity: true
    };
  }

  if (capacity > MAX_SUPPORTED_PLAYERS) {
    const topTier = PRICING_TIERS[PRICING_TIERS.length - 1];
    return {
      playerCapacity: capacity,
      price: topTier.price,
      formattedPrice: topTier.formattedPrice,
      isFree: false,
      tier: topTier,
      isValidCapacity: false,
      errorMessage: `Maximum capacity is currently ${MAX_SUPPORTED_PLAYERS} players.`
    };
  }

  const matchingTier = PRICING_TIERS.find(
    tier => capacity >= tier.minPlayers && capacity <= tier.maxPlayers
  ) || PRICING_TIERS[PRICING_TIERS.length - 1];

  return {
    playerCapacity: capacity,
    price: matchingTier.price,
    formattedPrice: matchingTier.price === 0 ? 'FREE' : formatPrice(matchingTier.price),
    isFree: matchingTier.price === 0,
    tier: matchingTier,
    isValidCapacity: true
  };
}
