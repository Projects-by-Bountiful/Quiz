import { Question } from '../types';

export const SAMPLE_QUESTIONS: Question[] = [
  // 1. Multiple Choice Questions
  {
    id: 'q1',
    type: 'multiple_choice',
    category: 'Web Development',
    difficulty: 'Easy',
    question: 'Which HTML tag is used to embed JavaScript code inside an HTML document?',
    options: ['<script>', '<javascript>', '<js>', '<codescript>'],
    correctAnswer: 0,
    explanation: 'The <script> tag is the standard HTML tag used to define client-side scripts.',
    tags: ['HTML', 'JavaScript', 'Web Basics'],
    estimatedTimeSec: 15,
    status: 'active'
  },
  {
    id: 'q2',
    type: 'multiple_choice',
    category: 'JavaScript & React',
    difficulty: 'Medium',
    question: 'In React, what hook should you use to perform side effects in functional components?',
    options: ['useState', 'useEffect', 'useContext', 'useReducer'],
    correctAnswer: 1,
    explanation: 'useEffect handles side effects such as data fetching, subscriptions, or manually changing DOM node values.',
    tags: ['React', 'Hooks', 'Frontend'],
    estimatedTimeSec: 20,
    status: 'active'
  },
  {
    id: 'q3',
    type: 'multiple_choice',
    category: 'AI & Machine Learning',
    difficulty: 'Medium',
    question: 'What does LLM stand for in the context of modern Artificial Intelligence?',
    options: [
      'Large Logic Module',
      'Long-term Learning Model',
      'Large Language Model',
      'Linear Learning Matrix'
    ],
    correctAnswer: 2,
    explanation: 'LLM stands for Large Language Model, a type of AI algorithm trained on vast text datasets to generate human-like text.',
    tags: ['AI', 'LLM', 'Tech Trends'],
    estimatedTimeSec: 15,
    status: 'active'
  },
  {
    id: 'q4',
    type: 'multiple_choice',
    category: 'UI/UX Design',
    difficulty: 'Easy',
    question: 'What is the primary purpose of creating a wireframe during design development?',
    options: [
      'To test final brand colors',
      'To outline structural layout and element placement',
      'To write production database schemas',
      'To measure server load times'
    ],
    correctAnswer: 1,
    explanation: 'Wireframes act as visual blueprints focusing on structural content and layout without visual distractions.',
    tags: ['UX', 'Wireframe', 'Design'],
    estimatedTimeSec: 15,
    status: 'active'
  },

  // 2. Fastest Fingers Questions
  {
    id: 'q_ff1',
    type: 'fastest_fingers',
    category: 'General Knowledge',
    difficulty: 'Easy',
    question: '⚡ FASTEST FINGERS: What is the primary color of the sun as seen from outer space?',
    options: ['White', 'Yellow', 'Red', 'Orange'],
    correctAnswer: 0,
    explanation: 'The sun emits all visible wavelengths of light almost equally, appearing pure white when viewed from outer space.',
    tags: ['Space', 'Science', 'Speed Challenge'],
    estimatedTimeSec: 10,
    status: 'active'
  },
  {
    id: 'q_ff2',
    type: 'fastest_fingers',
    category: 'JavaScript & React',
    difficulty: 'Medium',
    question: '⚡ FASTEST FINGERS: Which keyword is used to declare a block-scoped constant variable in modern JavaScript?',
    options: ['const', 'let', 'var', 'immutable'],
    correctAnswer: 0,
    explanation: 'const declares block-scoped constants that cannot be reassigned.',
    tags: ['JavaScript', 'ES6', 'Speed'],
    estimatedTimeSec: 10,
    status: 'active'
  },

  // 3. Fill in the Blank Questions
  {
    id: 'q_fib1',
    type: 'fill_blank',
    category: 'Web Development',
    difficulty: 'Medium',
    question: 'In web architecture, CSS stands for Cascading ______ Sheets.',
    acceptedAnswers: ['Style', 'style', 'Styles'],
    explanation: 'CSS stands for Cascading Style Sheets, used to style HTML elements.',
    tags: ['CSS', 'Web Basics'],
    estimatedTimeSec: 20,
    status: 'active'
  },
  {
    id: 'q_fib2',
    type: 'fill_blank',
    category: 'Cybersecurity',
    difficulty: 'Medium',
    question: 'In secure web communication, HTTPS encrypts traffic using the ______ protocol.',
    acceptedAnswers: ['TLS', 'SSL', 'TLS/SSL', 'SSL/TLS'],
    explanation: 'HTTPS uses TLS (Transport Layer Security, formerly SSL) to encrypt web traffic.',
    tags: ['Security', 'HTTPS', 'Networking'],
    estimatedTimeSec: 20,
    status: 'active'
  },
  {
    id: 'q_fib3',
    type: 'fill_blank',
    category: 'Product Management',
    difficulty: 'Easy',
    question: 'In Agile development, the short fixed-duration cycle where teams complete work is called a ______.',
    acceptedAnswers: ['sprint', 'iteration', 'Sprint'],
    explanation: 'A sprint is a repeatable, time-boxed period during which a specific product increment is created.',
    tags: ['Agile', 'Scrum', 'Product'],
    estimatedTimeSec: 15,
    status: 'active'
  },

  // 4. Ordering / Ranking Questions
  {
    id: 'q_ord1',
    type: 'ordering',
    category: 'Web Development',
    difficulty: 'Medium',
    question: 'Arrange the Web Development lifecycle stages in chronological order from first to last:',
    orderItems: [
      'Requirement Gathering & UX Research',
      'Wireframing & UI Prototyping',
      'Frontend & Backend Coding',
      'Testing, Deployment & Monitoring'
    ],
    explanation: 'Standard engineering workflows proceed from research to wireframing, followed by implementation, and finally deployment.',
    tags: ['Engineering', 'Workflow', 'Ordering'],
    estimatedTimeSec: 25,
    status: 'active'
  },
  {
    id: 'q_ord2',
    type: 'ordering',
    category: 'JavaScript & React',
    difficulty: 'Hard',
    question: 'Order the React Component lifecycle phases in execution sequence from mount to unmount:',
    orderItems: [
      'Initial Render (JSX computation)',
      'DOM Mutation & Paint',
      'useEffect Execution',
      'Component Cleanup (Unmount)'
    ],
    explanation: 'React first computes the virtual DOM, commits to the real DOM, executes layout/effects, and runs cleanups upon unmounting.',
    tags: ['React', 'Lifecycle', 'Deep Dive'],
    estimatedTimeSec: 25,
    status: 'active'
  },

  // 5. Matching Pairs Questions
  {
    id: 'q_mat1',
    type: 'matching',
    category: 'General Knowledge',
    difficulty: 'Medium',
    question: 'Match each programming language with its primary creator or ecosystem:',
    matchingPairs: [
      { id: 'm1', left: 'JavaScript', right: 'Brendan Eich (Netscape)' },
      { id: 'm2', left: 'Python', right: 'Guido van Rossum' },
      { id: 'm3', left: 'TypeScript', right: 'Anders Hejlsberg (Microsoft)' },
      { id: 'm4', left: 'Rust', right: 'Graydon Hoare (Mozilla)' }
    ],
    explanation: 'JavaScript was created by Brendan Eich, Python by Guido van Rossum, TypeScript by Anders Hejlsberg, and Rust by Graydon Hoare.',
    tags: ['History', 'Programming', 'Matching'],
    estimatedTimeSec: 25,
    status: 'active'
  },
  {
    id: 'q_mat2',
    type: 'matching',
    category: 'UI/UX Design',
    difficulty: 'Easy',
    question: 'Match each design concept to its definition:',
    matchingPairs: [
      { id: 'm2_1', left: 'Affordance', right: 'Visual clue to how an object is used' },
      { id: 'm2_2', left: 'Hierarchy', right: 'Visual arrangement denoting importance' },
      { id: 'm2_3', left: 'Kerning', right: 'Spacing between individual characters' },
      { id: 'm2_4', left: 'Whitespace', right: 'Negative space surrounding elements' }
    ],
    explanation: 'Affordances suggest interaction, visual hierarchy guides attention, kerning adjusts letter spacing, and whitespace gives layout breathing room.',
    tags: ['Design', 'UX', 'Typography'],
    estimatedTimeSec: 25,
    status: 'active'
  }
];
