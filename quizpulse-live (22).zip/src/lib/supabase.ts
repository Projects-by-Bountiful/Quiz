import { createClient, SupabaseClient } from '@supabase/supabase-js';

const metaEnv = (import.meta as any).env || {};
const DEFAULT_SUPABASE_URL = 'https://rhifmhjceinusodsbaea.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJoaWZtaGpjZWludXNvZHNiYWVhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUzOTMwMzAsImV4cCI6MjEwMDk2OTAzMH0.PR6z62VCynlVlFi1Ze8dihw_IlX5pU2JVqQj4xBGFfE';

const supabaseUrl = metaEnv.VITE_SUPABASE_URL || (typeof process !== 'undefined' ? process.env?.VITE_SUPABASE_URL : '') || DEFAULT_SUPABASE_URL;
const supabaseAnonKey = metaEnv.VITE_SUPABASE_ANON_KEY || (typeof process !== 'undefined' ? process.env?.VITE_SUPABASE_ANON_KEY : '') || DEFAULT_SUPABASE_ANON_KEY;

const isDev = Boolean(metaEnv.DEV || (typeof process !== 'undefined' && process.env?.NODE_ENV === 'development'));

if (!supabaseUrl || !supabaseAnonKey) {
  const missing = [];
  if (!supabaseUrl) missing.push('VITE_SUPABASE_URL');
  if (!supabaseAnonKey) missing.push('VITE_SUPABASE_ANON_KEY');
  const errorMsg = `[SUPABASE CONFIGURATION ERROR] Missing required environment variable(s): ${missing.join(', ')}. ` +
    `Ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set in Netlify or your .env file.`;
  console.error(errorMsg);
}

export const supabase: SupabaseClient | null = (supabaseUrl && supabaseAnonKey)
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

export function getSupabase(): SupabaseClient | null {
  return supabase;
}

export const isSupabaseConfigured = (): boolean => {
  return Boolean(supabaseUrl && supabaseAnonKey && supabase);
};


/*
-- SQL SCHEMA FOR SUPABASE DATABASE SETUP --
-- Execute this SQL in your Supabase SQL Editor:

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY,
  question TEXT NOT NULL,
  options JSONB NOT NULL,
  correct_answer INT NOT NULL,
  category TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  explanation TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS quiz_rooms (
  id TEXT PRIMARY KEY, -- Room Code (e.g. A7KX92)
  title TEXT NOT NULL,
  host_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'LOBBY', -- LOBBY, IN_PROGRESS, QUESTION_RESULT, COMPLETED
  current_question_index INT DEFAULT 0,
  timer_duration_sec INT DEFAULT 20,
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  questions JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS participants (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES quiz_rooms(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  avatar TEXT,
  score INT DEFAULT 0,
  streak INT DEFAULT 0,
  joined_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS answers (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES quiz_rooms(id) ON DELETE CASCADE,
  participant_id TEXT NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
  question_index INT NOT NULL,
  selected_option INT NOT NULL,
  is_correct BOOLEAN NOT NULL,
  points_awarded INT DEFAULT 0,
  time_taken_ms INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS game_results (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL,
  title TEXT NOT NULL,
  participant_count INT DEFAULT 0,
  leaderboard JSONB NOT NULL DEFAULT '[]'::jsonb,
  completed_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Realtime replication
ALTER PUBLICATION supabase_realtime ADD TABLE quiz_rooms, participants, answers;
*/
