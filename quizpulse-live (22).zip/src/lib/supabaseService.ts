import { getSupabase, isSupabaseConfigured } from './supabase';
import { safeInsertQuizRoom } from './quizRoomInspector';
import { Question, GameSession, Participant, ParticipantAnswer, Category, GameHistoryRecord, SessionFeedback } from '../types';

// Helper to check if Supabase is active
export { isSupabaseConfigured };

// --- QUESTIONS & CATEGORIES ---

export async function fetchQuestionsFromSupabase(): Promise<Question[]> {
  const supabase = getSupabase();
  if (!supabase) return [];

  try {
    const { data, error } = await supabase
      .from('questions')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase fetch questions error:', error);
      return [];
    }

    if (data && data.length > 0) {
      return data.map((q: any) => {
        let parsedOptions: any = q.options;
        if (typeof parsedOptions === 'string') {
          try { parsedOptions = JSON.parse(parsedOptions); } catch (e) { parsedOptions = []; }
        }

        let qType = q.type || 'multiple_choice';
        let acceptedAnswers = q.accepted_answers || q.acceptedAnswers;
        let orderItems = q.order_items || q.orderItems;
        let matchingPairs = q.matching_pairs || q.matchingPairs;

        if (parsedOptions && typeof parsedOptions === 'object' && !Array.isArray(parsedOptions)) {
          qType = parsedOptions.type || qType;
          acceptedAnswers = parsedOptions.acceptedAnswers || acceptedAnswers;
          orderItems = parsedOptions.orderItems || orderItems;
          matchingPairs = parsedOptions.matchingPairs || matchingPairs;
          parsedOptions = parsedOptions.options || [];
        }

        return {
          id: q.id,
          type: qType,
          question: q.question,
          options: Array.isArray(parsedOptions) ? parsedOptions : (qType === 'multiple_choice' || qType === 'fastest_fingers' ? ['A', 'B', 'C', 'D'] : []),
          correctAnswer: typeof q.correct_answer === 'number' ? q.correct_answer : 0,
          acceptedAnswers: Array.isArray(acceptedAnswers) ? acceptedAnswers : undefined,
          orderItems: Array.isArray(orderItems) ? orderItems : undefined,
          matchingPairs: Array.isArray(matchingPairs) ? matchingPairs : undefined,
          category: q.category || 'General Knowledge',
          difficulty: q.difficulty || 'Medium',
          explanation: q.explanation || '',
          tags: Array.isArray(q.tags) ? q.tags : [],
          estimatedTimeSec: q.estimated_time_sec || 20,
          status: 'active'
        };
      });
    }
  } catch (err) {
    console.error('Error fetching questions from Supabase:', err);
  }
  return [];
}

export async function saveQuestionToSupabase(q: Question): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase) return false;

  try {
    const payload: any = {
      id: q.id,
      question: q.question,
      options: q.options || [],
      correct_answer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
      category: q.category,
      difficulty: q.difficulty,
      explanation: q.explanation || ''
    };

    if (q.type) payload.type = q.type;
    if (q.acceptedAnswers) payload.accepted_answers = q.acceptedAnswers;
    if (q.orderItems) payload.order_items = q.orderItems;
    if (q.matchingPairs) payload.matching_pairs = q.matchingPairs;

    const { error } = await supabase
      .from('questions')
      .upsert(payload);

    if (error) {
      if (error.code === '42703') {
        // Fallback if custom columns don't exist yet: store full config inside options JSON
        const fallbackPayload = {
          id: q.id,
          question: q.question,
          options: {
            type: q.type || 'multiple_choice',
            options: q.options || [],
            acceptedAnswers: q.acceptedAnswers,
            orderItems: q.orderItems,
            matchingPairs: q.matchingPairs
          },
          correct_answer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
          category: q.category,
          difficulty: q.difficulty,
          explanation: q.explanation || ''
        };
        const { error: fallbackError } = await supabase.from('questions').upsert(fallbackPayload);
        if (fallbackError) {
          console.warn('Fallback save question error:', fallbackError);
          return false;
        }
        return true;
      }
      if (error.code === '42P01') {
        console.warn('Supabase table "questions" missing. Please run the SQL setup script in Supabase SQL Editor.');
      } else if (error.code === '42501') {
        console.warn('Supabase RLS policy issue. Please enable public access or disable RLS for table "questions".');
      } else {
        console.warn('Error saving question to Supabase:', error.message || error);
      }
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase save question exception:', err);
    return false;
  }
}

export async function saveQuestionsBulkToSupabase(questions: Question[]): Promise<{ success: boolean; count?: number; error?: string }> {
  const supabase = getSupabase();
  if (!supabase || questions.length === 0) return { success: false, error: 'Supabase client not available or questions array empty' };

  try {
    const rows = questions.map(q => {
      const row: any = {
        id: q.id,
        question: q.question,
        options: q.options || [],
        correct_answer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
        category: q.category,
        difficulty: q.difficulty,
        explanation: q.explanation || ''
      };
      if (q.type) row.type = q.type;
      if (q.acceptedAnswers) row.accepted_answers = q.acceptedAnswers;
      if (q.orderItems) row.order_items = q.orderItems;
      if (q.matchingPairs) row.matching_pairs = q.matchingPairs;
      return row;
    });

    console.log("Questions Bulk Payload Count:", rows.length);
    let { error, data } = await supabase.from('questions').upsert(rows).select();

    if (error && error.code === '42703') {
      // Fallback without extra columns
      const fallbackRows = questions.map(q => ({
        id: q.id,
        question: q.question,
        options: {
          type: q.type || 'multiple_choice',
          options: q.options || [],
          acceptedAnswers: q.acceptedAnswers,
          orderItems: q.orderItems,
          matchingPairs: q.matchingPairs
        },
        correct_answer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
        category: q.category,
        difficulty: q.difficulty,
        explanation: q.explanation || ''
      }));
      const fallbackRes = await supabase.from('questions').upsert(fallbackRows).select();
      error = fallbackRes.error;
      data = fallbackRes.data;
    }

    if (error) {
      if (error.code === '42P01') {
        console.warn('Supabase table "questions" missing. Please run the SQL setup script in Supabase SQL Editor.');
      } else if (error.code === '42501' || error.message?.includes('row-level security')) {
        console.warn('Supabase RLS policy issue. Please disable RLS for table "questions": ALTER TABLE questions DISABLE ROW LEVEL SECURITY;');
        return { success: false, error: 'Row-Level Security violation on "questions" table. Please run: ALTER TABLE questions DISABLE ROW LEVEL SECURITY; in your Supabase SQL Editor.' };
      } else {
        console.warn('Notice bulk saving questions to Supabase:', error.message || error);
      }
      return { success: false, error: error.message };
    }

    console.log("Supabase Bulk Questions Inserted Count:", data ? data.length : rows.length);
    return { success: true, count: data ? data.length : rows.length };
  } catch (err: any) {
    console.warn('Supabase bulk save questions exception:', err);
    return { success: false, error: err?.message || String(err) };
  }
}

export async function fetchCategoriesFromSupabase(): Promise<string[]> {
  const supabase = getSupabase();
  if (!supabase) return [];

  try {
    const { data, error } = await supabase.from('categories').select('name');
    if (error || !data) return [];
    return data.map((row: any) => row.name);
  } catch (err) {
    console.warn('Supabase fetch categories error:', err);
    return [];
  }
}

export async function addCategoryToSupabase(categoryName: string): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase) return false;

  try {
    const { error } = await supabase.from('categories').upsert({
      id: `cat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: categoryName
    }, { onConflict: 'name' });

    if (error) {
      console.warn('Error adding category to Supabase:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase add category exception:', err);
    return false;
  }
}

export async function deleteCategoryFromSupabase(categoryName: string): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase) return false;

  try {
    await supabase.from('categories').delete().eq('name', categoryName);
    return true;
  } catch (err) {
    console.warn('Supabase delete category exception:', err);
    return false;
  }
}

export async function deleteQuestionFromSupabase(id: string): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase) return false;

  try {
    const { error } = await supabase.from('questions').delete().eq('id', id);
    if (error) {
      console.error('[QuizPulse] Error deleting question from Supabase:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.error('[QuizPulse] Supabase delete question error:', err);
    return false;
  }
}

export async function deleteQuestionsBulkFromSupabase(ids: string[]): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase || ids.length === 0) return false;

  try {
    const { error } = await supabase.from('questions').delete().in('id', ids);
    if (error) {
      console.error('[QuizPulse] Error bulk deleting questions from Supabase:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.error('[QuizPulse] Supabase bulk delete questions error:', err);
    return false;
  }
}

// --- QUIZ ROOMS & SESSIONS ---

export async function saveQuizRoomToSupabase(session: GameSession): Promise<{ success: boolean; data?: any; error?: string }> {
  const supabase = getSupabase();
  if (!supabase) return { success: false, error: 'Supabase client not initialized' };

  let authUser: any = null;
  try {
    const { data: authData } = await supabase.auth.getUser();
    authUser = authData?.user;
    console.log("Authenticated User:", authUser);
  } catch (err) {
    console.warn("Auth getUser warning:", err);
  }

  const hostUserId = authUser?.id || session.hostId || 'host_default';
  if (!hostUserId) {
    console.error("Cannot insert quiz_room: host_id is null or empty");
    return { success: false, error: 'host_id is null or empty' };
  }

  const roomData = {
    id: session.id.toUpperCase(),
    title: session.title,
    host_id: hostUserId,
    status: session.status,
    current_question_index: session.currentQuestionIndex || 0,
    timer_duration_sec: session.settings?.timerDurationSec || 20,
    settings: session.settings || {},
    questions: session.questions || [],
    updated_at: new Date().toISOString()
  };

  console.log("Room payload:", session);
  console.log("Insert payload:", roomData);

  try {
    const res = await safeInsertQuizRoom(supabase, roomData);
    console.log("Returned rows:", res.data);
    if (!res.success) {
      console.error('Error saving quiz room to Supabase:', res.error);
      return { success: false, error: res.error };
    }

    // Save participants
    if (session.participants && Object.keys(session.participants).length > 0) {
      const pRows = Object.values(session.participants).map(p => ({
        id: p.id,
        room_id: session.id.toUpperCase(),
        name: p.name,
        avatar: p.avatar,
        score: p.score || 0,
        streak: p.streak || 0
      }));
      const { data: pData, error: pErr } = await supabase.from('participants').upsert(pRows).select();
      console.log("Participant Inserted Rows:", pData, "Error:", pErr);
    }

    return { success: true, data: res.data };
  } catch (err: any) {
    console.error('Supabase save quiz room exception:', err);
    return { success: false, error: err?.message || String(err) };
  }
}

export async function fetchQuizRoomFromSupabase(roomId: string): Promise<GameSession | null> {
  const supabase = getSupabase();
  if (!supabase || !roomId) return null;

  try {
    const cleanRoomId = roomId.trim().toUpperCase();
    const { data: roomData, error: roomError } = await supabase
      .from('quiz_rooms')
      .select('*')
      .eq('id', cleanRoomId)
      .single();

    if (roomError || !roomData) {
      console.warn('Quiz room not found or fetch error in Supabase:', roomError);
      return null;
    }

    // Safely parse questions and settings
    const parsedQuestions = Array.isArray(roomData.questions)
      ? roomData.questions
      : (typeof roomData.questions === 'string' ? JSON.parse(roomData.questions || '[]') : []);

    const parsedSettings = typeof roomData.settings === 'object' && roomData.settings !== null
      ? roomData.settings
      : (typeof roomData.settings === 'string' ? JSON.parse(roomData.settings || '{}') : {});

    // Fetch participants for this room
    const { data: pData } = await supabase
      .from('participants')
      .select('*')
      .eq('room_id', cleanRoomId);

    // Fetch answers for this room
    const { data: answersData } = await supabase
      .from('answers')
      .select('*')
      .eq('room_id', cleanRoomId);

    const answersByParticipant: Record<string, Record<string, ParticipantAnswer>> = {};
    if (answersData && Array.isArray(answersData)) {
      answersData.forEach((ans: any) => {
        const pid = ans.participant_id;
        if (!answersByParticipant[pid]) {
          answersByParticipant[pid] = {};
        }
        const qIndex = ans.question_index;
        const qId = parsedQuestions[qIndex]?.id || `q_${qIndex}`;
        const timeSec = (ans.time_taken_ms || 0) / 1000;
        const isCorrect = Boolean(ans.is_correct);
        answersByParticipant[pid][qId] = {
          questionId: qId,
          selectedOption: ans.selected_option,
          timeTakenSec: timeSec,
          isCorrect: isCorrect,
          scoreGained: ans.points_awarded || 0,
          speedBonus: Math.max(0, (ans.points_awarded || 0) - 100),
          timestamp: new Date(ans.created_at || Date.now()).getTime()
        };
      });
    }

    const participantsObj: Record<string, Participant> = {};
    if (pData && Array.isArray(pData)) {
      pData.forEach((p: any) => {
        const pAnswers = answersByParticipant[p.id] || {};
        const ansList = Object.values(pAnswers);
        const correctCount = ansList.filter(a => a.isCorrect).length;
        const totalResponseTime = ansList.reduce((sum, a) => sum + (a.timeTakenSec || 0), 0);
        let fastestResponseSec = ansList.length > 0 ? Math.min(...ansList.map(a => a.timeTakenSec)) : undefined;
        if (fastestResponseSec === Infinity) fastestResponseSec = undefined;

        let currentStreak = 0;
        let maxStreak = p.streak || 0;
        parsedQuestions.forEach((q: any) => {
          const ans = pAnswers[q.id];
          if (ans) {
            if (ans.isCorrect) {
              currentStreak++;
              if (currentStreak > maxStreak) maxStreak = currentStreak;
            } else {
              currentStreak = 0;
            }
          }
        });

        participantsObj[p.id] = {
          id: p.id,
          name: p.name,
          avatar: p.avatar || '⚡',
          score: p.score || 0,
          streak: p.streak || 0,
          maxStreak: maxStreak,
          correctCount: correctCount,
          totalResponseTime: totalResponseTime,
          fastestResponseSec: fastestResponseSec,
          answers: pAnswers,
          joinedAt: Date.now(),
          isOnline: true
        };
      });
    }

    const qStartTime = parsedSettings.questionStartTime 
      || (roomData.question_start_time ? new Date(roomData.question_start_time).getTime() : new Date(roomData.created_at || Date.now()).getTime());

    // Fetch feedback for this room
    const feedbackList = await fetchFeedbackForRoom(cleanRoomId);
    const feedbackObj: Record<string, SessionFeedback> = {};
    feedbackList.forEach(fb => {
      if (fb.participantId) {
        feedbackObj[fb.participantId] = fb;
      }
    });

    return {
      id: roomData.id,
      title: roomData.title,
      createdAt: new Date(roomData.created_at || Date.now()).getTime(),
      status: roomData.status,
      hostId: roomData.host_id,
      settings: parsedSettings,
      questions: parsedQuestions,
      currentQuestionIndex: roomData.current_question_index || 0,
      questionStartTime: qStartTime,
      timerRemaining: roomData.timer_duration_sec || 20,
      isTimerPaused: false,
      participants: participantsObj,
      feedback: feedbackObj
    };
  } catch (err) {
    console.warn('Supabase fetch quiz room notice:', err);
    return null;
  }
}

// --- PARTICIPANTS ---

export async function addParticipantToSupabase(roomId: string, p: Participant): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase || !roomId) return false;

  const cleanRoomId = roomId.trim().toUpperCase();

  try {
    // Idempotency check: check if participant with same ID or same name already exists in room
    const { data: existingRows } = await supabase
      .from('participants')
      .select('id, name')
      .eq('room_id', cleanRoomId);

    if (existingRows && existingRows.length > 0) {
      const match = existingRows.find(
        (row: any) => row.id === p.id || (row.name && row.name.toLowerCase() === p.name.trim().toLowerCase())
      );
      if (match) {
        console.log(`[QuizPulse Realtime] JOIN_DUPLICATE_PREVENTED: Participant ${p.name} (${match.id}) already exists in room ${cleanRoomId}`);
        return true;
      }
    }

    const participantPayload = {
      id: p.id,
      room_id: cleanRoomId,
      name: p.name,
      avatar: p.avatar,
      score: p.score || 0,
      streak: p.streak || 0
    };

    console.log("Add Participant Payload:", participantPayload);

    const { data, error } = await supabase
      .from('participants')
      .upsert(participantPayload)
      .select();

    if (error) {
      console.error('Error adding participant to Supabase:', error);
      return false;
    }

    console.log("Participant added returned rows:", data);
    return true;
  } catch (err) {
    console.error('Supabase add participant notice:', err);
    return false;
  }
}

// --- ANSWERS ---

export async function recordAnswerInSupabase(
  roomId: string,
  participantId: string,
  questionIndex: number,
  selectedOption: number,
  isCorrect: boolean,
  pointsAwarded: number,
  timeTakenMs: number
): Promise<boolean> {
  const supabase = getSupabase();
  if (!supabase) return false;

  try {
    const { error } = await supabase
      .from('answers')
      .insert({
        id: `ans_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        room_id: roomId,
        participant_id: participantId,
        question_index: questionIndex,
        selected_option: selectedOption,
        is_correct: isCorrect,
        points_awarded: pointsAwarded,
        time_taken_ms: timeTakenMs
      });

    if (error) {
      console.warn('Notice recording answer in Supabase:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase record answer notice:', err);
    return false;
  }
}

// --- FEEDBACK ---

export async function saveFeedbackToSupabase(
  roomId: string,
  rating: number,
  comment?: string,
  participantId?: string,
  participantName?: string,
  participantAvatar?: string
): Promise<boolean> {
  const cleanRoomId = roomId.trim().toUpperCase();
  const feedbackId = `fb_${participantId || 'anon'}_${Date.now()}`;
  const payload = {
    id: feedbackId,
    room_id: cleanRoomId,
    participant_id: participantId || null,
    participant_name: participantName || 'Anonymous Participant',
    participant_avatar: participantAvatar || '⚡',
    rating: Math.min(5, Math.max(1, rating)),
    comment: comment ? comment.trim() : null,
    created_at: new Date().toISOString()
  };

  // Always store locally as fallback
  try {
    const key = `quizpulse_feedback_${cleanRoomId}`;
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    existing.push(payload);
    localStorage.setItem(key, JSON.stringify(existing));
  } catch (e) {
    console.warn('LocalStorage save feedback notice:', e);
  }

  const supabase = getSupabase();
  if (!supabase) return true;

  try {
    const { error } = await supabase.from('quiz_feedback').upsert(payload);
    if (error) {
      console.warn('Notice saving feedback to Supabase:', error.message);
    }
    return true;
  } catch (err) {
    console.warn('Supabase save feedback exception:', err);
    return true;
  }
}

export async function fetchFeedbackForRoom(roomId: string): Promise<SessionFeedback[]> {
  const cleanRoomId = roomId.trim().toUpperCase();
  let localFeedback: SessionFeedback[] = [];

  try {
    const key = `quizpulse_feedback_${cleanRoomId}`;
    const stored = localStorage.getItem(key);
    if (stored) {
      localFeedback = JSON.parse(stored).map((item: any) => ({
        id: item.id,
        participantId: item.participant_id || item.participantId || 'anon',
        participantName: item.participant_name || item.participantName || 'Anonymous Participant',
        participantAvatar: item.participant_avatar || item.participantAvatar || '⚡',
        rating: Number(item.rating) || 5,
        comment: item.comment || undefined,
        timestamp: new Date(item.created_at || item.timestamp || Date.now()).getTime()
      }));
    }
  } catch (e) {}

  const supabase = getSupabase();
  if (!supabase) return localFeedback;

  try {
    const { data, error } = await supabase
      .from('quiz_feedback')
      .select('*')
      .eq('room_id', cleanRoomId)
      .order('created_at', { ascending: false });

    if (!error && data && data.length > 0) {
      return data.map((item: any) => ({
        id: item.id,
        participantId: item.participant_id || 'anon',
        participantName: item.participant_name || 'Anonymous Participant',
        participantAvatar: item.participant_avatar || '⚡',
        rating: Number(item.rating) || 5,
        comment: item.comment || undefined,
        timestamp: new Date(item.created_at || Date.now()).getTime()
      }));
    }
  } catch (e) {
    console.warn('Fetch feedback notice:', e);
  }

  return localFeedback;
}

// --- GAME RESULTS / HISTORY ---

export async function saveGameResultToSupabase(record: GameHistoryRecord): Promise<boolean> {
  // Always update localStorage first for fast offline/instant retrieval
  try {
    const stored = localStorage.getItem('quizpulse_game_history');
    const existing: GameHistoryRecord[] = stored ? JSON.parse(stored) : [];
    const updated = [record, ...existing.filter(h => h.id !== record.id)];
    localStorage.setItem('quizpulse_game_history', JSON.stringify(updated.slice(0, 50)));
  } catch (e) {
    console.warn('LocalStorage save history notice:', e);
  }

  const supabase = getSupabase();
  if (!supabase) return true;

  try {
    const leaderboardPayload = {
      participantsList: record.participants || [],
      fullSession: record.fullSession || null,
      questions: record.questions || record.fullSession?.questions || []
    };

    const { error } = await supabase
      .from('game_results')
      .upsert({
        id: record.id,
        room_id: record.id.replace('hist_', ''),
        title: record.title,
        participant_count: record.totalParticipants,
        leaderboard: leaderboardPayload,
        completed_at: new Date(record.timestamp || Date.now()).toISOString()
      });

    if (error) {
      console.warn('Notice saving game result to Supabase:', error);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Supabase save game result notice:', err);
    return false;
  }
}

export interface AnalyticsData {
  totalGames: number;
  totalParticipants: number;
  avgPlatformAccuracy: number;
  avgPlatformScore: number;
  avgResponseTime: number;
  highestScore: number;
  fastestResponse: number;
  avgSessionDurationSec: number;
  topRepeatWinners: Array<[string, number]>;
}

export async function fetchGameResultsFromSupabase(): Promise<GameHistoryRecord[]> {
  const supabase = getSupabase();
  if (!supabase) {
    try {
      const stored = localStorage.getItem('quizpulse_game_history');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  try {
    const historyMap = new Map<string, GameHistoryRecord>();

    // 1. Fetch from game_results table
    const { data: grData } = await supabase
      .from('game_results')
      .select('*')
      .order('completed_at', { ascending: false });

    if (grData && Array.isArray(grData)) {
      grData.forEach((row: any) => {
        let participantsList: any[] = [];
        let fullSession: GameSession | undefined = undefined;
        let questions: Question[] | undefined = undefined;

        if (row.leaderboard && typeof row.leaderboard === 'object' && !Array.isArray(row.leaderboard)) {
          participantsList = row.leaderboard.participantsList || row.leaderboard.participants || [];
          fullSession = row.leaderboard.fullSession || undefined;
          questions = row.leaderboard.questions || undefined;
        } else if (Array.isArray(row.leaderboard)) {
          participantsList = row.leaderboard;
        }

        const totalQs = row.total_questions || questions?.length || (fullSession?.questions?.length) || 10;
        const enrichedParticipants = participantsList.map((p: any, idx: number) => {
          const score = p.score || 0;
          const correctCount = p.correctCount || (p.answers ? Object.values(p.answers).filter((a: any) => a.isCorrect).length : 0);
          const totalAns = p.answers ? Object.keys(p.answers).length : (p.questionsAnswered || totalQs);
          const accuracy = p.accuracy !== undefined ? p.accuracy : (totalAns > 0 ? Math.round((correctCount / totalAns) * 100) : 0);
          const avgTime = p.avgTime || p.averageResponseTime || (p.totalResponseTime && totalAns ? Number((p.totalResponseTime / totalAns).toFixed(1)) : 0);
          return {
            ...p,
            name: p.name || 'Player',
            score,
            correctCount,
            accuracy,
            avgTime,
            rank: p.rank || (idx + 1)
          };
        });

        const sortedParticipants = [...enrichedParticipants].sort((a, b) => (b.score || 0) - (a.score || 0));
        const winnerObj = sortedParticipants[0];

        const avgScore = row.average_score || (enrichedParticipants.length ? Math.round(enrichedParticipants.reduce((s: number, p: any) => s + (p.score || 0), 0) / enrichedParticipants.length) : 0);
        const avgAccuracy = row.average_accuracy || (enrichedParticipants.length ? Math.round(enrichedParticipants.reduce((s: number, p: any) => s + (p.accuracy || 0), 0) / enrichedParticipants.length) : 0);

        historyMap.set(row.id, {
          id: row.id,
          title: row.title,
          date: new Date(row.completed_at || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          timestamp: new Date(row.completed_at || Date.now()).getTime(),
          totalParticipants: row.participant_count || enrichedParticipants.length,
          totalQuestions: totalQs,
          averageScore: avgScore,
          averageAccuracy: avgAccuracy,
          winnerName: winnerObj?.name || row.winner_name || 'N/A',
          winnerScore: winnerObj?.score || row.winner_score || 0,
          category: row.category || 'General',
          participants: enrichedParticipants,
          fullSession,
          questions
        });
      });
    }

    // 2. Fetch completed rooms from quiz_rooms or game_sessions
    let completedRooms: any[] = [];
    try {
      const { data: rooms } = await supabase
        .from('quiz_rooms')
        .select('*')
        .eq('status', 'COMPLETED');
      if (rooms && Array.isArray(rooms)) {
        completedRooms = rooms;
      }
    } catch (e) {}

    try {
      const { data: gsRooms } = await supabase
        .from('game_sessions')
        .select('*')
        .eq('status', 'COMPLETED');
      if (gsRooms && Array.isArray(gsRooms)) {
        completedRooms = [...completedRooms, ...gsRooms];
      }
    } catch (e) {}

    for (const room of completedRooms) {
      const histId = `hist_${room.id}`;
      const existingKey = historyMap.has(histId) ? histId : (historyMap.has(room.id) ? room.id : null);

      if (!existingKey) {
        let pData: any[] = [];
        try {
          const { data } = await supabase.from('participants').select('*').eq('room_id', room.id);
          if (data) pData = data;
        } catch (e) {}

        if (pData.length === 0) {
          try {
            const { data } = await supabase.from('participant_results').select('*').eq('session_id', room.id);
            if (data) pData = data;
          } catch (e) {}
        }

        let answersData: any[] = [];
        try {
          const { data } = await supabase.from('answers').select('*').eq('room_id', room.id);
          if (data) answersData = data;
        } catch (e) {}

        const parsedQuestions = Array.isArray(room.questions)
          ? room.questions
          : (typeof room.questions === 'string' ? JSON.parse(room.questions || '[]') : []);

        const totalQuestions = parsedQuestions.length || 10;

        const answersByParticipant: Record<string, any[]> = {};
        answersData.forEach((ans: any) => {
          const pid = ans.participant_id || ans.participantId;
          if (!answersByParticipant[pid]) answersByParticipant[pid] = [];
          answersByParticipant[pid].push(ans);
        });

        const rawParticipantsList = pData.map((p: any) => {
          const pAns = answersByParticipant[p.id] || [];
          const correctCount = pAns.filter((a: any) => a.is_correct || a.isCorrect).length;
          const totalAns = pAns.length;
          const accuracy = totalAns > 0 ? Math.round((correctCount / totalAns) * 100) : 0;
          const totalTimeSec = pAns.reduce((s: number, a: any) => s + ((a.time_taken_ms || a.timeTakenMs || 0) / 1000), 0);
          const avgTime = totalAns > 0 ? Number((totalTimeSec / totalAns).toFixed(1)) : 0;

          return {
            id: p.id,
            name: p.name || 'Player',
            avatar: p.avatar || '⚡',
            score: p.score || 0,
            streak: p.streak || 0,
            correctCount,
            accuracy,
            avgTime,
            totalResponseTime: totalTimeSec
          };
        }).sort((a, b) => b.score - a.score);

        const participantsList = rawParticipantsList.map((p, idx) => ({
          ...p,
          rank: idx + 1
        }));

        const winner = participantsList[0];
        const avgScore = participantsList.length ? Math.round(participantsList.reduce((s, p) => s + p.score, 0) / participantsList.length) : 0;
        const avgAccuracy = participantsList.length ? Math.round(participantsList.reduce((s, p) => s + p.accuracy, 0) / participantsList.length) : 0;

        historyMap.set(histId, {
          id: histId,
          title: room.title || 'Live Quiz Session',
          date: new Date(room.updated_at || room.created_at || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          timestamp: new Date(room.updated_at || room.created_at || Date.now()).getTime(),
          totalParticipants: participantsList.length,
          totalQuestions,
          averageScore: avgScore,
          averageAccuracy: avgAccuracy,
          winnerName: winner?.name || 'N/A',
          winnerScore: winner?.score || 0,
          category: room.category || 'General',
          participants: participantsList,
          questions: parsedQuestions
        });
      }
    }

    const records = Array.from(historyMap.values()).sort((a, b) => b.timestamp - a.timestamp);

    // Merge with localStorage records to preserve fullSession if present
    try {
      const stored = localStorage.getItem('quizpulse_game_history');
      if (stored) {
        const localRecords: GameHistoryRecord[] = JSON.parse(stored);
        const localMap = new Map(localRecords.map(r => [r.id, r]));
        return records.map(r => {
          const local = localMap.get(r.id);
          if (local) {
            return {
              ...r,
              fullSession: r.fullSession || local.fullSession,
              questions: r.questions || local.questions || local.fullSession?.questions
            };
          }
          return r;
        });
      }
    } catch (e) {}

    if (records.length > 0) {
      try {
        localStorage.setItem('quizpulse_game_history', JSON.stringify(records.slice(0, 50)));
      } catch (e) {}
    }

    return records;
  } catch (err) {
    console.warn('Supabase fetch game results notice:', err);
    try {
      const stored = localStorage.getItem('quizpulse_game_history');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }
}

export async function fetchAnalyticsFromSupabase(): Promise<AnalyticsData> {
  const supabase = getSupabase();
  const historyRecords = await fetchGameResultsFromSupabase();

  let totalGames = historyRecords.length;
  let totalParticipants = 0;
  let accuracySum = 0;
  let scoreSum = 0;
  let totalResponseTimeSum = 0;
  let responseTimeCount = 0;
  let highestScore = 0;
  let fastestResponse = 999;
  let totalDurationSecSum = 0;
  const winnerCounts: Record<string, number> = {};

  if (supabase) {
    try {
      const { data: answersData } = await supabase
        .from('answers')
        .select('is_correct, time_taken_ms');

      if (answersData && answersData.length > 0) {
        let totalTimeMs = 0;
        let validTimeCount = 0;

        answersData.forEach((ans: any) => {
          if (ans.time_taken_ms && ans.time_taken_ms > 0) {
            totalTimeMs += ans.time_taken_ms;
            validTimeCount++;
            const sec = ans.time_taken_ms / 1000;
            if (sec < fastestResponse) fastestResponse = sec;
          }
        });

        if (validTimeCount > 0) {
          totalResponseTimeSum = totalTimeMs / 1000;
          responseTimeCount = validTimeCount;
        }
      }
    } catch (e) {}

    try {
      const { data: prData } = await supabase
        .from('participant_results')
        .select('*');

      if (prData && prData.length > 0) {
        prData.forEach((pr: any) => {
          if (pr.score && pr.score > highestScore) highestScore = pr.score;
        });
      }
    } catch (e) {}
  }

  historyRecords.forEach(rec => {
    const pCount = rec.totalParticipants || (rec.participants || []).length;
    totalParticipants += pCount;
    accuracySum += rec.averageAccuracy || 0;
    scoreSum += rec.averageScore || 0;

    if (rec.participants && rec.participants.length > 0) {
      rec.participants.forEach((p: any) => {
        if (p.score && p.score > highestScore) {
          highestScore = p.score;
        }
        if (p.avgTime && p.avgTime > 0 && p.avgTime < fastestResponse) {
          fastestResponse = p.avgTime;
        }
      });
    }

    if (rec.winnerScore && rec.winnerScore > highestScore) {
      highestScore = rec.winnerScore;
    }

    totalDurationSecSum += (rec.totalQuestions || 10) * 20;

    if (rec.winnerName && rec.winnerName !== 'N/A') {
      winnerCounts[rec.winnerName] = (winnerCounts[rec.winnerName] || 0) + 1;
    }
  });

  const avgPlatformAccuracy = totalGames > 0 ? Math.round(accuracySum / totalGames) : 0;
  const avgPlatformScore = totalGames > 0 ? Math.round(scoreSum / totalGames) : 0;
  const avgResponseTime = responseTimeCount > 0 ? Number((totalResponseTimeSum / responseTimeCount).toFixed(1)) : 0;
  const validFastestResponse = fastestResponse < 999 ? Number(fastestResponse.toFixed(1)) : 0;
  const avgSessionDurationSec = totalGames > 0 ? Math.round(totalDurationSecSum / totalGames) : 0;

  const topRepeatWinners = Object.entries(winnerCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  return {
    totalGames,
    totalParticipants,
    avgPlatformAccuracy,
    avgPlatformScore,
    avgResponseTime,
    highestScore,
    fastestResponse: validFastestResponse,
    avgSessionDurationSec,
    topRepeatWinners
  };
}

export async function deleteGameResultFromSupabase(historyId: string): Promise<boolean> {
  // Always update localStorage
  try {
    const stored = localStorage.getItem('quizpulse_game_history');
    if (stored) {
      const parsed: GameHistoryRecord[] = JSON.parse(stored);
      const filtered = parsed.filter(h => h.id !== historyId);
      localStorage.setItem('quizpulse_game_history', JSON.stringify(filtered));
    }
  } catch (e) {}

  const supabase = getSupabase();
  if (!supabase) return true;

  try {
    const { error } = await supabase
      .from('game_results')
      .delete()
      .eq('id', historyId);

    if (error) {
      console.warn('Notice deleting game result in Supabase:', error);
    }
    return true;
  } catch (err) {
    console.warn('Delete game result error:', err);
    return false;
  }
}

// --- SUPABASE REALTIME SUBSCRIPTION ---

export function subscribeToSupabaseRoom(
  roomId: string,
  onRoomChange: (payload: any) => void,
  onParticipantChange: (payload: any) => void,
  onBroadcast?: (payload: any) => void
) {
  const supabase = getSupabase();
  if (!supabase) return null;

  try {
    const cleanRoomId = roomId.toUpperCase();
    const channel = supabase
      .channel(`room_${cleanRoomId}`, {
        config: {
          broadcast: { self: true }
        }
      })
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'quiz_rooms', filter: `id=eq.${cleanRoomId}` },
        onRoomChange
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'participants', filter: `room_id=eq.${cleanRoomId}` },
        onParticipantChange
      );

    if (onBroadcast) {
      channel.on('broadcast', { event: 'game_event' }, onBroadcast);
    }

    channel.subscribe((status: string) => {
      console.log(`Supabase Realtime subscription status: Connected | Subscribed | Broadcast received (${status})`);
    });

    return channel;
  } catch (err) {
    console.warn('Notice subscribing to Supabase realtime channel:', err);
    return null;
  }
}

// --- WAITLIST SUBMISSION ---
export async function submitToWaitlist(data: { full_name: string; email: string; company?: string }) {
  const supabase = getSupabase();
  if (!supabase) return { success: true };

  try {
    const { error } = await supabase.from('waitlist').insert({
      full_name: data.full_name,
      email: data.email,
      company: data.company || null,
      created_at: new Date().toISOString()
    });

    if (error) {
      console.warn('Waitlist insertion notice:', error);
      const existing = JSON.parse(localStorage.getItem('quizpulse_waitlist') || '[]');
      existing.push({ ...data, created_at: new Date().toISOString() });
      localStorage.setItem('quizpulse_waitlist', JSON.stringify(existing));
    }
    return { success: true };
  } catch (err) {
    console.warn('Waitlist submission error:', err);
    return { success: true };
  }
}
