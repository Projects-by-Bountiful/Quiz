/**
 * Quiz Room Schema Inspector & Safe Inserter
 *
 * Inspects quiz_rooms payload before insert/upsert into Supabase,
 * dynamically queries actual database columns, logs mismatched/unknown fields,
 * and prevents insertion if unknown fields exist.
 */

export interface SchemaCheckResult {
  valid: boolean;
  dbColumns: string[];
  unknownFields: string[];
  errorMessage?: string;
}

/**
 * Inspects the actual quiz_rooms table schema and compares it against roomData payload.
 */
export async function inspectQuizRoomSchema(
  supabase: any,
  roomData: Record<string, any>
): Promise<SchemaCheckResult> {
  const payloadKeys = Object.keys(roomData);
  const knownDatabaseCols = new Set<string>();
  const unknownFields: string[] = [];

  try {
    // Attempt to query an existing row to get all actual table columns in one request
    const { data: sampleRows } = await supabase.from('quiz_rooms').select('*').limit(1);
    if (sampleRows && sampleRows.length > 0) {
      Object.keys(sampleRows[0]).forEach((col) => knownDatabaseCols.add(col));
    } else {
      // Table has 0 rows: inspect each payload key against the quiz_rooms schema
      for (const key of payloadKeys) {
        const { error } = await supabase.from('quiz_rooms').select(key).limit(1);
        if (
          error &&
          (error.code === 'PGRST204' ||
            error.message.toLowerCase().includes('does not exist') ||
            error.message.includes('Could not find'))
        ) {
          unknownFields.push(key);
        } else {
          knownDatabaseCols.add(key);
        }
      }
    }

    // Check payload keys against discovered columns if columns were found via sample row
    if (knownDatabaseCols.size > 0 && unknownFields.length === 0) {
      for (const key of payloadKeys) {
        if (!knownDatabaseCols.has(key) && !unknownFields.includes(key)) {
          unknownFields.push(key);
        }
      }
    }
  } catch (err: any) {
    console.warn('Schema inspection warning:', err?.message || err);
  }

  const dbColumns = Array.from(knownDatabaseCols);

  if (unknownFields.length > 0) {
    const errorMsg = `Attempting to insert unknown fields into quiz_rooms table: ${unknownFields.join(', ')}`;
    console.error("Attempting to insert:", roomData);
    console.error("Database columns:", dbColumns);
    console.error("Unknown fields:", unknownFields);
    console.error("Error:", errorMsg);
    return {
      valid: false,
      dbColumns,
      unknownFields,
      errorMessage: errorMsg
    };
  }

  return {
    valid: true,
    dbColumns,
    unknownFields: []
  };
}

/**
 * Safely inserts or upserts a quiz_room payload into Supabase after inspecting schema and logging payload.
 */
export async function safeInsertQuizRoom(
  supabase: any,
  roomData: Record<string, any>
): Promise<{ success: boolean; data?: any; error?: string; unknownFields?: string[] }> {
  // 1. BEFORE the insert, log the payload
  console.log("Quiz Room Payload", roomData);

  // 2. Inspect table schema and compare payload
  const inspection = await inspectQuizRoomSchema(supabase, roomData);

  // 3. If payload contains fields that do not exist in the table: do not insert, log mismatched fields, display error
  if (!inspection.valid) {
    console.warn("Mismatched Fields in Quiz Room Payload:", inspection.unknownFields);
    return {
      success: false,
      error: inspection.errorMessage,
      unknownFields: inspection.unknownFields
    };
  }

  // 4. Only insert columns that exist
  const cleanPayload: Record<string, any> = {};
  for (const key of Object.keys(roomData)) {
    if (inspection.dbColumns.includes(key) || inspection.dbColumns.length === 0) {
      cleanPayload[key] = roomData[key];
    }
  }

  const { data, error } = await supabase.from('quiz_rooms').upsert(cleanPayload).select();
  if (error) {
    console.warn('Quiz Room Insert Notice:', error.message || error);
    if (error.code === '42501' || error.message?.includes('row-level security') || error.message?.includes('Row-Level Security')) {
      return {
        success: false,
        error: 'Row-Level Security violation on "quiz_rooms" table. Please run: ALTER TABLE quiz_rooms DISABLE ROW LEVEL SECURITY; in your Supabase SQL Editor.'
      };
    }
    return { success: false, error: error.message };
  }

  return { success: true, data };
}
