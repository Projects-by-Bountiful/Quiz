import { getSupabase } from './supabase';
import { HostProfile } from '../types';

export async function fetchProfileFromSupabase(userId: string): Promise<HostProfile | null> {
  const supabase = getSupabase();
  if (!supabase) return null;

  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .or(`id.eq.${userId},user_id.eq.${userId}`)
      .maybeSingle();

    if (error) {
      console.warn('Supabase profile fetch error:', error.message);
      return null;
    }

    if (data) {
      return {
        id: data.id || userId,
        user_id: data.user_id || userId,
        full_name: data.full_name || '',
        email: data.email || '',
        phone: data.phone || '',
        location: data.location || '',
        industry: data.industry || '',
        company: data.company || '',
        job_title: data.job_title || '',
        timezone: data.timezone || 'UTC',
        created_at: data.created_at,
        updated_at: data.updated_at
      };
    }
  } catch (err) {
    console.warn('Profile fetch exception:', err);
  }
  return null;
}

export async function upsertProfileInSupabase(profile: Partial<HostProfile> & { id: string, email: string }): Promise<HostProfile | null> {
  const supabase = getSupabase();
  if (!supabase) return null;

  try {
    const row = {
      id: profile.id,
      user_id: profile.id,
      full_name: profile.full_name || '',
      email: profile.email,
      phone: profile.phone || '',
      location: profile.location || '',
      industry: profile.industry || '',
      company: profile.company || '',
      job_title: profile.job_title || '',
      timezone: profile.timezone || 'UTC',
      updated_at: new Date().toISOString()
    };

    const { data, error } = await supabase
      .from('profiles')
      .upsert(row, { onConflict: 'id' })
      .select()
      .maybeSingle();

    if (error) {
      if (error.code === '42P01') {
        console.warn('Profiles table missing. Creating in memory...');
      } else {
        console.warn('Profile upsert warning:', error.message);
      }
      return {
        id: profile.id,
        user_id: profile.id,
        full_name: profile.full_name || '',
        email: profile.email,
        phone: profile.phone || '',
        location: profile.location || '',
        industry: profile.industry || '',
        company: profile.company || '',
        job_title: profile.job_title || '',
        timezone: profile.timezone || 'UTC'
      };
    }

    if (data) {
      return {
        id: data.id,
        user_id: data.user_id,
        full_name: data.full_name,
        email: data.email,
        phone: data.phone,
        location: data.location,
        industry: data.industry,
        company: data.company,
        job_title: data.job_title,
        timezone: data.timezone,
        created_at: data.created_at,
        updated_at: data.updated_at
      };
    }
  } catch (err) {
    console.warn('Profile upsert exception:', err);
  }

  return {
    id: profile.id,
    user_id: profile.id,
    full_name: profile.full_name || '',
    email: profile.email,
    phone: profile.phone || '',
    location: profile.location || '',
    industry: profile.industry || '',
    company: profile.company || '',
    job_title: profile.job_title || '',
    timezone: profile.timezone || 'UTC'
  };
}
