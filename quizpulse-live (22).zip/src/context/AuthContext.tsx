import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { getSupabase } from '../lib/supabase';
import { HostProfile } from '../types';
import { fetchProfileFromSupabase, upsertProfileInSupabase } from '../lib/authService';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: HostProfile | null;
  loading: boolean;
  isEmailVerified: boolean;
  signUpHost: (data: {
    fullName: string;
    phone: string;
    email: string;
    password: string;
    location: string;
    industry: string;
    company?: string;
    jobTitle?: string;
  }) => Promise<{ success: boolean; error?: string; requiresEmailVerification?: boolean }>;
  signInHost: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOutHost: () => Promise<void>;
  resendVerification: () => Promise<{ success: boolean; error?: string }>;
  sendPasswordResetEmail: (email: string) => Promise<{ success: boolean; error?: string }>;
  resetPassword: (newPassword: string) => Promise<{ success: boolean; error?: string }>;
  refreshAuth: () => Promise<void>;
  updateHostProfile: (updates: Partial<HostProfile>) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<HostProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const supabase = getSupabase();

  const loadUserData = async (currentUser: User | null) => {
    if (!currentUser) {
      setUser(null);
      setProfile(null);
      return;
    }

    setUser(currentUser);

    // Fetch profile from database
    let prof = await fetchProfileFromSupabase(currentUser.id);

    // If profile row doesn't exist yet, automatically create it
    if (!prof && currentUser.email) {
      const meta = currentUser.user_metadata || {};
      prof = await upsertProfileInSupabase({
        id: currentUser.id,
        email: currentUser.email,
        full_name: meta.full_name || meta.fullName || currentUser.email.split('@')[0],
        phone: meta.phone || '',
        location: meta.location || '',
        industry: meta.industry || '',
        company: meta.company || '',
        job_title: meta.job_title || meta.jobTitle || '',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
      });
    }

    setProfile(prof);
  };

  useEffect(() => {
    if (!supabase) {
      // Mock fallback state if Supabase isn't configured
      setLoading(false);
      return;
    }

    // Initial session check
    supabase.auth.getSession().then(({ data: { session: initSession } }) => {
      setSession(initSession);
      if (initSession?.user) {
        loadUserData(initSession.user).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      setSession(newSession);
      if (newSession?.user) {
        await loadUserData(newSession.user);
      } else {
        setUser(null);
        setProfile(null);
      }
      setLoading(false);
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const isEmailVerified = Boolean(
    user?.email_confirmed_at || 
    user?.confirmed_at || 
    (user?.app_metadata as any)?.provider === 'google' ||
    !supabase // If no supabase, bypass for preview fallback
  );

  const signUpHost: AuthContextType['signUpHost'] = async (data) => {
    if (!supabase) {
      // Fallback local registration
      const mockId = `host_${Date.now()}`;
      const mockProfile: HostProfile = {
        id: mockId,
        user_id: mockId,
        full_name: data.fullName,
        email: data.email,
        phone: data.phone,
        location: data.location,
        industry: data.industry,
        company: data.company || '',
        job_title: data.jobTitle || '',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
      };
      setProfile(mockProfile);
      return { success: true, requiresEmailVerification: true };
    }

    try {
      const { data: authData, error } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            full_name: data.fullName,
            phone: data.phone,
            location: data.location,
            industry: data.industry,
            company: data.company,
            job_title: data.jobTitle
          },
          emailRedirectTo: `${window.location.origin}/#verify`
        }
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (authData.user) {
        // Save to profiles table immediately
        const createdProf = await upsertProfileInSupabase({
          id: authData.user.id,
          email: data.email,
          full_name: data.fullName,
          phone: data.phone,
          location: data.location,
          industry: data.industry,
          company: data.company || '',
          job_title: data.jobTitle || '',
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
        });
        setProfile(createdProf);
        setUser(authData.user);
      }

      const requiresVerification = !authData.user?.email_confirmed_at;
      return { success: true, requiresEmailVerification: requiresVerification };
    } catch (err: any) {
      return { success: false, error: err.message || 'Signup failed' };
    }
  };

  const signInHost: AuthContextType['signInHost'] = async (email, password) => {
    if (!supabase) {
      // Fallback local signin
      const mockProfile: HostProfile = {
        id: 'host_local',
        user_id: 'host_local',
        full_name: 'Verified Host',
        email,
        location: 'Global',
        industry: 'Technology'
      };
      setProfile(mockProfile);
      return { success: true };
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        await loadUserData(data.user);
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Authentication failed' };
    }
  };

  const signOutHost = async () => {
    if (supabase) {
      await supabase.auth.signOut();
    }
    setUser(null);
    setSession(null);
    setProfile(null);
  };

  const resendVerification = async () => {
    if (!supabase || !user?.email) {
      return { success: true };
    }

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: user.email
      });

      if (error) {
        return { success: false, error: error.message };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Resend failed' };
    }
  };

  const sendPasswordResetEmail = async (email: string) => {
    if (!supabase) {
      return { success: true };
    }

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`
      });

      if (error) {
        return { success: false, error: error.message };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to send reset email' };
    }
  };

  const resetPassword = async (newPassword: string) => {
    if (!supabase) {
      return { success: true };
    }

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) {
        return { success: false, error: error.message };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to reset password' };
    }
  };

  const refreshAuth = async () => {
    if (!supabase) return;
    const { data } = await supabase.auth.getUser();
    if (data?.user) {
      await loadUserData(data.user);
    }
  };

  const updateHostProfile: AuthContextType['updateHostProfile'] = async (updates) => {
    if (!user && !profile) {
      return { success: false, error: 'User not logged in' };
    }

    const currentEmail = user?.email || profile?.email || '';
    const userId = user?.id || profile?.id || 'host_local';

    const merged = {
      ...profile,
      ...updates,
      id: userId,
      email: currentEmail
    };

    const savedProf = await upsertProfileInSupabase(merged);
    if (savedProf) {
      setProfile(savedProf);
      return { success: true };
    }
    return { success: false, error: 'Failed to save profile' };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        loading,
        isEmailVerified,
        signUpHost,
        signInHost,
        signOutHost,
        resendVerification,
        sendPasswordResetEmail,
        resetPassword,
        refreshAuth,
        updateHostProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
