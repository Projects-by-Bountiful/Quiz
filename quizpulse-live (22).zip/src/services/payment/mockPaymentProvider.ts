import { IPaymentProvider, InitializePaymentParams, PaymentInitResult, PaymentVerificationResult } from './types';
import { calculateGamePrice, CURRENCY_CODE } from '../../config/pricingConfig';

/**
 * MockPaymentProvider
 *
 * Simulates a realistic payment lifecycle for QuizPulse Pay-As-You-Go games
 * without calling real payment gateways. Designed to be swapped with Paystack/Flutterwave
 * without modifying UI or game launch callers.
 */
export class MockPaymentProvider implements IPaymentProvider {
  readonly name = 'mock' as const;
  readonly isMock = true;

  async initializePayment(params: InitializePaymentParams): Promise<PaymentInitResult> {
    const { hostId, quizTitle, playerCapacity } = params;

    // Server-side authoritative price calculation
    const priceInfo = calculateGamePrice(playerCapacity);
    if (!priceInfo.isValidCapacity) {
      throw new Error(priceInfo.errorMessage || 'Invalid player capacity specified.');
    }

    // Generate standard mock payment reference
    const timestamp = Date.now();
    const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const reference = `QP_MOCK_${playerCapacity}P_${timestamp}_${randomSuffix}`;

    return {
      reference,
      amount: priceInfo.price,
      currency: CURRENCY_CODE,
      provider: this.name,
      quizTitle: quizTitle || 'Live Quiz Event',
      playerCapacity
    };
  }

  async verifyPayment(
    reference: string,
    expectedCapacity: number,
    simulateFailure: boolean = false
  ): Promise<PaymentVerificationResult> {
    // Artificial latency to reflect realistic network verification
    await new Promise((resolve) => setTimeout(resolve, 600));

    const priceInfo = calculateGamePrice(expectedCapacity);

    if (simulateFailure) {
      return {
        success: false,
        reference,
        amount: priceInfo.price,
        currency: CURRENCY_CODE,
        playerCapacity: expectedCapacity,
        status: 'FAILED',
        error: 'Simulated payment failure: Transaction was declined by mock gateway.'
      };
    }

    return {
      success: true,
      reference,
      amount: priceInfo.price,
      currency: CURRENCY_CODE,
      playerCapacity: expectedCapacity,
      status: 'SUCCESS'
    };
  }
}
