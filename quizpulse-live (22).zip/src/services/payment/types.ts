/**
 * Payment & Entitlement Abstraction Types for QuizPulse
 */

export type PaymentProviderType = 'mock' | 'paystack' | 'flutterwave' | 'stripe';

export type PaymentStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'CANCELLED' | 'REFUNDED';

export type EntitlementStatus = 'ACTIVE' | 'USED' | 'EXPIRED';

export interface PaymentRecord {
  id: string;
  host_id: string;
  quiz_title: string;
  quiz_id?: string;
  room_id?: string;
  reference: string;
  provider: PaymentProviderType;
  amount: number;
  currency: string;
  status: PaymentStatus;
  player_capacity: number;
  metadata?: Record<string, any>;
  created_at: string;
  paid_at?: string;
  error_message?: string;
}

export interface GameEntitlement {
  id: string;
  host_id: string;
  quiz_title: string;
  player_capacity: number;
  amount_paid: number;
  currency: string;
  payment_reference: string;
  provider: PaymentProviderType;
  status: EntitlementStatus;
  created_at: string;
  used_at?: string;
  used_for_room_id?: string;
}

export interface InitializePaymentParams {
  hostId: string;
  hostEmail?: string;
  hostName?: string;
  quizTitle: string;
  playerCapacity: number;
  metadata?: Record<string, any>;
}

export interface PaymentInitResult {
  reference: string;
  amount: number;
  currency: string;
  provider: PaymentProviderType;
  quizTitle: string;
  playerCapacity: number;
  requiresRedirect?: boolean;
  redirectUrl?: string;
}

export interface PaymentVerificationResult {
  success: boolean;
  reference: string;
  amount: number;
  currency: string;
  playerCapacity: number;
  status: PaymentStatus;
  error?: string;
  entitlement?: GameEntitlement;
}

/**
 * Standard Payment Provider interface to facilitate plugging in Paystack,
 * Flutterwave, Stripe, or Mock providers without changing checkout logic.
 */
export interface IPaymentProvider {
  readonly name: PaymentProviderType;
  readonly isMock: boolean;
  
  initializePayment(params: InitializePaymentParams): Promise<PaymentInitResult>;
  
  verifyPayment(
    reference: string,
    expectedCapacity: number,
    simulateFailure?: boolean
  ): Promise<PaymentVerificationResult>;
}
