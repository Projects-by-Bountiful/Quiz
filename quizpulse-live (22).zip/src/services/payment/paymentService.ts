import { IPaymentProvider, PaymentProviderType, PaymentRecord, GameEntitlement, InitializePaymentParams, PaymentInitResult, PaymentVerificationResult, PaymentStatus } from './types';
import { MockPaymentProvider } from './mockPaymentProvider';
import { calculateGamePrice, CURRENCY_CODE } from '../../config/pricingConfig';
import { getSupabase } from '../../lib/supabase';

// Current active payment provider mode
export const PAYMENT_MODE: PaymentProviderType = 'mock';

// Storage keys for resilient fallback
const PAYMENTS_STORAGE_KEY = 'quizpulse_host_payments';
const ENTITLEMENTS_STORAGE_KEY = 'quizpulse_game_entitlements';

class PaymentService {
  private activeProvider: IPaymentProvider;

  constructor() {
    this.activeProvider = new MockPaymentProvider();
  }

  public getProvider(): IPaymentProvider {
    return this.activeProvider;
  }

  public setProvider(provider: IPaymentProvider) {
    this.activeProvider = provider;
  }

  /**
   * Initializes a game payment session with the active provider
   */
  async initializeGamePayment(params: InitializePaymentParams): Promise<PaymentInitResult> {
    const initResult = await this.activeProvider.initializePayment(params);

    // Record the pending transaction
    const initialPaymentRecord: PaymentRecord = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      host_id: params.hostId,
      quiz_title: params.quizTitle,
      reference: initResult.reference,
      provider: initResult.provider,
      amount: initResult.amount,
      currency: initResult.currency,
      status: 'PENDING',
      player_capacity: params.playerCapacity,
      metadata: params.metadata || {},
      created_at: new Date().toISOString()
    };

    await this.savePaymentRecord(initialPaymentRecord);
    return initResult;
  }

  /**
   * Verifies payment with the active provider and generates a game entitlement upon success
   */
  async verifyAndUnlockGame(
    reference: string,
    params: InitializePaymentParams,
    simulateFailure: boolean = false
  ): Promise<PaymentVerificationResult> {
    const verification = await this.activeProvider.verifyPayment(
      reference,
      params.playerCapacity,
      simulateFailure
    );

    if (verification.success && verification.status === 'SUCCESS') {
      // 1. Create durable Game Entitlement
      const entitlement: GameEntitlement = {
        id: `ent_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        host_id: params.hostId,
        quiz_title: params.quizTitle,
        player_capacity: params.playerCapacity,
        amount_paid: verification.amount,
        currency: verification.currency,
        payment_reference: reference,
        provider: this.activeProvider.name,
        status: 'ACTIVE',
        created_at: new Date().toISOString()
      };

      await this.saveEntitlement(entitlement);
      verification.entitlement = entitlement;

      // 2. Update payment status to SUCCESS
      await this.updatePaymentStatus(reference, 'SUCCESS', new Date().toISOString());
    } else {
      // Update payment status to FAILED
      await this.updatePaymentStatus(reference, 'FAILED', undefined, verification.error);
    }

    return verification;
  }

  /**
   * Validates if a host has an active entitlement for the specified game & capacity
   */
  async validateEntitlementForLaunch(
    hostId: string,
    playerCapacity: number,
    entitlementId?: string
  ): Promise<{ valid: boolean; entitlement?: GameEntitlement; error?: string }> {
    // 0–5 players is always free and valid
    if (playerCapacity <= 5) {
      return { valid: true };
    }

    const entitlements = await this.getHostEntitlements(hostId);
    
    // Find active matching entitlement
    let matching: GameEntitlement | undefined;
    if (entitlementId) {
      matching = entitlements.find(e => e.id === entitlementId && e.status === 'ACTIVE');
    } else {
      matching = entitlements.find(
        e => e.status === 'ACTIVE' && e.player_capacity >= playerCapacity
      );
    }

    if (!matching) {
      return {
        valid: false,
        error: `No valid payment entitlement found for a ${playerCapacity}-player game. Please complete payment checkout.`
      };
    }

    return {
      valid: true,
      entitlement: matching
    };
  }

  /**
   * Marks an entitlement as USED once the room is created and launched
   */
  async markEntitlementUsed(entitlementId: string, roomId: string): Promise<boolean> {
    const supabase = getSupabase();
    const now = new Date().toISOString();

    // 1. Update Supabase if available
    if (supabase) {
      try {
        await supabase
          .from('game_entitlements')
          .update({ status: 'USED', used_at: now, used_for_room_id: roomId })
          .eq('id', entitlementId);
      } catch (e) {
        // Continue to fallback
      }
    }

    // 2. Update LocalStorage fallback
    try {
      const stored = this.getLocalEntitlements();
      const idx = stored.findIndex(e => e.id === entitlementId);
      if (idx !== -1) {
        stored[idx].status = 'USED';
        stored[idx].used_at = now;
        stored[idx].used_for_room_id = roomId;
        localStorage.setItem(ENTITLEMENTS_STORAGE_KEY, JSON.stringify(stored));
      }
    } catch (e) {}

    return true;
  }

  /**
   * Retrieves all payment records for a host (combines database & local store)
   */
  async fetchHostPayments(hostId: string): Promise<PaymentRecord[]> {
    const supabase = getSupabase();
    let dbPayments: PaymentRecord[] = [];

    if (supabase && hostId) {
      try {
        const { data, error } = await supabase
          .from('payments')
          .select('*')
          .eq('host_id', hostId)
          .order('created_at', { ascending: false });

        if (!error && data) {
          dbPayments = data;
        }
      } catch (err) {
        console.warn('Supabase fetch payments notice:', err);
      }
    }

    const localPayments = this.getLocalPayments().filter(p => !hostId || p.host_id === hostId);

    // Merge and deduplicate by reference
    const seenRefs = new Set<string>();
    const merged: PaymentRecord[] = [];

    [...dbPayments, ...localPayments].forEach(pay => {
      if (!seenRefs.has(pay.reference)) {
        seenRefs.add(pay.reference);
        merged.push(pay);
      }
    });

    return merged.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  // --- Internal Persistence Helpers ---

  private async savePaymentRecord(record: PaymentRecord): Promise<void> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('payments').upsert(record);
      } catch (e) {
        console.warn('Notice saving payment to Supabase table:', e);
      }
    }

    // Always keep resilient local backup
    try {
      const stored = this.getLocalPayments();
      const existingIdx = stored.findIndex(p => p.reference === record.reference);
      if (existingIdx >= 0) {
        stored[existingIdx] = record;
      } else {
        stored.unshift(record);
      }
      localStorage.setItem(PAYMENTS_STORAGE_KEY, JSON.stringify(stored.slice(0, 100)));
    } catch (e) {}
  }

  private async updatePaymentStatus(
    reference: string,
    status: PaymentStatus,
    paidAt?: string,
    errorMessage?: string
  ): Promise<void> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        const updatePayload: any = { status };
        if (paidAt) updatePayload.paid_at = paidAt;
        if (errorMessage) updatePayload.error_message = errorMessage;

        await supabase
          .from('payments')
          .update(updatePayload)
          .eq('reference', reference);
      } catch (e) {}
    }

    try {
      const stored = this.getLocalPayments();
      const p = stored.find(item => item.reference === reference);
      if (p) {
        p.status = status;
        if (paidAt) p.paid_at = paidAt;
        if (errorMessage) p.error_message = errorMessage;
        localStorage.setItem(PAYMENTS_STORAGE_KEY, JSON.stringify(stored));
      }
    } catch (e) {}
  }

  private async saveEntitlement(entitlement: GameEntitlement): Promise<void> {
    const supabase = getSupabase();
    if (supabase) {
      try {
        await supabase.from('game_entitlements').upsert(entitlement);
      } catch (e) {
        console.warn('Notice saving entitlement to Supabase table:', e);
      }
    }

    try {
      const stored = this.getLocalEntitlements();
      stored.unshift(entitlement);
      localStorage.setItem(ENTITLEMENTS_STORAGE_KEY, JSON.stringify(stored.slice(0, 100)));
    } catch (e) {}
  }

  private async getHostEntitlements(hostId: string): Promise<GameEntitlement[]> {
    const supabase = getSupabase();
    let dbEntitlements: GameEntitlement[] = [];

    if (supabase && hostId) {
      try {
        const { data, error } = await supabase
          .from('game_entitlements')
          .select('*')
          .eq('host_id', hostId);

        if (!error && data) {
          dbEntitlements = data;
        }
      } catch (e) {}
    }

    const localEntitlements = this.getLocalEntitlements().filter(e => !hostId || e.host_id === hostId);

    const map = new Map<string, GameEntitlement>();
    [...dbEntitlements, ...localEntitlements].forEach(ent => {
      map.set(ent.id, ent);
    });

    return Array.from(map.values());
  }

  private getLocalPayments(): PaymentRecord[] {
    try {
      const raw = localStorage.getItem(PAYMENTS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  private getLocalEntitlements(): GameEntitlement[] {
    try {
      const raw = localStorage.getItem(ENTITLEMENTS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }
}

export const paymentService = new PaymentService();
