import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ParticipantJoin } from './components/ParticipantJoin';
import { WaitingRoom } from './components/WaitingRoom';
import { QuestionView } from './components/QuestionView';
import { LeaderboardView } from './components/LeaderboardView';
import { ResultsView } from './components/ResultsView';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { SignupPage } from './components/SignupPage';
import { EmailVerificationPage } from './components/EmailVerificationPage';
import { ForgotPasswordPage } from './components/ForgotPasswordPage';
import { ResetPasswordPage } from './components/ResetPasswordPage';
import { HostWorkspace } from './components/HostWorkspace';
import { PresenterModeView } from './components/PresenterModeView';
import { SupabaseDiagnosticModal } from './components/SupabaseDiagnosticModal';

import { AuthProvider, useAuth } from './context/AuthContext';
import { useRealtimeSession } from './utils/useRealtimeSession';
import { Question, GameHistoryRecord, GameSession, Role, Category, DEFAULT_CATEGORIES } from './types';
import { SAMPLE_QUESTIONS } from './data/sampleQuestions';
import { supabase } from './utils/supabase';
import {
  fetchQuestionsFromSupabase,
  saveQuestionsBulkToSupabase,
  saveQuizRoomToSupabase,
  fetchQuizRoomFromSupabase,
  fetchGameResultsFromSupabase,
  deleteQuestionFromSupabase,
  deleteQuestionsBulkFromSupabase
} from './lib/supabaseService';
import { getParticipantJoinUrl } from './utils/url';

function MainApp() {
  const { user, profile, isEmailVerified, loading: authLoading } = useAuth();

  const [currentView, setCurrentView] = useState<Role>('landing');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isHostMobileDrawerOpen, setIsHostMobileDrawerOpen] = useState<boolean>(false);
  
  const [questions, setQuestions] = useState<Question[]>(SAMPLE_QUESTIONS);
  const [categories, setCategories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [history, setHistory] = useState<GameHistoryRecord[]>([]);
  const [isDiagnosticOpen, setIsDiagnosticOpen] = useState<boolean>(false);

  // Check URL query param or route for auto-join code
  const [initialJoinCode, setInitialJoinCode] = useState<string>('');

  const {
    session,
    participantId,
    connectionStatus,
    showBackOnlineToast,
    errorMessage,
    reactions,
    connect,
    submitAnswer,
    submitFeedback,
    sendReaction,
    hostAction,
    setSession
  } = useRealtimeSession();

  const isHostAuthenticated = Boolean(user || profile);

  // Sync browser URL bar without page reload
  const updateUrlPath = (path: string) => {
    if (typeof window !== 'undefined' && window.location.pathname !== path) {
      window.history.pushState(null, '', path);
    }
  };

  // Safe view selector with Route Protection
  const handleSelectView = (requestedView: Role) => {
    // If user tries to access protected host view without auth -> redirect to login
    if (requestedView.startsWith('host_') && !isHostAuthenticated) {
      setCurrentView('login');
      updateUrlPath('/login');
      return;
    }

    // If authenticated user goes to login or signup -> redirect to host_dashboard
    if ((requestedView === 'login' || requestedView === 'signup') && isHostAuthenticated) {
      if (!isEmailVerified) {
        setCurrentView('verify-email');
        updateUrlPath('/verify-email');
        return;
      }
      console.log('[QuizPulse] Workspace navigation → /host');
      setCurrentView('host_dashboard');
      updateUrlPath('/host');
      return;
    }

    if (requestedView === 'host_dashboard') {
      console.log('[QuizPulse] Workspace navigation → /host');
    }

    setIsHostMobileDrawerOpen(false);
    setCurrentView(requestedView);

    if (requestedView === 'landing') updateUrlPath('/');
    else if (requestedView === 'participant') updateUrlPath(session?.id ? `/join/${session.id}` : '/join');
    else if (requestedView === 'login') updateUrlPath('/login');
    else if (requestedView === 'signup') updateUrlPath('/signup');
    else if (requestedView === 'verify-email') updateUrlPath('/verify-email');
    else if (requestedView === 'forgot-password') updateUrlPath('/forgot-password');
    else if (requestedView === 'reset-password') updateUrlPath('/reset-password');
    else if (requestedView === 'host_dashboard') updateUrlPath('/host');
    else if (requestedView.startsWith('host_')) updateUrlPath(`/host/${requestedView.replace('host_', '')}`);
  };

  // Parse deep-linked path /host/:roomId, /join/:roomId, /results/:roomId or ?code=
  const parseCurrentUrl = async () => {
    if (typeof window === 'undefined') return;

    const pathname = window.location.pathname;
    const hash = window.location.hash;
    const searchParams = new URLSearchParams(window.location.search);
    const codeParam = searchParams.get('code');

    // Password reset callback detection from Supabase link
    if (pathname === '/reset-password' || hash.includes('reset-password') || hash.includes('type=recovery')) {
      handleSelectView('reset-password');
      return;
    }

    if (pathname === '/forgot-password') {
      handleSelectView('forgot-password');
      return;
    }

    // Case 1: /host or /host/*
    if (pathname === '/host' || pathname === '/host/' || pathname.startsWith('/host/')) {
      const rest = pathname.replace(/^\/host\/?/, '');
      const parts = rest ? rest.split('/') : [];
      const subRoute = parts[0]?.toLowerCase();

      if (['dashboard', 'questions', 'categories', 'quizzes', 'participants', 'analytics', 'history', 'profile', 'settings'].includes(subRoute)) {
        if (subRoute === 'dashboard') {
          console.log('[QuizPulse] Workspace navigation → /host');
          handleSelectView('host_dashboard');
        } else {
          handleSelectView(`host_${subRoute}` as Role);
        }
      } else if (parts[0] && parts[0].length >= 4 && isHostAuthenticated) {
        // Room ID
        const roomId = parts[0].toUpperCase();
        console.log('[QuizPulse] Workspace navigation → /host');
        handleSelectView('host_dashboard');
        connect(roomId, 'Host', true);
      } else {
        console.log('[QuizPulse] Workspace navigation → /host');
        handleSelectView('host_dashboard');
      }
    }
    // Case 2: /join/:roomId OR ?code=
    else if (pathname.startsWith('/join/') || codeParam) {
      const roomId = (
        pathname.startsWith('/join/')
          ? pathname.replace('/join/', '').split('/')[0].trim()
          : codeParam || ''
      ).toUpperCase();

      if (roomId) {
        setInitialJoinCode(roomId);
        handleSelectView('participant');
        if (pathname !== `/join/${roomId}`) {
          updateUrlPath(`/join/${roomId}`);
        }

        // Auto-resume existing participant session if saved in localStorage
        try {
          const savedParticipantRaw = localStorage.getItem(`quizpulse_participant_${roomId}`);
          if (savedParticipantRaw) {
            const savedParticipant = JSON.parse(savedParticipantRaw);
            if (savedParticipant?.name) {
              console.log('[QuizPulse Realtime] RECONNECT: Auto-resuming participant session from storage', {
                roomId,
                participantId: savedParticipant.participantId,
                name: savedParticipant.name
              });
              connect(roomId, savedParticipant.name, false);
            }
          }
        } catch (e) {
          console.warn('Notice parsing saved participant state:', e);
        }
      } else {
        handleSelectView('participant');
      }
    }
    // Case 3: /login or /signup
    else if (pathname === '/login') {
      handleSelectView('login');
    } else if (pathname === '/signup') {
      handleSelectView('signup');
    }
    // Case 4: Root path or standard view
    else {
      if (pathname === '/' || pathname === '') {
        handleSelectView('landing');
      }
    }
  };

  // Load questions and history on mount, parse deep link routes
  useEffect(() => {
    const loadDataAsynchronously = async () => {
      try {
        const [sbQuestions, sbHistory] = await Promise.all([
          fetchQuestionsFromSupabase(),
          fetchGameResultsFromSupabase()
        ]);

        if (sbQuestions && sbQuestions.length > 0) {
          setQuestions(sbQuestions);
          const extraCats = Array.from(new Set(sbQuestions.map((q: Question) => q.category)));
          setCategories(prev => Array.from(new Set([...prev, ...extraCats])));
        } else {
          // Seed initial sample questions into Supabase if empty
          setQuestions(SAMPLE_QUESTIONS);
          saveQuestionsBulkToSupabase(SAMPLE_QUESTIONS);
        }

        if (sbHistory) {
          setHistory(sbHistory);
        }
      } catch (err) {
        console.warn('Async workspace initial load error:', err);
      }
    };

    loadDataAsynchronously();

    parseCurrentUrl();

    const handlePopState = () => {
      parseCurrentUrl();
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Category Handlers
  const handleAddCategory = (categoryName: string) => {
    if (!categories.includes(categoryName)) {
      setCategories(prev => [...prev, categoryName]);
    }
  };

  const handleDeleteCategory = (categoryName: string) => {
    setCategories(prev => prev.filter(c => c !== categoryName));
    setQuestions(prev => prev.filter(q => q.category !== categoryName));
  };

  // Question Handlers
  const handleAddQuestion = async (newQ: Question) => {
    setQuestions(prev => [newQ, ...prev]);

    if (supabase) {
      try {
        await supabase.from('questions').upsert({
          id: newQ.id,
          question: newQ.question,
          options: newQ.options,
          correct_answer: newQ.correctAnswer,
          category: newQ.category,
          difficulty: newQ.difficulty,
          explanation: newQ.explanation || ''
        });
      } catch (err) {
        console.error('Supabase handleAddQuestion error:', err);
      }
    }
  };

  const handleUpdateQuestion = async (updatedQ: Question) => {
    setQuestions(prev => prev.map(q => q.id === updatedQ.id ? updatedQ : q));

    if (supabase) {
      try {
        await supabase.from('questions').upsert({
          id: updatedQ.id,
          question: updatedQ.question,
          options: updatedQ.options,
          correct_answer: updatedQ.correctAnswer,
          category: updatedQ.category,
          difficulty: updatedQ.difficulty,
          explanation: updatedQ.explanation || ''
        });
      } catch (err) {
        console.error('Supabase handleUpdateQuestion error:', err);
      }
    }
  };

  const handleDeleteQuestion = async (id: string) => {
    console.log('[QuizPulse] Delete question requested');
    console.log('[QuizPulse] Question ID:', id);
    console.log('[QuizPulse] Supabase delete started');

    const success = await deleteQuestionFromSupabase(id);
    if (success) {
      console.log('[QuizPulse] Supabase delete successful');
    } else {
      console.warn('[QuizPulse] Supabase delete notice, synchronizing local question state');
    }
    setQuestions(prev => prev.filter(q => q.id !== id));
    console.log('[QuizPulse] Local question state updated');
  };

  const handleImportQuestions = async (imported: Question[]): Promise<{ success: boolean; count: number; error?: string }> => {
    if (!imported || imported.length === 0) {
      return { success: false, count: 0, error: 'No questions provided' };
    }

    console.log('Questions Ready:', imported);

    // 1. Write to Supabase first
    const saveRes = await saveQuestionsBulkToSupabase(imported);
    console.log('[SUPABASE DIAGNOSTIC] Questions inserted result:', saveRes);

    if (!saveRes.success) {
      console.error('[SUPABASE DIAGNOSTIC] Question import failed:', saveRes.error);
      if (saveRes.error?.includes('Row-Level Security') || saveRes.error?.includes('row-level security')) {
        setIsDiagnosticOpen(true);
      }
      return { success: false, count: 0, error: saveRes.error || 'Failed to save questions to Supabase' };
    }

    // 2. Fetch fresh list directly from Supabase to verify and reload
    const sbQuestions = await fetchQuestionsFromSupabase();
    console.log('[SUPABASE DIAGNOSTIC] Reloaded Questions from Supabase:', sbQuestions.length);

    if (sbQuestions && sbQuestions.length > 0) {
      setQuestions(sbQuestions);
      const extraCats = Array.from(new Set(sbQuestions.map((q: Question) => q.category)));
      setCategories(prev => Array.from(new Set([...prev, ...extraCats])));
    }

    return { success: true, count: saveRes.count || imported.length };
  };

  const handleBulkDeleteQuestions = async (ids: string[]) => {
    if (!ids || ids.length === 0) return;
    console.log('[QuizPulse] Bulk delete questions requested:', ids.length);
    console.log('[QuizPulse] Supabase delete started');

    const success = await deleteQuestionsBulkFromSupabase(ids);
    if (success) {
      console.log('[QuizPulse] Supabase delete successful');
    }
    const idSet = new Set(ids);
    setQuestions(prev => prev.filter(q => !idSet.has(q.id)));
    console.log('[QuizPulse] Local question state updated');
  };

  const handleMoveQuestionsCategory = async (ids: string[], newCategory: Category) => {
    const idSet = new Set(ids);
    setQuestions(prev => prev.map(q => idSet.has(q.id) ? { ...q, category: newCategory } : q));

    if (supabase && ids.length > 0) {
      try {
        await supabase.from('questions').update({ category: newCategory }).in('id', ids);
      } catch (err) {
        console.error('Supabase handleMoveQuestionsCategory error:', err);
      }
    }
  };

  const generateRoomCode = (): string => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  // Host creates new game session directly in Supabase
  const handleCreateSession = async (title: string, settings: any, selectedQuestionIds?: string[]) => {
    try {
      console.log('[QuizPulse] Creating room');
      const roomId = generateRoomCode();
      const joinUrl = getParticipantJoinUrl(roomId);
      console.log('[QuizPulse] Room created');
      console.log('[QuizPulse] Room code:', roomId);
      console.log('[QuizPulse] Join URL:', joinUrl);
      
      // Question selection and strict category filtering
      let sessionQuestions: Question[] = [];

      if (selectedQuestionIds && selectedQuestionIds.length > 0) {
        // Manual hand-picked selection
        sessionQuestions = questions.filter(q => selectedQuestionIds.includes(q.id));
      } else if (settings?.categories && Array.isArray(settings.categories) && settings.categories.length > 0) {
        // Host selected specific category or categories
        const categoryPool = questions.filter(q => settings.categories.includes(q.category));
        
        if (categoryPool.length === 0) {
          alert(`No questions found for the selected category: ${settings.categories.join(', ')}. Please add questions or select a different category.`);
          return;
        }

        let pool = [...categoryPool];
        if (settings.isRandom) {
          pool.sort(() => Math.random() - 0.5);
        }

        const count = settings.questionCount && settings.questionCount > 0 ? settings.questionCount : 10;
        sessionQuestions = pool.slice(0, count);

        // Strict category validation
        const outOfCategory = sessionQuestions.filter(q => !settings.categories.includes(q.category));
        if (outOfCategory.length > 0) {
          console.error('[QuizPulse] Category validation error: Found questions from unselected categories', outOfCategory);
          sessionQuestions = sessionQuestions.filter(q => settings.categories.includes(q.category));
        }
      } else {
        // Standard question bank slice
        let pool = [...questions];
        if (settings?.isRandom) {
          pool.sort(() => Math.random() - 0.5);
        }
        sessionQuestions = pool.slice(0, settings?.questionCount || 10);
      }

      if (sessionQuestions.length === 0) {
        sessionQuestions = SAMPLE_QUESTIONS.slice(0, 10);
      }

      // Verify authenticated user context
      let authUser: any = null;
      if (supabase) {
        try {
          const { data } = await supabase.auth.getUser();
          authUser = data?.user;
        } catch (e) {
          console.warn('Auth getUser notice:', e);
        }
      }

      const hostUserId = authUser?.id || user?.id || profile?.id || 'host_' + Math.random().toString(36).substring(2, 8);

      const newSession: GameSession = {
        id: roomId,
        title: title || 'Live Quiz Session',
        createdAt: Date.now(),
        status: 'LOBBY',
        hostId: hostUserId,
        settings: settings || {
          timerDurationSec: 20,
          showLeaderboardAfterEach: true,
          shuffleQuestions: false,
          allowLateJoin: true
        },
        questions: sessionQuestions,
        currentQuestionIndex: 0,
        questionStartTime: Date.now(),
        timerRemaining: settings?.timerDurationSec || 20,
        isTimerPaused: false,
        participants: {}
      };

      console.log('[QuizPulse] QR generated');
      const savedResult = await saveQuizRoomToSupabase(newSession);
      console.log('[QuizPulse] Room persisted', savedResult);

      if (!savedResult.success) {
        console.error('[SUPABASE DIAGNOSTIC] Quiz Room creation failed:', savedResult.error);
        if (savedResult.error?.includes('Row-Level Security') || savedResult.error?.includes('row-level security')) {
          setIsDiagnosticOpen(true);
        }
        alert(`Failed to save Quiz Room to Supabase:\n${savedResult.error || 'Database insert failed'}`);
        return;
      }

      console.log('Launching session ID:', roomId);
      connect(roomId, 'Host', true, newSession);
      handleSelectView('host_quizzes');
    } catch (err: any) {
      console.error('Notice creating quiz room:', err);
      alert('Failed to create quiz room: ' + (err?.message || err));
    }
  };

  const handleParticipantJoin = (code: string, name: string) => {
    const cleanCode = code.trim().toUpperCase();
    connect(cleanCode, name, false);
    updateUrlPath(`/join/${cleanCode}`);
  };

  const isHostRole = session ? session.hostId === participantId || currentView.startsWith('host_') : currentView.startsWith('host_');

  // Gameplay view renderer
  const renderGameContent = () => {
    if (!session) return null;

    switch (session.status) {
      case 'LOBBY':
        return (
          <WaitingRoom
            session={session}
            isHost={isHostRole}
            participantId={participantId}
            onStartGame={() => hostAction('START_GAME')}
            onSendReaction={(emoji) => sendReaction(emoji, session.participants[participantId || '']?.name || 'Player')}
            reactions={reactions}
          />
        );
      case 'QUESTION':
      case 'ANSWER_REVEAL':
        return (
          <QuestionView
            session={session}
            isHost={isHostRole}
            participantId={participantId}
            onSubmitAnswer={submitAnswer}
            onHostAction={hostAction}
            soundEnabled={soundEnabled}
            connectionStatus={connectionStatus}
            showBackOnlineToast={showBackOnlineToast}
          />
        );
      case 'LEADERBOARD':
        return (
          <LeaderboardView
            session={session}
            isHost={isHostRole}
            onHostAction={hostAction}
            soundEnabled={soundEnabled}
          />
        );
      case 'ENDED':
        return (
          <ResultsView
            session={session}
            isHost={isHostRole}
            onHostAction={hostAction}
            onNewGame={() => {
              setSession(null);
              handleSelectView('host_dashboard');
            }}
            soundEnabled={soundEnabled}
            onSubmitFeedback={submitFeedback}
          />
        );
      default:
        return null;
    }
  };

  // Dedicated Full-Viewport App Shell for Authenticated Host Workspace (height: 100dvh)
  if (currentView.startsWith('host_') && !session) {
    return (
      <div className="h-[100dvh] max-h-[100dvh] bg-slate-950 font-sans text-slate-100 selection:bg-yellow-400 selection:text-slate-950 flex flex-col overflow-hidden">
        
        {/* Fixed Top Navbar (h-[68px] flex-shrink-0) */}
        <Navbar
          currentRole={currentView}
          onSelectRole={handleSelectView}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled(prev => !prev)}
          activeSessionCode={session?.id}
          onOpenDiagnostic={() => setIsDiagnosticOpen(true)}
          onToggleHostMobileDrawer={() => setIsHostMobileDrawerOpen(prev => !prev)}
          isHostMobileDrawerOpen={isHostMobileDrawerOpen}
        />

        {/* Full-Viewport Body Workspace (Remaining height: 100dvh - 68px) */}
        <div className="flex-1 min-h-0 min-w-0 flex flex-row overflow-hidden relative">
          <HostWorkspace
            currentTab={currentView}
            onSelectTab={handleSelectView}
            questions={questions}
            categories={categories}
            activeSession={session}
            historyRecords={history}
            onCreateQuestion={handleAddQuestion}
            onUpdateQuestion={handleUpdateQuestion}
            onDeleteQuestion={handleDeleteQuestion}
            onBulkDeleteQuestions={handleBulkDeleteQuestions}
            onMoveQuestionsCategory={handleMoveQuestionsCategory}
            onBulkImport={handleImportQuestions}
            onCreateCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
            onCreateSession={handleCreateSession}
            onOpenSession={(sId) => connect(sId, 'Host', true)}
            onDeleteHistoryRecord={(id) => setHistory(prev => prev.filter(h => h.id !== id))}
            onOpenDiagnostic={() => setIsDiagnosticOpen(true)}
            isMobileDrawerOpen={isHostMobileDrawerOpen}
            onCloseMobileDrawer={() => setIsHostMobileDrawerOpen(false)}
          />
        </div>

        {/* Database Diagnostic Modal */}
        <SupabaseDiagnosticModal
          isOpen={isDiagnosticOpen}
          onClose={() => setIsDiagnosticOpen(false)}
        />

      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 selection:bg-yellow-400 selection:text-slate-950 flex flex-col justify-between">
      
      <div>
        {/* Public Navigation Header */}
        <Navbar
          currentRole={currentView}
          onSelectRole={handleSelectView}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled(prev => !prev)}
          activeSessionCode={session?.id}
          onOpenDiagnostic={() => setIsDiagnosticOpen(true)}
        />

        {/* Main View Area */}
        <main>
          {session ? (
            renderGameContent()
          ) : (
            <>
              {currentView === 'landing' && (
                <LandingPage
                  onHostGameClick={() => handleSelectView('signup')}
                  onJoinGameClick={() => handleSelectView('participant')}
                />
              )}

              {currentView === 'participant' && (
                <ParticipantJoin
                  onJoin={handleParticipantJoin}
                  errorMessage={errorMessage}
                  initialCode={initialJoinCode}
                  onQuickHost={() => handleSelectView('signup')}
                />
              )}

              {currentView === 'login' && (
                <LoginPage
                  onNavigateToSignup={() => handleSelectView('signup')}
                  onNavigateToForgotPassword={() => handleSelectView('forgot-password')}
                  onLoginSuccess={() => handleSelectView('host_dashboard')}
                />
              )}

              {currentView === 'signup' && (
                <SignupPage
                  onNavigateToLogin={() => handleSelectView('login')}
                  onSignupSuccess={() => handleSelectView('verify-email')}
                />
              )}

              {currentView === 'verify-email' && (
                <EmailVerificationPage
                  onVerified={() => handleSelectView('host_dashboard')}
                />
              )}

              {currentView === 'forgot-password' && (
                <ForgotPasswordPage
                  onNavigateToLogin={() => handleSelectView('login')}
                />
              )}

              {currentView === 'reset-password' && (
                <ResetPasswordPage
                  onNavigateToLogin={() => handleSelectView('login')}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Database Diagnostic Modal */}
      <SupabaseDiagnosticModal
        isOpen={isDiagnosticOpen}
        onClose={() => setIsDiagnosticOpen(false)}
      />

      {/* Public Footer */}
      {!currentView.startsWith('host_') && <Footer />}

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
