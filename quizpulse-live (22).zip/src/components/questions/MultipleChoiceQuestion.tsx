import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Lock } from 'lucide-react';
import { Question } from '../../types';

interface MultipleChoiceQuestionProps {
  question: Question;
  selectedOption: number | null;
  onSelectOption: (optionIndex: number) => void;
  disabled: boolean;
  isHost: boolean;
}

export const MultipleChoiceQuestion: React.FC<MultipleChoiceQuestionProps> = ({
  question,
  selectedOption,
  onSelectOption,
  disabled,
  isHost
}) => {
  const options = question.options || ['Option A', 'Option B', 'Option C', 'Option D'];

  const optionStyles = [
    { letter: 'A', bg: 'bg-blue-900/40 hover:bg-blue-800/60 border-blue-500/40 text-blue-100 ring-blue-400/50', badge: 'bg-blue-500 text-white' },
    { letter: 'B', bg: 'bg-rose-900/40 hover:bg-rose-800/60 border-rose-500/40 text-rose-100 ring-rose-400/50', badge: 'bg-rose-500 text-white' },
    { letter: 'C', bg: 'bg-amber-900/40 hover:bg-amber-800/60 border-amber-500/40 text-amber-100 ring-amber-400/50', badge: 'bg-amber-500 text-slate-950 font-black' },
    { letter: 'D', bg: 'bg-emerald-900/40 hover:bg-emerald-800/60 border-emerald-500/40 text-emerald-100 ring-emerald-400/50', badge: 'bg-emerald-500 text-white' }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 w-full">
      {options.map((optionText, idx) => {
        const style = optionStyles[idx % optionStyles.length];
        const isSelected = selectedOption === idx;

        return (
          <motion.button
            key={idx}
            id={`mc-option-${idx}`}
            whileHover={!disabled && !isHost ? { scale: 1.015 } : {}}
            whileTap={!disabled && !isHost ? { scale: 0.985 } : {}}
            onClick={() => onSelectOption(idx)}
            disabled={disabled || isHost}
            className={`w-full min-h-[5rem] sm:min-h-[5.5rem] p-4 sm:p-5 rounded-2xl sm:rounded-3xl border-2 transition-all flex items-center justify-between text-left relative overflow-hidden backdrop-blur-md ${
              isSelected
                ? `${style.bg} border-amber-400 ring-4 ring-amber-400/40 shadow-xl shadow-amber-400/10`
                : `${style.bg} border-slate-700/60 text-slate-200`
            } ${disabled && !isSelected ? 'opacity-60 cursor-not-allowed' : ''} ${
              isHost ? 'cursor-default' : 'cursor-pointer active:scale-95'
            }`}
          >
            <div className="flex items-center space-x-3.5 sm:space-x-4 pr-2">
              <span className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl flex items-center justify-center font-black text-sm sm:text-base flex-shrink-0 shadow-md ${style.badge}`}>
                {style.letter}
              </span>
              <span className="text-sm sm:text-base md:text-lg font-bold text-white leading-snug">
                {optionText}
              </span>
            </div>

            {isSelected && (
              <span className="flex-shrink-0 ml-2 px-2.5 py-1 bg-amber-400 text-slate-950 rounded-xl text-xs font-black flex items-center space-x-1 shadow">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">SELECTED</span>
              </span>
            )}
          </motion.button>
        );
      })}
    </div>
  );
};
