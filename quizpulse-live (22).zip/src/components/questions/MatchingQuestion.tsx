import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Link2, CheckCircle2, RotateCcw, ArrowRightLeft, Sparkles, Unlink } from 'lucide-react';
import { Question, MatchingPair } from '../../types';

interface MatchingQuestionProps {
  question: Question;
  submittedMatches: Record<string, string> | null;
  onSubmitMatches: (matches: Record<string, string>) => void;
  disabled: boolean;
  isHost: boolean;
}

const PAIR_COLORS = [
  { bg: 'bg-purple-500/20 border-purple-400 text-purple-200', tag: 'bg-purple-500 text-white' },
  { bg: 'bg-blue-500/20 border-blue-400 text-blue-200', tag: 'bg-blue-500 text-white' },
  { bg: 'bg-emerald-500/20 border-emerald-400 text-emerald-200', tag: 'bg-emerald-500 text-slate-950 font-bold' },
  { bg: 'bg-amber-500/20 border-amber-400 text-amber-200', tag: 'bg-amber-500 text-slate-950 font-bold' },
  { bg: 'bg-rose-500/20 border-rose-400 text-rose-200', tag: 'bg-rose-500 text-white' }
];

export const MatchingQuestion: React.FC<MatchingQuestionProps> = ({
  question,
  submittedMatches,
  onSubmitMatches,
  disabled,
  isHost
}) => {
  const pairs: MatchingPair[] = question.matchingPairs || [];
  
  // Left items are in order, Right items are shuffled
  const [leftItems] = useState(() => pairs.map(p => ({ id: p.id, text: p.left })));
  const [rightItems] = useState(() => {
    const rights = pairs.map(p => ({ id: p.id, text: p.right }));
    if (isHost) return rights;
    return [...rights].sort((a, b) => ((a.text.length * 3 + 7) % 5) - ((b.text.length * 3 + 7) % 5));
  });

  // Current selections & matches
  const [selectedLeftId, setSelectedLeftId] = useState<string | null>(null);
  const [matches, setMatches] = useState<Record<string, string>>(submittedMatches || {}); // leftId -> rightId

  const isSubmitted = Boolean(submittedMatches && Object.keys(submittedMatches).length > 0);

  const handleLeftClick = (leftId: string) => {
    if (disabled || isHost || isSubmitted) return;
    if (selectedLeftId === leftId) {
      setSelectedLeftId(null);
    } else {
      setSelectedLeftId(leftId);
    }
  };

  const handleRightClick = (rightId: string) => {
    if (disabled || isHost || isSubmitted) return;
    if (!selectedLeftId) return;

    // Check if right item is already assigned to another left item and detach it
    setMatches(prev => {
      const copy = { ...prev };
      // Remove any existing left mapped to this rightId
      Object.keys(copy).forEach(lId => {
        if (copy[lId] === rightId) delete copy[lId];
      });
      copy[selectedLeftId] = rightId;
      return copy;
    });

    setSelectedLeftId(null);
  };

  const handleUnlinkMatch = (leftId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (disabled || isHost || isSubmitted) return;
    setMatches(prev => {
      const copy = { ...prev };
      delete copy[leftId];
      return copy;
    });
  };

  const handleFinalSubmit = () => {
    if (disabled || isHost || isSubmitted) return;
    onSubmitMatches(matches);
  };

  const matchedCount = Object.keys(matches).length;
  const allMatched = matchedCount === pairs.length && pairs.length > 0;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-4">
      {/* Header instructions */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md">
        <div className="flex items-center space-x-2 text-purple-300 text-xs sm:text-sm font-bold">
          <ArrowRightLeft className="w-4 h-4 text-purple-400" />
          <span>Tap an item on the left, then tap its matching pair on the right</span>
        </div>
        <div className="text-xs text-purple-200 font-bold bg-purple-500/20 px-3 py-1 rounded-xl border border-purple-400/30">
          Matched: {matchedCount} / {pairs.length}
        </div>
      </div>

      {/* Two Column Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* LEFT COLUMN: Prompts */}
        <div className="space-y-2.5">
          <div className="text-xs font-black uppercase tracking-wider text-slate-400 px-2 flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-purple-400 inline-block"></span>
            <span>Terms / Items</span>
          </div>

          {leftItems.map((left, idx) => {
            const isSelected = selectedLeftId === left.id;
            const pairedRightId = matches[left.id];
            const pairColor = PAIR_COLORS[idx % PAIR_COLORS.length];

            return (
              <motion.button
                key={left.id}
                type="button"
                whileHover={!disabled && !isHost ? { scale: 1.01 } : {}}
                whileTap={!disabled && !isHost ? { scale: 0.99 } : {}}
                onClick={() => handleLeftClick(left.id)}
                disabled={disabled || isHost || isSubmitted}
                className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center justify-between relative backdrop-blur-md ${
                  isSelected
                    ? 'border-purple-400 bg-purple-900/40 ring-4 ring-purple-400/30 text-white'
                    : pairedRightId
                    ? `${pairColor.bg} border-2`
                    : 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:border-slate-500'
                } ${isSubmitted ? 'cursor-default' : ''}`}
              >
                <div className="flex items-center space-x-3 pr-2">
                  <span className="w-7 h-7 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center text-xs font-black flex-shrink-0">
                    {idx + 1}
                  </span>
                  <span className="text-sm sm:text-base font-bold text-white leading-snug">
                    {left.text}
                  </span>
                </div>

                {pairedRightId && (
                  <div className="flex items-center space-x-2 flex-shrink-0 ml-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-md font-black uppercase tracking-wider ${pairColor.tag}`}>
                      Linked
                    </span>
                    {!isSubmitted && !disabled && (
                      <span
                        onClick={(e) => handleUnlinkMatch(left.id, e)}
                        className="p-1 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 rounded-md transition-all cursor-pointer"
                        title="Unlink match"
                      >
                        <Unlink className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* RIGHT COLUMN: Targets */}
        <div className="space-y-2.5">
          <div className="text-xs font-black uppercase tracking-wider text-slate-400 px-2 flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 inline-block"></span>
            <span>Matches / Definitions</span>
          </div>

          {rightItems.map((right, idx) => {
            // Find which left is matched to this right
            const matchedLeftId = Object.keys(matches).find(lId => matches[lId] === right.id);
            const matchedLeftIdx = leftItems.findIndex(l => l.id === matchedLeftId);
            const pairColor = matchedLeftIdx !== -1 ? PAIR_COLORS[matchedLeftIdx % PAIR_COLORS.length] : null;

            return (
              <motion.button
                key={right.id}
                type="button"
                whileHover={!disabled && !isHost && selectedLeftId ? { scale: 1.01 } : {}}
                whileTap={!disabled && !isHost && selectedLeftId ? { scale: 0.99 } : {}}
                onClick={() => handleRightClick(right.id)}
                disabled={disabled || isHost || isSubmitted || (!selectedLeftId && !matchedLeftId)}
                className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center justify-between relative backdrop-blur-md ${
                  pairColor
                    ? `${pairColor.bg} border-2`
                    : selectedLeftId
                    ? 'bg-slate-900/90 border-slate-700 hover:border-purple-400 text-slate-200 cursor-pointer'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400'
                } ${isSubmitted ? 'cursor-default' : ''}`}
              >
                <div className="flex items-center space-x-3 pr-2">
                  <span className="w-7 h-7 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center text-xs font-black flex-shrink-0">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="text-sm sm:text-base font-bold text-white leading-snug">
                    {right.text}
                  </span>
                </div>

                {pairColor && matchedLeftIdx !== -1 && (
                  <span className={`flex-shrink-0 ml-2 text-[10px] px-2 py-0.5 rounded-md font-black uppercase tracking-wider ${pairColor.tag}`}>
                    Item {matchedLeftIdx + 1}
                  </span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Submission CTA */}
      {!isHost && (
        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={handleFinalSubmit}
            disabled={disabled || isSubmitted || matchedCount === 0}
            className={`w-full sm:w-auto py-3.5 px-8 rounded-2xl font-black text-sm flex items-center justify-center space-x-2 transition-all ${
              isSubmitted
                ? 'bg-purple-500 text-white cursor-default shadow-lg shadow-purple-500/20'
                : matchedCount > 0 && !disabled
                ? 'bg-purple-400 hover:bg-purple-300 text-slate-950 shadow-xl shadow-purple-400/25 active:scale-95'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {isSubmitted ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>MATCHES SUBMITTED</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>SUBMIT ALL MATCHES ({matchedCount}/{pairs.length})</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
