import React, { useState, useEffect, useRef } from 'react';
import { motion, Reorder } from 'motion/react';
import { ArrowUp, ArrowDown, GripVertical, CheckCircle2, RotateCcw, ListOrdered } from 'lucide-react';
import { Question } from '../../types';

interface OrderingQuestionProps {
  question: Question;
  submittedOrder: number[] | null;
  onSubmitOrder: (orderIndices: number[]) => void;
  disabled: boolean;
  isHost: boolean;
}

interface OrderItemObject {
  originalIndex: number;
  text: string;
}

export const OrderingQuestion: React.FC<OrderingQuestionProps> = ({
  question,
  submittedOrder,
  onSubmitOrder,
  disabled,
  isHost
}) => {
  const originalItems: string[] = question.orderItems && question.orderItems.length > 0
    ? question.orderItems
    : (question.options || []);

  const [items, setItems] = useState<OrderItemObject[]>(() => {
    if (submittedOrder && Array.isArray(submittedOrder)) {
      return submittedOrder.map(origIdx => ({
        originalIndex: origIdx,
        text: originalItems[origIdx] || `Item ${origIdx + 1}`
      }));
    }
    // Deterministic pseudo-shuffle for fresh question
    const initialized = originalItems.map((text, idx) => ({ originalIndex: idx, text }));
    if (isHost) return initialized;
    // Reverse/scramble so user starts with scrambled list
    return [...initialized].sort((a, b) => ((a.originalIndex * 7 + 3) % originalItems.length) - ((b.originalIndex * 7 + 3) % originalItems.length));
  });

  const isSubmitted = Boolean(submittedOrder && Array.isArray(submittedOrder) && submittedOrder.length > 0);

  const moveItem = (index: number, direction: 'up' | 'down') => {
    if (disabled || isHost || isSubmitted) return;
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= items.length) return;

    setItems(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy;
    });
  };

  const handleFinalSubmit = () => {
    if (disabled || isHost || isSubmitted) return;
    const orderIndices = items.map(it => it.originalIndex);
    onSubmitOrder(orderIndices);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Header instructions */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md">
        <div className="flex items-center space-x-2 text-cyan-300 text-xs sm:text-sm font-bold">
          <ListOrdered className="w-4 h-4 text-cyan-400" />
          <span>Arrange items in correct sequence (Top = 1st, Bottom = Last)</span>
        </div>
        {!isHost && !isSubmitted && (
          <span className="text-xs text-slate-400 font-semibold hidden sm:inline">
            Use arrows or drag to reorder
          </span>
        )}
      </div>

      {/* Items List */}
      <div className="space-y-2.5">
        {items.map((item, idx) => (
          <motion.div
            key={item.originalIndex}
            layout
            className={`p-3.5 sm:p-4 rounded-2xl border-2 transition-all flex items-center justify-between backdrop-blur-md ${
              isSubmitted
                ? 'bg-cyan-950/40 border-cyan-400/60 text-slate-200'
                : 'bg-slate-900/90 border-slate-700/80 text-white hover:border-slate-500'
            }`}
          >
            {/* Left: Position Rank Number & Text */}
            <div className="flex items-center space-x-3.5 pr-2 flex-1">
              <span className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 flex items-center justify-center font-black text-sm flex-shrink-0">
                {idx + 1}
              </span>
              <span className="text-sm sm:text-base font-bold text-slate-100 leading-snug">
                {item.text}
              </span>
            </div>

            {/* Right: Up / Down Accessible Action Buttons */}
            {!isHost && !isSubmitted && !disabled && (
              <div className="flex items-center space-x-1.5 flex-shrink-0 ml-2">
                <button
                  type="button"
                  onClick={() => moveItem(idx, 'up')}
                  disabled={idx === 0}
                  aria-label="Move item up"
                  className={`p-2 rounded-xl border transition-all ${
                    idx === 0
                      ? 'opacity-30 border-slate-800 text-slate-600 cursor-not-allowed'
                      : 'border-slate-700 bg-slate-800 hover:bg-cyan-500/20 hover:border-cyan-400 text-slate-200 active:scale-95'
                  }`}
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => moveItem(idx, 'down')}
                  disabled={idx === items.length - 1}
                  aria-label="Move item down"
                  className={`p-2 rounded-xl border transition-all ${
                    idx === items.length - 1
                      ? 'opacity-30 border-slate-800 text-slate-600 cursor-not-allowed'
                      : 'border-slate-700 bg-slate-800 hover:bg-cyan-500/20 hover:border-cyan-400 text-slate-200 active:scale-95'
                  }`}
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Submission CTA */}
      {!isHost && (
        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={handleFinalSubmit}
            disabled={disabled || isSubmitted}
            className={`w-full sm:w-auto py-3.5 px-8 rounded-2xl font-black text-sm flex items-center justify-center space-x-2 transition-all ${
              isSubmitted
                ? 'bg-cyan-500 text-slate-950 cursor-default shadow-lg shadow-cyan-500/20'
                : !disabled
                ? 'bg-cyan-400 hover:bg-cyan-300 text-slate-950 shadow-xl shadow-cyan-400/25 active:scale-95'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {isSubmitted ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>ORDER SUBMITTED</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>SUBMIT FINAL ORDER</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
