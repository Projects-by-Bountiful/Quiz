import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Send, CheckCircle2, CornerDownLeft, Sparkles, HelpCircle } from 'lucide-react';
import { Question } from '../../types';

interface FillBlankQuestionProps {
  question: Question;
  submittedAnswer: string | null;
  onSubmitAnswer: (text: string) => void;
  disabled: boolean;
  isHost: boolean;
}

export const FillBlankQuestion: React.FC<FillBlankQuestionProps> = ({
  question,
  submittedAnswer,
  onSubmitAnswer,
  disabled,
  isHost
}) => {
  const [inputText, setInputText] = useState<string>(submittedAnswer || '');

  useEffect(() => {
    if (submittedAnswer !== null) {
      setInputText(submittedAnswer);
    }
  }, [submittedAnswer]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (disabled || isHost) return;
    if (!inputText.trim()) return;
    onSubmitAnswer(inputText.trim());
  };

  const isSubmitted = submittedAnswer !== null && submittedAnswer !== undefined && submittedAnswer.length > 0;

  return (
    <div className="w-full max-w-2xl mx-auto space-y-5">
      {/* Visual representation of the prompt with highlighted blank indicator */}
      <div className="p-4 sm:p-5 bg-slate-900/80 border border-slate-800 rounded-2xl sm:rounded-3xl backdrop-blur-md">
        <div className="flex items-center space-x-2 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Type your answer to fill the missing blank</span>
        </div>
        <p className="text-sm sm:text-base text-slate-300 font-medium leading-relaxed">
          {question.question.includes('___') ? (
            <span>
              {question.question.split(/_{2,}/).map((part, i, arr) => (
                <React.Fragment key={i}>
                  {part}
                  {i < arr.length - 1 && (
                    <span className="inline-block px-3 py-0.5 mx-1 bg-emerald-500/20 border-b-2 border-emerald-400 text-emerald-300 font-bold rounded">
                      {isSubmitted ? (submittedAnswer || '...') : ' ? '}
                    </span>
                  )}
                </React.Fragment>
              ))}
            </span>
          ) : (
            question.question
          )}
        </p>
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="relative">
          <input
            id="fill-blank-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={disabled || isHost}
            placeholder={isHost ? "Participants type their answer here..." : "Type your answer here..."}
            autoComplete="off"
            autoFocus={!isHost && !disabled}
            className={`w-full py-4 sm:py-5 pl-5 pr-32 bg-slate-900/90 border-2 rounded-2xl sm:rounded-3xl text-base sm:text-lg font-bold text-white placeholder-slate-500 focus:outline-none transition-all ${
              isSubmitted
                ? 'border-emerald-400/80 ring-4 ring-emerald-400/20 bg-emerald-950/30'
                : 'border-slate-700 focus:border-emerald-400 focus:ring-4 focus:ring-emerald-400/20'
            } ${disabled ? 'opacity-70 cursor-not-allowed' : ''}`}
          />

          {!isHost && (
            <button
              type="submit"
              disabled={disabled || !inputText.trim() || isSubmitted}
              className={`absolute right-2.5 top-2.5 bottom-2.5 px-4 sm:px-6 rounded-xl sm:rounded-2xl font-black text-sm flex items-center space-x-2 transition-all ${
                isSubmitted
                  ? 'bg-emerald-500 text-slate-950 cursor-default'
                  : inputText.trim() && !disabled
                  ? 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-lg shadow-emerald-400/30 active:scale-95'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {isSubmitted ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="hidden sm:inline">SUBMITTED</span>
                </>
              ) : (
                <>
                  <span>SUBMIT</span>
                  <CornerDownLeft className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          )}
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 px-2 font-medium">
          <span>Answers are not case-sensitive (e.g. "Invoice" = "invoice")</span>
          <span className="hidden sm:inline">Press Enter ↵ to submit</span>
        </div>
      </form>
    </div>
  );
};
