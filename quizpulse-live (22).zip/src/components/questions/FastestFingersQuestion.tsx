import React from 'react';
import { motion } from 'motion/react';
import { Zap, Flame, CheckCircle2 } from 'lucide-react';
import { Question, FASTEST_FINGER_FORMAT_LABELS } from '../../types';

interface FastestFingersQuestionProps {
  question: Question;
  selectedOption: number | null;
  onSelectOption: (optionIndex: number) => void;
  disabled: boolean;
  isHost: boolean;
}

export const FastestFingersQuestion: React.FC<FastestFingersQuestionProps> = ({
  question,
  selectedOption,
  onSelectOption,
  disabled,
  isHost
}) => {
  // Fastest Fingers always has exactly two options: Option A (index 0) and Option B (index 1)
  const rawOpts = question.options && question.options.length >= 2 ? question.options : ['TRUE', 'FALSE'];
  const options = rawOpts.slice(0, 2);

  const formatLabel = question.fastestFingerFormat 
    ? FASTEST_FINGER_FORMAT_LABELS[question.fastestFingerFormat] 
    : undefined;

  const choicesStyles = [
    {
      letter: 'A',
      label: 'OPTION A',
      bg: 'bg-amber-500/15 hover:bg-amber-500/25 border-amber-500/50 text-amber-100',
      badge: 'bg-amber-400 text-slate-950',
      activeRing: 'ring-4 ring-amber-400/50 bg-amber-400/30 border-amber-300 shadow-2xl shadow-amber-400/20'
    },
    {
      letter: 'B',
      label: 'OPTION B',
      bg: 'bg-cyan-500/15 hover:bg-cyan-500/25 border-cyan-500/50 text-cyan-100',
      badge: 'bg-cyan-400 text-slate-950',
      activeRing: 'ring-4 ring-cyan-400/50 bg-cyan-400/30 border-cyan-300 shadow-2xl shadow-cyan-400/20'
    }
  ];

  return (
    <div className="space-y-4 w-full">
      {/* Rapid Fire Banner */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-cyan-500/20 border border-amber-400/40 rounded-2xl">
        <div className="flex items-center space-x-2 text-amber-300 text-xs sm:text-sm font-black uppercase tracking-wider">
          <Zap className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
          <span>Fastest Fingers • Two-Choice Rapid Response (Up to +1500 PTS)</span>
        </div>
        {formatLabel && (
          <span className="hidden sm:inline-block px-2.5 py-0.5 bg-slate-950/80 border border-amber-400/40 text-amber-300 font-extrabold text-[11px] rounded-lg uppercase tracking-wider">
            {formatLabel}
          </span>
        )}
      </div>

      {/* Exactly 2 Rapid-Response Choices */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {options.map((optionText, idx) => {
          const style = choicesStyles[idx] || choicesStyles[0];
          const isSelected = selectedOption === idx;
          const isLocked = selectedOption !== null;

          return (
            <motion.button
              key={idx}
              id={`ff-option-${idx}`}
              whileHover={!disabled && !isHost && !isLocked ? { scale: 1.02 } : {}}
              whileTap={!disabled && !isHost && !isLocked ? { scale: 0.98 } : {}}
              onClick={() => {
                if (!disabled && !isHost && selectedOption === null) {
                  onSelectOption(idx);
                }
              }}
              disabled={disabled || isHost || isLocked}
              className={`w-full min-h-[6rem] sm:min-h-[7rem] p-5 sm:p-6 rounded-3xl border-2 transition-all flex items-center justify-between text-left relative overflow-hidden backdrop-blur-md select-none ${
                isSelected
                  ? style.activeRing
                  : `${style.bg} border-slate-700/60`
              } ${disabled && !isSelected ? 'opacity-50 cursor-not-allowed' : ''} ${
                isHost ? 'cursor-default' : isLocked ? 'cursor-default' : 'cursor-pointer'
              }`}
            >
              <div className="flex items-center space-x-4 pr-2">
                <span className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl flex-shrink-0 shadow-lg ${style.badge}`}>
                  {style.letter}
                </span>
                <div>
                  <span className="text-xs font-black opacity-60 uppercase tracking-widest block mb-0.5">
                    {style.label}
                  </span>
                  <span className="text-xl sm:text-2xl font-black text-white leading-snug tracking-tight">
                    {optionText}
                  </span>
                </div>
              </div>

              {isSelected && (
                <span className="flex-shrink-0 ml-2 px-3.5 py-1.5 bg-amber-400 text-slate-950 rounded-xl text-xs font-black flex items-center space-x-1.5 shadow-lg animate-bounce">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>LOCKED IN</span>
                </span>
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
