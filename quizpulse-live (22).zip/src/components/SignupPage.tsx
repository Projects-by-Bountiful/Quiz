import React, { useState } from 'react';
import { Mail, User, Briefcase, Sparkles, ArrowRight, CheckCircle2, AlertCircle, Clock } from 'lucide-react';
import { submitToWaitlist } from '../lib/supabaseService';

interface SignupPageProps {
  onNavigateToLogin: () => void;
  onSignupSuccess?: () => void;
}

export const SignupPage: React.FC<SignupPageProps> = ({
  onNavigateToLogin
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim() || !email.trim()) {
      setErrorMsg('Full name and email address are required.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    setLoading(true);

    const res = await submitToWaitlist({
      full_name: fullName.trim(),
      email: email.trim(),
      company: company.trim()
    });

    setLoading(false);

    if (res.success) {
      setIsSubmitted(true);
    } else {
      setErrorMsg('Failed to join waitlist. Please try again.');
    }
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white flex items-center justify-center p-4 sm:p-6 md:p-10 font-sans">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8 relative overflow-hidden">
        
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-yellow-400/10 rounded-full blur-3xl pointer-events-none" />
        
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 bg-yellow-400/10 border border-yellow-400/30 rounded-full text-yellow-400 text-xs font-black uppercase tracking-widest">
            <Clock className="w-3.5 h-3.5" />
            <span>Coming Soon</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Coming Soon
          </h1>
          <p className="text-sm text-slate-300 font-semibold max-w-md mx-auto leading-relaxed">
            We're preparing something exciting. Leave your details and we'll notify you when registrations open.
          </p>
        </div>

        {isSubmitted ? (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-6 text-center space-y-4">
            <div className="w-12 h-12 bg-emerald-400 text-slate-950 rounded-2xl mx-auto flex items-center justify-center font-black">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-black text-white">You're on the list!</h3>
            <p className="text-xs text-slate-300 font-semibold">
              Thank you for signing up. We'll send an update to <span className="text-yellow-400 font-bold">{email}</span> as soon as host registration opens.
            </p>
            <button
              onClick={onNavigateToLogin}
              className="mt-2 px-6 py-3 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all"
            >
              Back to Host Login
            </button>
          </div>
        ) : (
          <>
            {errorMsg && (
              <div className="bg-rose-500/10 border border-rose-500/30 rounded-2xl p-4 text-rose-400 text-xs font-bold flex items-center space-x-3">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Full Name */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="w-5 h-5 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    placeholder="Jane Doe"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 pl-11 pr-4 text-sm font-semibold text-white placeholder-slate-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Email Address */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="w-5 h-5 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    placeholder="jane@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 pl-11 pr-4 text-sm font-semibold text-white placeholder-slate-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Company (Optional) */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Company (Optional)
                </label>
                <div className="relative">
                  <Briefcase className="w-5 h-5 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    placeholder="Acme Corp"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 pl-11 pr-4 text-sm font-semibold text-white placeholder-slate-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-base rounded-2xl shadow-xl shadow-yellow-400/20 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {loading ? (
                  <span>Submitting Details...</span>
                ) : (
                  <>
                    <span>NOTIFY ME WHEN OPEN</span>
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>
          </>
        )}

        <div className="text-center pt-4 border-t border-slate-800">
          <p className="text-xs text-slate-400 font-semibold">
            Already have an active host account?{' '}
            <button
              type="button"
              onClick={onNavigateToLogin}
              className="text-yellow-400 hover:underline font-extrabold ml-1"
            >
              Log In Here
            </button>
          </p>
        </div>

      </div>
    </div>
  );
};


