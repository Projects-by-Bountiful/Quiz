import React, { useState, useEffect } from 'react';
import { 
  Zap, Play, Plus, BookOpen, Users, Sliders, Shield, ArrowRight, Radio, 
  Bookmark, Trash2, Eye, Sparkles, Layers, Clock
} from 'lucide-react';
import { GameSession, Question, Category } from '../types';
import { QuizCreationWizardModal, QuizTemplate } from './QuizCreationWizardModal';
import { ParticipantQuestionPreviewModal } from './ParticipantQuestionPreviewModal';

interface HostDashboardProps {
  activeSession: GameSession | null;
  questions: Question[];
  onCreateSession: (title: string, settings: any, selectedQuestionIds?: string[]) => void;
  onOpenSession: (sessionId: string) => void;
  onOpenQuestionBank: () => void;
}

const DEFAULT_TEMPLATES: QuizTemplate[] = [
  {
    id: 'preset_speed',
    name: '⚡ Speed Round (10s Blitz)',
    description: 'Fast-paced 10-second countdowns with +50 max speed bonus points',
    title: 'Speed Round Blitz',
    timerDurationSec: 10,
    questionCount: 10,
    isRandom: true,
    enableBonusSpeedPoints: true,
    allowAnswerChange: false,
    showCorrectAnswer: true,
    enableLeaderboard: true,
    categories: [],
    createdAt: Date.now()
  },
  {
    id: 'preset_trivia',
    name: '🧠 Team Trivia (20s Standard)',
    description: 'Classic 20-second trivia format for general knowledge & tech',
    title: 'Team Trivia Night',
    timerDurationSec: 20,
    questionCount: 10,
    isRandom: true,
    enableBonusSpeedPoints: true,
    allowAnswerChange: false,
    showCorrectAnswer: true,
    enableLeaderboard: true,
    categories: [],
    createdAt: Date.now()
  },
  {
    id: 'preset_mastermind',
    name: '🏆 Mastermind Challenge (30s Deep Think)',
    description: '30-second think time for complex questions & code reasoning',
    title: 'Mastermind Tech Challenge',
    timerDurationSec: 30,
    questionCount: 15,
    isRandom: true,
    enableBonusSpeedPoints: false,
    allowAnswerChange: false,
    showCorrectAnswer: true,
    enableLeaderboard: true,
    categories: [],
    createdAt: Date.now()
  }
];

export const HostDashboard: React.FC<HostDashboardProps> = ({
  activeSession,
  questions = [],
  onCreateSession,
  onOpenSession,
  onOpenQuestionBank
}) => {
  const safeQuestions = questions || [];
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [savedTemplates, setSavedTemplates] = useState<QuizTemplate[]>([]);
  const [previewQuestion, setPreviewQuestion] = useState<Question | null>(null);

  const availableCategories = Array.from(new Set(safeQuestions.map(q => q.category))) as Category[];

  // Load custom saved templates
  useEffect(() => {
    try {
      const stored = localStorage.getItem('quizpulse_saved_templates');
      if (stored) {
        setSavedTemplates(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to parse saved templates:', e);
    }
  }, []);

  const handleSaveTemplate = (newTemplate: QuizTemplate) => {
    const updated = [...savedTemplates, newTemplate];
    setSavedTemplates(updated);
    try {
      localStorage.setItem('quizpulse_saved_templates', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleDeleteTemplate = (id: string) => {
    const updated = savedTemplates.filter(t => t.id !== id);
    setSavedTemplates(updated);
    try {
      localStorage.setItem('quizpulse_saved_templates', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleLaunchTemplate = (tmpl: QuizTemplate) => {
    onCreateSession(
      tmpl.title,
      {
        categories: tmpl.categories || [],
        questionCount: tmpl.questionCount || 10,
        timerDurationSec: tmpl.timerDurationSec || 20,
        isRandom: tmpl.isRandom ?? true,
        enableBonusSpeedPoints: tmpl.enableBonusSpeedPoints ?? true,
        allowAnswerChange: tmpl.allowAnswerChange ?? false,
        showCorrectAnswer: tmpl.showCorrectAnswer ?? true,
        enableLeaderboard: tmpl.enableLeaderboard ?? true,
        enableSoundEffects: true,
        maxParticipants: 100
      },
      tmpl.selectedQuestionIds
    );
  };

  const allTemplates = [...DEFAULT_TEMPLATES, ...savedTemplates];

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-indigo-950 text-white p-4 sm:p-6 md:p-8 max-w-7xl mx-auto w-full space-y-8">
      
      {/* Hero Banner */}
      <div className="bg-indigo-900/70 border border-indigo-500/30 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 bg-amber-400 text-indigo-950 rounded-full text-xs font-black uppercase tracking-widest shadow-md">
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Host Presenter Control Center</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
            Run Real-Time Live Event Quizzes
          </h1>
          <p className="text-sm sm:text-base text-indigo-200 font-semibold">
            Synchronize questions across mobile phones simultaneously, control countdowns on shared projectors, and broadcast live leaderboards!
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => setIsWizardOpen(true)}
              className="py-4 px-8 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-base rounded-2xl shadow-xl shadow-amber-400/20 transition-all flex items-center space-x-2 transform active:scale-98"
            >
              <Plus className="w-5 h-5 stroke-[3]" />
              <span>LAUNCH WIZARD (3-STEP CREATOR)</span>
            </button>

            <button
              onClick={onOpenQuestionBank}
              className="py-4 px-6 bg-indigo-950/80 hover:bg-indigo-800 text-indigo-100 font-bold text-sm rounded-2xl border border-indigo-500/30 transition-colors flex items-center space-x-2"
            >
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Question Bank ({safeQuestions.length})</span>
            </button>

            {safeQuestions.length > 0 && (
              <button
                onClick={() => {
                  const randomQ = safeQuestions[Math.floor(Math.random() * safeQuestions.length)];
                  setPreviewQuestion(randomQ);
                }}
                className="py-4 px-5 bg-slate-900/80 hover:bg-slate-800 text-amber-400 font-bold text-sm rounded-2xl border border-amber-400/30 flex items-center space-x-2 transition-colors"
                title="Preview a random question as participants see it on mobile"
              >
                <Eye className="w-4 h-4" />
                <span>Preview Participant View</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Active Session Card (If currently running) */}
      {activeSession && (
        <div className="bg-emerald-950/80 border-2 border-emerald-400/60 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-400 text-indigo-950 flex items-center justify-center font-black flex-shrink-0 animate-pulse shadow-lg shadow-emerald-400/30">
              <Radio className="w-8 h-8" />
            </div>
            <div>
              <span className="inline-block px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 text-xs font-black uppercase tracking-widest mb-1 border border-emerald-400/30">
                Active Session ({activeSession.status})
              </span>
              <h3 className="text-2xl font-black text-white">{activeSession.title}</h3>
              <p className="text-xs text-indigo-200 font-mono mt-0.5 font-bold">
                Join Code: <span className="font-black text-amber-400 text-xl tracking-wider">{activeSession.id}</span> • {Object.keys(activeSession.participants || {}).length} / {activeSession.settings?.maxParticipants || 50} Players Connected
              </p>
            </div>
          </div>

          <button
            onClick={() => onOpenSession(activeSession.id)}
            className="w-full md:w-auto py-4 px-8 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-base rounded-2xl shadow-xl shadow-amber-400/20 transition-transform active:scale-95 flex items-center justify-center space-x-2"
          >
            <span>RESUME CONTROL SCREEN</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Saved Quiz Session Templates */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bookmark className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-black text-white">Saved Session Templates ({allTemplates.length})</h2>
          </div>
          
          <button
            onClick={() => setIsWizardOpen(true)}
            className="text-xs text-amber-400 font-bold hover:underline flex items-center space-x-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create & Save New Template</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {allTemplates.map((tmpl) => {
            const isCustom = tmpl.id.startsWith('tmpl_');

            return (
              <div
                key={tmpl.id}
                className="bg-indigo-900/60 border border-indigo-500/30 hover:border-amber-400/50 rounded-3xl p-6 shadow-2xl space-y-4 flex flex-col justify-between transition-all relative group"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 bg-amber-400/20 text-amber-300 text-xs font-bold rounded-full border border-amber-400/30">
                      {tmpl.questionCount} Qs • {tmpl.timerDurationSec}s Timer
                    </span>
                    {isCustom && (
                      <button
                        onClick={() => handleDeleteTemplate(tmpl.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 transition-colors"
                        title="Delete custom saved template"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <h3 className="text-lg font-black text-white mt-3 leading-tight">{tmpl.name}</h3>
                  <p className="text-xs text-indigo-200 mt-1 font-semibold line-clamp-2">
                    {tmpl.description}
                  </p>
                </div>

                <div className="pt-2 flex items-center space-x-2">
                  <button
                    onClick={() => handleLaunchTemplate(tmpl)}
                    className="flex-1 py-3 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-xs rounded-2xl shadow-lg shadow-amber-400/20 flex items-center justify-center space-x-2 transition-transform active:scale-95"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>LAUNCH NOW</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Step-by-Step Quiz Creation Wizard */}
      <QuizCreationWizardModal
        isOpen={isWizardOpen}
        onClose={() => setIsWizardOpen(false)}
        onCreateSession={(title, settings, selectedQIds) => {
          onCreateSession(title, settings, selectedQIds);
          setIsWizardOpen(false);
        }}
        availableCategories={availableCategories}
        allQuestions={questions}
        onSaveTemplate={handleSaveTemplate}
      />

      {/* Participant Question Preview Modal */}
      <ParticipantQuestionPreviewModal
        question={previewQuestion}
        isOpen={Boolean(previewQuestion)}
        onClose={() => setPreviewQuestion(null)}
      />

    </div>
  );
};
