import React from 'react';
import { 
  Zap, Users, QrCode, Trophy, Sparkles, ArrowRight, Smartphone, 
  Check, Layers, Upload, Star, BarChart3, Clock, 
  Building2, GraduationCap, Heart, Tv, ShieldCheck, 
  TrendingUp, History, PlayCircle, Plus, CheckCircle2, ChevronRight,
  CreditCard, Shield, Gift
} from 'lucide-react';

interface LandingPageProps {
  onHostGameClick: () => void;
  onJoinGameClick: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onHostGameClick,
  onJoinGameClick
}) => {
  const steps = [
    {
      num: '01',
      title: 'Create Your Quiz',
      desc: 'Create manually, paste in bulk, import CSV or use your Question Bank.',
      borderColor: 'border-blue-500',
      badgeColor: 'bg-blue-600',
      icon: <Layers className="w-8 h-8 text-blue-400" />
    },
    {
      num: '02',
      title: 'Launch Your Room',
      desc: 'Generate a Game PIN and QR code. Display it and you\'re ready.',
      borderColor: 'border-indigo-500',
      badgeColor: 'bg-indigo-600',
      icon: <Tv className="w-8 h-8 text-indigo-400" />
    },
    {
      num: '03',
      title: 'Everyone Joins Instantly',
      desc: 'Players scan the QR code or enter the PIN, choose a name and join.',
      borderColor: 'border-emerald-500',
      badgeColor: 'bg-emerald-600',
      icon: <Users className="w-8 h-8 text-emerald-400" />
    },
    {
      num: '04',
      title: 'Host. Play. Compete.',
      desc: 'Run questions, track live answers, award bonuses and watch the leaderboard.',
      borderColor: 'border-amber-500',
      badgeColor: 'bg-amber-600',
      icon: <Trophy className="w-8 h-8 text-amber-400" />
    },
    {
      num: '05',
      title: 'Know What Happened',
      desc: 'Get results, insights and reports that show the full story of your game.',
      borderColor: 'border-rose-500',
      badgeColor: 'bg-rose-600',
      icon: <BarChart3 className="w-8 h-8 text-rose-400" />
    }
  ];

  const features = [
    {
      icon: <Zap className="w-6 h-6 text-purple-400" />,
      bgColor: 'bg-purple-500/10',
      title: 'Instant Join',
      desc: 'QR code or Game PIN. No accounts needed.'
    },
    {
      icon: <Users className="w-6 h-6 text-blue-400" />,
      bgColor: 'bg-blue-500/10',
      title: 'Live Multiplayer',
      desc: 'Keep every participant connected in real-time.'
    },
    {
      icon: <Layers className="w-6 h-6 text-emerald-400" />,
      bgColor: 'bg-emerald-500/10',
      title: 'Question Banks',
      desc: 'Build, organize and reuse your best questions.'
    },
    {
      icon: <Upload className="w-6 h-6 text-amber-400" />,
      bgColor: 'bg-amber-500/10',
      title: 'Bulk Import',
      desc: 'Create dozens of questions in seconds.'
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-rose-400" />,
      bgColor: 'bg-rose-500/10',
      title: 'Real-Time Leaderboards',
      desc: 'Turn every question into friendly competition.'
    },
    {
      icon: <Trophy className="w-6 h-6 text-indigo-400" />,
      bgColor: 'bg-indigo-500/10',
      title: 'Speed Bonuses',
      desc: 'Reward fast and correct answers with bonus points.'
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-teal-400" />,
      bgColor: 'bg-teal-500/10',
      title: 'Host Workspace',
      desc: 'Manage quizzes, sessions, participants and results.'
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-orange-400" />,
      bgColor: 'bg-orange-500/10',
      title: 'Session Analytics',
      desc: 'Understand performance beyond the final score.'
    },
    {
      icon: <History className="w-6 h-6 text-cyan-400" />,
      bgColor: 'bg-cyan-500/10',
      title: 'Session History',
      desc: 'Revisit past games and results anytime.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#0B0E14] text-white font-sans overflow-x-hidden selection:bg-yellow-400 selection:text-slate-950">
      
      {/* Hero Section */}
      <section className="relative pt-12 pb-20 sm:pt-20 sm:pb-28 overflow-hidden border-b border-white/10">
        {/* Glow Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/20 blur-[130px] rounded-full"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-400/10 blur-[130px] rounded-full"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 space-y-8">
          
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 bg-yellow-400/10 border border-yellow-400/30 rounded-full text-yellow-400 text-xs font-bold tracking-[0.2em] uppercase">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
            <span>Live Quizzes. Real-Time Energy.</span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold leading-[1.08] tracking-tight max-w-4xl mx-auto">
            Turn Any Room Into <br /> a <span className="text-yellow-400">Live Game.</span>
          </h1>

          <p className="max-w-2xl mx-auto text-slate-300 text-base sm:text-lg font-medium leading-relaxed">
            Create interactive quizzes your audience can join instantly from their phones. No participant accounts. No app downloads. Just scan, join and play.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={onHostGameClick}
              className="w-full sm:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 px-8 py-4 rounded-xl font-extrabold text-base flex items-center justify-center gap-2.5 shadow-[0_0_25px_rgba(255,215,0,0.3)] transition-all hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-5 h-5 fill-current" />
              <span>Host a Game</span>
            </button>

            <button
              onClick={onJoinGameClick}
              className="w-full sm:w-auto border-2 border-white/20 hover:border-white/40 bg-white/5 hover:bg-white/10 text-white px-8 py-4 rounded-xl font-extrabold text-base transition-all flex items-center justify-center gap-2.5"
            >
              <Smartphone className="w-5 h-5 text-cyan-400" />
              <span>Join With Game PIN</span>
            </button>
          </div>

          {/* Social Proof */}
          <div className="pt-6 flex flex-col items-center gap-3">
            <div className="flex -space-x-2.5">
              <img 
                referrerPolicy="no-referrer"
                src="https://lh3.googleusercontent.com/aida/AP1WRLsHx1tS-0_5lfsEzqyDBCBtCj7hf8TwhBJ5t8WOIts68rbnD6CIHDHYvEfetGFu5Z7JD5Y9e2GMLL6u2wljsWaULoIk3muLx8e8rUA3VLJHX3KrlPc7OZ_j9xYJr6xab4xT4eFGkLZieq5f1E_9CQGhx8mMHH-BMRTC2dhTvLtzdkCtlHaj4kTueXNLkOco2ZXjvCR5D6bJyQhdXWQ4sRLXWKfxJFLieWtxikTQ3aYO4l3Kvzv2rMwyxw8" 
                alt="Host" 
                className="w-10 h-10 rounded-full border-2 border-[#0B0E14] object-cover" 
              />
              <img 
                referrerPolicy="no-referrer"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuD3yiTBeUWoPvmOpeyS7S5Aow3LwxAeUBMCQfu4oTPQT3OfEJ0IcNPyfleWuQ2vyb6_DNkDrQ41ZwRpFZtb0_DpXs7PgCykq1NUlJp4tjR_4yYMM42RbAEIK3ic2eacvSICF1NTCEj0lQi0Q_MOHHlTf___Yaw4EaBBLCmhVoH49b6-zLAg0cxseYWghz-GpgHL7tVim3dQDDxaqsC4H4HcQUoHPbpkVFtNOAThtx9M-NhkKPeFXYvH" 
                alt="Host" 
                className="w-10 h-10 rounded-full border-2 border-[#0B0E14] object-cover" 
              />
              <img 
                referrerPolicy="no-referrer"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCFgo35xhmj4GpUJs7i7GZs9u7VfiPeIqx3rA_RzaIK5zW_j9Js0ShNZ1FKVXn1JGR4bzGrNatzAiRmGbg6WVmZbFQiT-14ABrEYEYKqgY78PpD0UBNC7l3oEDnHmsxc1RPH2GIGtMjlO0KNJKHOML8SXozqsbGV9yFZkVc6KXxdri8DAnof4tIZjikqtcqKN4sb1wj6yl2OY06URNEtZhP3QQJDhfhfQvr3QVowwMLL-kz5GPDH8X6" 
                alt="Host" 
                className="w-10 h-10 rounded-full border-2 border-[#0B0E14] object-cover" 
              />
              <img 
                referrerPolicy="no-referrer"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBnn74_vhE1OrX9xPBUXnKKkR-9RB4XN3FqwwmrFu708ho0wbQmpXyHlCLg0R74mEQTc07MdBiEg1CazxqLZ_D-LO41loQ8QTA8jXbSBj-bdzWfblxYrlMRMQKyf5T08iiRDmK4WhyyfcaB6Ytu_sLVVEEj0KlO8sJcfFd-j9-lyXM_4-UFz05G1xsCSgGuVhHSvMyPg9C0SFNtx2WIrqquswluUN95gk2RsNadx5gVC5QeZbRXgkIe" 
                alt="Host" 
                className="w-10 h-10 rounded-full border-2 border-[#0B0E14] object-cover" 
              />
            </div>
            <div className="flex items-center gap-2">
              <div className="flex text-yellow-400 space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current text-yellow-400" />
                ))}
              </div>
              <span className="text-xs text-slate-400 font-semibold">Loved by hosts and players everywhere</span>
            </div>
          </div>

        </div>
      </section>

      {/* Stats Bar */}
      <section className="border-b border-white/10 bg-[#161B22] py-10">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/10 text-purple-400 border border-purple-500/20 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl font-extrabold text-white">12,450+</div>
              <div className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Answers Submitted</div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/10 text-purple-400 border border-purple-500/20 flex items-center justify-center flex-shrink-0">
              <Tv className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl font-extrabold text-white">1,320+</div>
              <div className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Live Games Hosted</div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/10 text-purple-400 border border-purple-500/20 flex items-center justify-center flex-shrink-0">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl font-extrabold text-white">98,700+</div>
              <div className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Participants Engaged</div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-yellow-400/10 text-yellow-400 border border-yellow-400/20 flex items-center justify-center flex-shrink-0">
              <Zap className="w-6 h-6 fill-current" />
            </div>
            <div>
              <div className="text-2xl font-extrabold text-white">Real-Time</div>
              <div className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Multiplayer</div>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions / One Platform Section */}
      <section className="py-24 bg-white text-slate-900" id="solutions">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="text-center space-y-3">
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-slate-950">
              One Platform. A Hundred Ways to Play.
            </h2>
            <p className="text-base text-slate-500 font-semibold max-w-xl mx-auto">
              QuizPulse works wherever people gather.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Events Card */}
            <div className="bg-blue-50/80 rounded-2xl p-6 flex flex-col h-full border border-blue-100 hover:shadow-xl transition-all group">
              <div className="mb-4 overflow-hidden rounded-xl">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuC829lqJVPYrlXfnfnHXlwORM0YjOnpByw3xGwjT6Z8bYpqDz2BySKIeKwhgQpw_31hMuT35DxSXibPYBpGjyfJ0zEV5A7rDMMn_8vzKSa_xMociAYB4xL2_VsJMI-a0slr5hNxDNCL7XQ-xQ2EE_0uHROurBQWF0j10mXMWlTYAd2qQ8XPcCO9ktXuONge-Y9Z4YPN2VGjYB1THJgGECkUHdtMRwcI6Euw1Fc79CbAkG7uXZNraQB4" 
                  alt="Events" 
                  className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300" 
                />
              </div>
              <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center mb-4 shadow-md">
                <Tv className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-black mb-2 text-slate-950">Events</h3>
              <p className="text-xs text-slate-600 mb-6 flex-grow leading-relaxed font-medium">
                Make conferences, meetups, launches and community gatherings more interactive and memorable.
              </p>
              <button onClick={onHostGameClick} className="text-blue-600 font-extrabold text-xs flex items-center gap-1 group-hover:gap-2 transition-all">
                <span>Explore Events</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Work Card */}
            <div className="bg-indigo-50/80 rounded-2xl p-6 flex flex-col h-full border border-indigo-100 hover:shadow-xl transition-all group">
              <div className="mb-4 overflow-hidden rounded-xl">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBb6GziTLmt4GZ5FO-14watdgJ1sX7ETVwEkn1VRpC_OLhsEzAQ3Cdk9MjrnK-ca0pdVmhwQ7w8IGWrNQswZzwS95fxNyHAh3PvA_EBIDoUQguTePEP2ALJRmOrspUquWGbXGQLhusI4kcadHi3_XdtAFTn_j_OuuVHOAkTHtaiNwjQHYIOkvUmL6pFv2Gjql3tXdZHJxyXPzC2nvbht-9B25TuGiKk4eKFU9dFeLsWGJ3y9aa99NWu" 
                  alt="Work" 
                  className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300" 
                />
              </div>
              <div className="w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center mb-4 shadow-md">
                <Building2 className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-black mb-2 text-slate-950">Work</h3>
              <p className="text-xs text-slate-600 mb-6 flex-grow leading-relaxed font-medium">
                Run onboarding quizzes, training sessions, knowledge challenges and team competitions.
              </p>
              <button onClick={onHostGameClick} className="text-indigo-600 font-extrabold text-xs flex items-center gap-1 group-hover:gap-2 transition-all">
                <span>Explore Teams</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Education Card */}
            <div className="bg-emerald-50/80 rounded-2xl p-6 flex flex-col h-full border border-emerald-100 hover:shadow-xl transition-all group">
              <div className="mb-4 overflow-hidden rounded-xl">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDAK3K8S6NQ0pOd7O2ShvrvjVqrjhDkIya_MJ5p0pgBJRh5A7iMjdruDV-XgZ23FlrxXWdAwkuJ7YFtbkffadoof0FA2ZjFH3_9Qn98BCPlktt28WM2Z2leUSy8JkDlA11rckON7XVc2AUfmTNQYMNdGJ4KP0JSbGRGiai3mefaxQPrKhipbTAIfgsqcpWmT0cjfcDqDCSNs1cfnjmSiQBZpzM6bTHIPS2eqOTiST2Pju-80Gr4XsIs" 
                  alt="Education" 
                  className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300" 
                />
              </div>
              <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center mb-4 shadow-md">
                <GraduationCap className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-black mb-2 text-slate-950">Education</h3>
              <p className="text-xs text-slate-600 mb-6 flex-grow leading-relaxed font-medium">
                Create classroom quizzes, revision games and knowledge challenges with instant feedback.
              </p>
              <button onClick={onHostGameClick} className="text-emerald-600 font-extrabold text-xs flex items-center gap-1 group-hover:gap-2 transition-all">
                <span>Explore Education</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Communities Card */}
            <div className="bg-rose-50/80 rounded-2xl p-6 flex flex-col h-full border border-rose-100 hover:shadow-xl transition-all group">
              <div className="mb-4 overflow-hidden rounded-xl">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCxljYl_tLXRfJy8bnkZkTHuc8gO7WS2ZWn1zpvLIvPgVqXBwhwUnQsRlDHILBrnRpufojJiRvMQP-VGj2YVpCho-de9Of2bjEaJMMeBnD20aTKHQUODuYht8Ulgh-M_R477d1qj5aQsDqQZeoT0X1bZ6PnJ_su2EMnxZt53YqcZKU52dnkakghzpfNH85c6KCMcOV-GWgDTC6CqlB79sCkK9fOFYYemNtKST-xB2TDhgvwDl6rzlB3" 
                  alt="Communities" 
                  className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300" 
                />
              </div>
              <div className="w-10 h-10 bg-rose-600 text-white rounded-xl flex items-center justify-center mb-4 shadow-md">
                <Heart className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-black mb-2 text-slate-950">Communities</h3>
              <p className="text-xs text-slate-600 mb-6 flex-grow leading-relaxed font-medium">
                Perfect for associations, churches, online communities and social gatherings.
              </p>
              <button onClick={onHostGameClick} className="text-rose-600 font-extrabold text-xs flex items-center gap-1 group-hover:gap-2 transition-all">
                <span>Explore Communities</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-[#0B0E14] text-white border-b border-white/10" id="how-it-works">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="text-center space-y-3">
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight">
              From Question Bank to Game Night <span className="text-yellow-400">in Minutes.</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {steps.map((s, idx) => (
              <div key={idx} className="text-center flex flex-col h-full group">
                <div className={`w-12 h-12 ${s.badgeColor} rounded-full flex items-center justify-center text-white font-black text-sm mx-auto mb-6 shadow-lg`}>
                  {s.num}
                </div>
                <div className={`bg-white/[0.03] backdrop-blur-md border border-white/10 border-t-4 ${s.borderColor} p-6 rounded-2xl flex-grow flex flex-col items-center justify-start space-y-3 shadow-xl hover:bg-white/[0.06] transition-all`}>
                  <div className="mb-2">
                    {s.icon}
                  </div>
                  <h4 className="font-extrabold text-base text-white">{s.title}</h4>
                  <p className="text-xs text-slate-400 font-medium leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section (Built for Big Screen & Small Screen) */}
      <section className="py-20 bg-white text-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 text-center">
          <div>
            <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-2">The QuizPulse Experience</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-950 leading-tight">
              Built for the Big Screen. And Every Small Screen.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="bg-slate-50 border border-slate-200/80 p-6 rounded-2xl flex items-start gap-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 bg-blue-100 text-blue-600 rounded-2xl flex-shrink-0 flex items-center justify-center font-bold">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900 mb-1">Host View</h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">Control questions, timers, reveals and game progression.</p>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 p-6 rounded-2xl flex items-start gap-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 bg-indigo-100 text-indigo-600 rounded-2xl flex-shrink-0 flex items-center justify-center font-bold">
                <Smartphone className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900 mb-1">Player View</h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">Fast, distraction-free answering from any phone.</p>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 p-6 rounded-2xl flex items-start gap-4 hover:shadow-md transition-all">
              <div className="w-11 h-11 bg-purple-100 text-purple-600 rounded-2xl flex-shrink-0 flex items-center justify-center font-bold">
                <Tv className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900 mb-1">Presenter View</h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">A clean live display designed for projectors, TVs and LED screens.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-slate-50 text-slate-900" id="features">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="flex flex-col lg:flex-row justify-between lg:items-end gap-6">
            <div className="space-y-3 max-w-xl">
              <span className="text-xs font-black text-purple-600 uppercase tracking-widest block">Powerful & Easy to Use</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-950">
                Everything You Need to Run Amazing Live Games.
              </h2>
            </div>
            <button 
              onClick={onHostGameClick}
              className="bg-purple-600 hover:bg-purple-700 text-white px-7 py-3.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all self-start lg:self-auto shadow-md"
            >
              <span>Explore All Features</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200/80 flex items-start gap-4 hover:shadow-lg transition-all">
                <div className={`w-12 h-12 rounded-xl ${f.bgColor} flex items-center justify-center flex-shrink-0`}>
                  {f.icon}
                </div>
                <div className="space-y-1">
                  <h5 className="font-extrabold text-sm text-slate-950">{f.title}</h5>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-[#0B0E14] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="space-y-3">
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight">
              Loved by Hosts. <br /> Hyped by Players.
            </h2>
            <p className="text-slate-400 text-sm font-medium">Real stories from real QuizPulse events around the world.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white/[0.03] backdrop-blur-md border border-white/10 p-8 rounded-2xl flex flex-col justify-between space-y-6 shadow-xl">
              <div className="space-y-4">
                <div className="text-purple-400">
                  <Sparkles className="w-8 h-8 fill-current" />
                </div>
                <p className="text-slate-300 text-sm italic font-medium leading-relaxed">
                  "QuizPulse made our conference 10x more engaging. The leaderboard had everyone on their phones!"
                </p>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida/AP1WRLsHx1tS-0_5lfsEzqyDBCBtCj7hf8TwhBJ5t8WOIts68rbnD6CIHDHYvEfetGFu5Z7JD5Y9e2GMLL6u2wljsWaULoIk3muLx8e8rUA3VLJHX3KrlPc7OZ_j9xYJr6xab4xT4eFGkLZieq5f1E_9CQGhx8mMHH-BMRTC2dhTvLtzdkCtlHaj4kTueXNLkOco2ZXjvCR5D6bJyQhdXWQ4sRLXWKfxJFLieWtxikTQ3aYO4l3Kvzv2rMwyxw8" 
                  alt="Tolu A." 
                  className="w-11 h-11 rounded-full object-cover border border-white/20" 
                />
                <div>
                  <div className="font-extrabold text-sm text-white">Tolu A.</div>
                  <div className="text-[11px] text-slate-400 font-semibold">Event Coordinator</div>
                </div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white/[0.03] backdrop-blur-md border border-white/10 p-8 rounded-2xl flex flex-col justify-between space-y-6 shadow-xl">
              <div className="space-y-4">
                <div className="text-purple-400">
                  <Sparkles className="w-8 h-8 fill-current" />
                </div>
                <p className="text-slate-300 text-sm italic font-medium leading-relaxed">
                  "So easy to use. We had 200+ people join in seconds. The energy in the room was insane!"
                </p>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCypes3RYwk90-LNztSQaNn-amir1kQjVP-9EUlOflz0DlS0sdSUYIbIY6HUAAJH4HyzxiychFZEN7bxCFngmmumLYHLOufYkSkQeY1NyxYQh5h-Nm93wSsqPaQkKb908hpOIwd7AqSNaKaAVeXeMZDiAqXBRFkiVuqtESbDrZMjeZJ9OLritrJg_2t_W6c_YtFhw9kDDsDZtS8ytDlL_rvBIdg-mdEADJ7mhUzJFEckSV2dcHFEktj" 
                  alt="David O." 
                  className="w-11 h-11 rounded-full object-cover border border-white/20" 
                />
                <div>
                  <div className="font-extrabold text-sm text-white">David O.</div>
                  <div className="text-[11px] text-slate-400 font-semibold">Workshop Host</div>
                </div>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white/[0.03] backdrop-blur-md border border-white/10 p-8 rounded-2xl flex flex-col justify-between space-y-6 shadow-xl">
              <div className="space-y-4">
                <div className="text-purple-400">
                  <Sparkles className="w-8 h-8 fill-current" />
                </div>
                <p className="text-slate-300 text-sm italic font-medium leading-relaxed">
                  "Best part of our youth event! The speed bonus rounds were everyone's favorite."
                </p>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <img 
                  referrerPolicy="no-referrer"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuD1IqaxhAyoydbcnOQCf4EeJxIbYqD4fmwBzKSpgeg1t1_lakMKt2FL7WxNtA3KfR3HLBEXOnAvV3Cq9Qks_xt4jfiSgnMlMXl9z03039HjwQg_oNMl5vHbP-C3aZtoXjeiqJLjdoZ3mcqUGn7wZJNUiXKPtg6zeB59sJD3SQFtNglYYQEkyC2ZUILdUKHvSguPSSKlOGtef6OYITC-3o9DOx4thFU1A-S-RizrNbWaO72Wd_9GvkmN" 
                  alt="Mercy E." 
                  className="w-11 h-11 rounded-full object-cover border border-white/20" 
                />
                <div>
                  <div className="font-extrabold text-sm text-white">Mercy E.</div>
                  <div className="text-[11px] text-slate-400 font-semibold">Community Leader</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pay-As-You-Go Pricing Section */}
      <section className="py-24 bg-slate-900 border-t border-slate-800 text-white" id="pricing">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-4 max-w-2xl mx-auto">
            <span className="px-3.5 py-1 bg-yellow-400/10 text-yellow-400 text-xs font-black uppercase tracking-widest rounded-full border border-yellow-400/30 inline-block">
              Simple Pay-As-You-Go Pricing
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Pay Only For What You Host. <br />
              <span className="text-yellow-400">No Monthly Subscriptions.</span>
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm font-semibold leading-relaxed">
              Create quizzes, manage question banks, and import questions completely free. Pay only when you launch a live game based on your maximum participant capacity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            
            {/* Free Tier */}
            <div className="bg-slate-950 border border-emerald-500/40 rounded-3xl p-6 flex flex-col justify-between relative hover:border-emerald-400 transition-all shadow-xl">
              <div className="space-y-4">
                <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black uppercase tracking-wider rounded-lg border border-emerald-500/30 inline-block">
                  Starter / Free
                </span>
                <div>
                  <div className="text-3xl font-black text-white">FREE</div>
                  <p className="text-[11px] text-slate-400 mt-1 font-semibold">0–5 Players per game</p>
                </div>
                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    <span>Free Live Game</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    <span>All Question Types</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    <span>Realtime Leaderboard</span>
                  </div>
                </div>
              </div>
              <button
                onClick={onHostGameClick}
                className="mt-6 w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl transition-transform active:scale-95"
              >
                Host Free Game
              </button>
            </div>

            {/* Tier 10 */}
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between hover:border-slate-700 transition-all shadow-xl">
              <div className="space-y-4">
                <span className="px-2.5 py-1 bg-slate-900 text-slate-400 text-[10px] font-black uppercase tracking-wider rounded-lg border border-slate-800 inline-block">
                  Small Event
                </span>
                <div>
                  <div className="text-2xl font-black text-yellow-400">₦5,000</div>
                  <p className="text-[11px] text-slate-400 mt-1 font-semibold">6–10 Players per game</p>
                </div>
                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Single Live Session</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Speed Bonus Engine</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Presenter Display Mode</span>
                  </div>
                </div>
              </div>
              <button
                onClick={onHostGameClick}
                className="mt-6 w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl border border-slate-700 transition-transform active:scale-95"
              >
                Select Tier
              </button>
            </div>

            {/* Tier 20 (POPULAR) */}
            <div className="bg-slate-950 border-2 border-yellow-400 rounded-3xl p-6 flex flex-col justify-between relative hover:shadow-yellow-400/10 hover:shadow-2xl transition-all">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-slate-950 text-[9px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-md">
                MOST POPULAR
              </div>
              <div className="space-y-4">
                <span className="px-2.5 py-1 bg-yellow-400/10 text-yellow-400 text-[10px] font-black uppercase tracking-wider rounded-lg border border-yellow-400/30 inline-block">
                  Medium Event
                </span>
                <div>
                  <div className="text-2xl font-black text-yellow-400">₦10,000</div>
                  <p className="text-[11px] text-slate-400 mt-1 font-semibold">11–20 Players per game</p>
                </div>
                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Up to 20 Concurrents</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Dedicated Presenter TV</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Instant Analytics Export</span>
                  </div>
                </div>
              </div>
              <button
                onClick={onHostGameClick}
                className="mt-6 w-full py-2.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-xl shadow transition-transform active:scale-95"
              >
                Get Started
              </button>
            </div>

            {/* Tier 50 */}
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between hover:border-slate-700 transition-all shadow-xl">
              <div className="space-y-4">
                <span className="px-2.5 py-1 bg-slate-900 text-slate-400 text-[10px] font-black uppercase tracking-wider rounded-lg border border-slate-800 inline-block">
                  Large Event
                </span>
                <div>
                  <div className="text-2xl font-black text-yellow-400">₦25,000</div>
                  <p className="text-[11px] text-slate-400 mt-1 font-semibold">21–50 Players per game</p>
                </div>
                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Up to 50 Concurrents</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Live Timer Synchronizer</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <span>Full History & CSV</span>
                  </div>
                </div>
              </div>
              <button
                onClick={onHostGameClick}
                className="mt-6 w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl border border-slate-700 transition-transform active:scale-95"
              >
                Select Tier
              </button>
            </div>

            {/* Tier 100 */}
            <div className="bg-slate-950 border border-indigo-500/40 rounded-3xl p-6 flex flex-col justify-between hover:border-indigo-400 transition-all shadow-xl">
              <div className="space-y-4">
                <span className="px-2.5 py-1 bg-indigo-500/10 text-indigo-400 text-[10px] font-black uppercase tracking-wider rounded-lg border border-indigo-500/30 inline-block">
                  Enterprise / High Scale
                </span>
                <div>
                  <div className="text-2xl font-black text-yellow-400">₦50,000</div>
                  <p className="text-[11px] text-slate-400 mt-1 font-semibold">51–100 Players max</p>
                </div>
                <div className="space-y-2 pt-2 border-t border-slate-800/80 text-xs text-slate-300">
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
                    <span>High-Scale 100 Players</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
                    <span>Optimized Supabase Sync</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
                    <span>Priority Support</span>
                  </div>
                </div>
              </div>
              <button
                onClick={onHostGameClick}
                className="mt-6 w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl transition-transform active:scale-95"
              >
                Select Tier
              </button>
            </div>

          </div>

          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4 text-yellow-400 flex-shrink-0" />
              <span>Safe Mock Payment Engine enabled for testing. No real card charges.</span>
            </div>
            <span className="font-bold text-slate-300">Questions & Quizzes remain free forever.</span>
          </div>

        </div>
      </section>

      {/* Final Call to Action */}
      <section className="py-16 bg-[#0B0E14] border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-[#0B0E14] rounded-3xl p-8 sm:p-12 flex flex-col lg:flex-row items-center justify-between gap-10 overflow-hidden relative border border-purple-500/30 shadow-2xl">
            <div className="relative z-10 space-y-6 text-center lg:text-left max-w-2xl">
              <h2 className="text-2xl sm:text-4xl font-extrabold leading-tight text-white">
                Your Audience Already Has Their Phones. <br /> Give Them Something Worth Joining.
              </h2>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <button
                  onClick={onHostGameClick}
                  className="w-full sm:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 px-8 py-4 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Sparkles className="w-4 h-4 fill-current" />
                  <span>Host a Game</span>
                </button>

                <button
                  onClick={onJoinGameClick}
                  className="w-full sm:w-auto border-2 border-white/20 hover:border-white/40 text-white px-8 py-4 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 transition-all"
                >
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <span>Join With Game PIN</span>
                </button>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl flex items-center gap-5 shadow-2xl relative z-10 border border-slate-200">
              <div className="w-20 h-20 bg-slate-950 text-yellow-400 rounded-xl flex items-center justify-center flex-shrink-0">
                <QrCode className="w-14 h-14" />
              </div>
              <div className="text-slate-950">
                <div className="font-extrabold text-base">Scan to Join</div>
                <div className="text-xs text-slate-500 font-semibold">No setup. Just play.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
