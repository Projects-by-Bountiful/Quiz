import React from 'react';
import { 
  Zap, Check, X, Users, Sparkles, ShieldCheck, ArrowRight, 
  HelpCircle, CreditCard, Gift, Layers 
} from 'lucide-react';
import { PRICING_TIERS, MAX_SUPPORTED_PLAYERS, CURRENCY_SYMBOL } from '../config/pricingConfig';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartQuiz?: () => void;
}

export const PricingModal: React.FC<PricingModalProps> = ({
  isOpen,
  onClose,
  onStartQuiz
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl p-6 sm:p-8 shadow-2xl relative space-y-8 my-4 overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Section */}
        <div className="text-center space-y-3 max-w-2xl mx-auto pt-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-yellow-400/10 border border-yellow-400/30 rounded-full text-yellow-400 text-xs font-black uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Transparent Pay-As-You-Go</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Pay only when you play
          </h2>

          <p className="text-sm sm:text-base text-slate-300 font-medium leading-relaxed">
            No monthly subscription. No recurring billing. Pay for individual live games based on the capacity you need.
          </p>
        </div>

        {/* Value Propositions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center flex-shrink-0 font-bold">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-extrabold text-white">Build & Prepare For Free</h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-normal">
                Build your quiz for free. Pay only when you're ready to host a live game.
              </p>
            </div>
          </div>

          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-yellow-400/15 border border-yellow-400/30 text-yellow-400 flex items-center justify-center flex-shrink-0 font-bold">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-extrabold text-white">One Game. One Payment.</h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-normal">
                One game. One payment. No monthly subscription, hidden fees, or auto-renewals.
              </p>
            </div>
          </div>
        </div>

        {/* Pricing Tier Grid / Table */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center space-x-2">
              <Layers className="w-4 h-4 text-yellow-400" />
              <span>QuizPulse Live Pricing Tiers</span>
            </h3>
            <span className="text-xs text-slate-400 font-semibold">
              Max capacity: {MAX_SUPPORTED_PLAYERS} players
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {PRICING_TIERS.map((tier, idx) => {
              const isPopular = tier.price === 25000;
              return (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border transition-all relative flex flex-col justify-between ${
                    tier.isFree
                      ? 'bg-slate-950/90 border-emerald-500/40 text-emerald-300'
                      : isPopular
                      ? 'bg-yellow-950/20 border-yellow-400 shadow-lg shadow-yellow-400/10'
                      : 'bg-slate-950/80 border-slate-800'
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-2.5 right-3 px-2 py-0.5 bg-yellow-400 text-slate-950 text-[10px] font-black uppercase tracking-wider rounded-full shadow">
                      Popular
                    </div>
                  )}

                  <div className="space-y-1 mb-4">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                      {tier.badge || 'Tier'}
                    </span>
                    <h4 className="text-base font-black text-white flex items-center space-x-1">
                      <Users className="w-3.5 h-3.5 text-slate-400" />
                      <span>{tier.label}</span>
                    </h4>
                  </div>

                  <div>
                    <div className="text-xl font-black text-yellow-400 tracking-tight">
                      {tier.formattedPrice}
                    </div>
                    <span className="text-[10px] text-slate-400 font-semibold block">
                      {tier.isFree ? 'Free forever' : 'per live game'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Feature Matrix summary */}
        <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-2">
          <div className="font-bold text-white uppercase tracking-wider text-[11px]">
            Every Live Game Includes:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-400">
            <div className="flex items-center space-x-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Real-time WebSocket & Supabase sync</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Live leaderboard with streak bonuses</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>All 5 question types (MC, Fastest Fingers, Ordering, etc.)</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>Full post-game analytics & participant exports</span>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <span className="text-xs text-slate-400 font-semibold">
            Ready to host? Create quizzes for free anytime.
          </span>

          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase tracking-wider transition-colors"
            >
              Close
            </button>
            {onStartQuiz && (
              <button
                onClick={() => {
                  onClose();
                  onStartQuiz();
                }}
                className="px-6 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black uppercase tracking-wider transition-all flex items-center space-x-2 shadow-lg shadow-yellow-400/20"
              >
                <span>Create Quiz For Free</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
