import React, { useState } from 'react';
import { 
  X, Download, Printer, Trophy, Users, HelpCircle, CheckCircle2, XCircle, 
  Clock, Zap, Star, BarChart3, ArrowUpRight, MessageSquare
} from 'lucide-react';
import { GameSession, GameHistoryRecord, Question, Participant, ParticipantAnswer } from '../types';
import { calculateParticipantStats, calculateSessionSummary } from '../utils/stats';

interface PostEventReportModalProps {
  session?: GameSession;
  historyRecord?: GameHistoryRecord;
  onClose: () => void;
}

export const PostEventReportModal: React.FC<PostEventReportModalProps> = ({
  session,
  historyRecord,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'questions' | 'participants' | 'feedback'>('summary');

  // Standardize data from either active GameSession or GameHistoryRecord
  const title = session?.title || historyRecord?.title || 'Quiz Session Report';
  const questions: Question[] = session?.questions || historyRecord?.questions || historyRecord?.fullSession?.questions || [];
  const participants = session?.participants 
    ? Object.values(session.participants)
    : historyRecord?.participants || [];

  const feedbackList = session?.feedback 
    ? Object.values(session.feedback)
    : historyRecord?.feedbackList || [];

  const totalParticipants = participants.length;
  const totalQuestions = questions.length;

  // Compute aggregated answer statistics across all participants and questions
  let totalAnswersSubmitted = 0;
  let totalCorrectAnswers = 0;
  let totalResponseTimeSec = 0;
  let fastestResponseSec = Infinity;
  let fastestParticipantName = 'N/A';
  let fastestQuestionText = 'N/A';

  // Question-level metrics mapping
  const questionMetrics = questions.map((q, qIdx) => {
    let qSubmitted = 0;
    let qCorrect = 0;
    let qTotalTime = 0;

    if (session?.participants) {
      (Object.values(session.participants) as Participant[]).forEach(p => {
        const ans = p.answers?.[q.id];
        if (ans) {
          qSubmitted++;
          totalAnswersSubmitted++;
          qTotalTime += ans.timeTakenSec || 0;
          totalResponseTimeSec += ans.timeTakenSec || 0;

          if (ans.isCorrect) {
            qCorrect++;
            totalCorrectAnswers++;
          }

          if (ans.timeTakenSec && ans.timeTakenSec < fastestResponseSec) {
            fastestResponseSec = ans.timeTakenSec;
            fastestParticipantName = p.name;
            fastestQuestionText = `Q${qIdx + 1}: ${q.question}`;
          }
        }
      });
    }

    const accuracyPercent = qSubmitted > 0 ? Math.round((qCorrect / qSubmitted) * 100) : 0;
    const avgTimeSec = qSubmitted > 0 ? Number((qTotalTime / qSubmitted).toFixed(1)) : 0;

    return {
      question: q,
      index: qIdx + 1,
      submitted: qSubmitted,
      correct: qCorrect,
      incorrect: qSubmitted - qCorrect,
      accuracyPercent,
      avgTimeSec
    };
  });

  const totalIncorrectAnswers = totalAnswersSubmitted - totalCorrectAnswers;
  const averageAccuracy = totalAnswersSubmitted > 0 ? Math.round((totalCorrectAnswers / totalAnswersSubmitted) * 100) : (historyRecord?.averageAccuracy || 0);
  const averageResponseTime = totalAnswersSubmitted > 0 ? Number((totalResponseTimeSec / totalAnswersSubmitted).toFixed(1)) : 0;

  // Find hardest and easiest questions
  const sortedByAccuracy = [...questionMetrics].sort((a, b) => a.accuracyPercent - b.accuracyPercent);
  const hardestQuestion = sortedByAccuracy[0];
  const easiestQuestion = sortedByAccuracy[sortedByAccuracy.length - 1];

  // Calculate Average Feedback Star Rating
  const avgFeedbackRating = feedbackList.length > 0
    ? Number((feedbackList.reduce((acc, f) => acc + f.rating, 0) / feedbackList.length).toFixed(1))
    : 0;

  // Export as CSV
  const exportCSV = () => {
    let csv = `Event Title,${title}\nTotal Participants,${totalParticipants}\nTotal Questions,${totalQuestions}\nTotal Answers,${totalAnswersSubmitted}\nAverage Accuracy,${averageAccuracy}%\nAverage Response Time,${averageResponseTime}s\n\n`;
    csv += `Rank,Participant Name,Score,Correct Count,Avg Time (s)\n`;
    
    participants.forEach((p: any, idx) => {
      csv += `${p.rank || idx + 1},"${p.name}",${p.score},${p.correctCount || 0},${p.avgTime || p.totalResponseTime || 0}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.replace(/\s+/g, '_')}_Report.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export as JSON
  const exportJSON = () => {
    const data = {
      title,
      totalParticipants,
      totalQuestions,
      totalAnswersSubmitted,
      totalCorrectAnswers,
      totalIncorrectAnswers,
      averageAccuracy,
      averageResponseTime,
      fastestRecord: {
        timeSec: fastestResponseSec === Infinity ? 0 : fastestResponseSec,
        participant: fastestParticipantName,
        question: fastestQuestionText
      },
      questionMetrics,
      participants,
      feedbackList
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.replace(/\s+/g, '_')}_Report.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto font-sans">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* REPORT MODAL HEADER */}
        <div className="p-4 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-950">
          <div className="flex items-center space-x-3 min-w-0">
            <div className="p-3 bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 rounded-2xl flex-shrink-0">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <span className="text-xs text-yellow-400 font-extrabold uppercase tracking-widest block">POST-EVENT ANALYTICS</span>
              <h2 className="text-lg sm:text-2xl font-black text-white truncate max-w-full">{title}</h2>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-2 justify-start sm:justify-end">
            <button
              onClick={exportCSV}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all border border-slate-700"
              title="Export CSV"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>CSV</span>
            </button>

            <button
              onClick={exportJSON}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all border border-slate-700"
              title="Export JSON"
            >
              <Download className="w-3.5 h-3.5 text-yellow-400" />
              <span>JSON</span>
            </button>

            <button
              onClick={() => window.print()}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all border border-slate-700"
              title="Print Report"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-400" />
              <span>Print</span>
            </button>

            <button
              onClick={onClose}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-all ml-auto sm:ml-0"
              title="Close Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex border-b border-slate-800 bg-slate-900 px-4 sm:px-6 pt-3 space-x-2 text-xs font-black overflow-x-auto whitespace-nowrap">
          <button
            onClick={() => setActiveTab('summary')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 transition-all ${
              activeTab === 'summary'
                ? 'border-yellow-400 text-yellow-400 bg-slate-950'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('questions')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 transition-all ${
              activeTab === 'questions'
                ? 'border-yellow-400 text-yellow-400 bg-slate-950'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Question Breakdown ({questions.length})
          </button>
          <button
            onClick={() => setActiveTab('participants')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 transition-all ${
              activeTab === 'participants'
                ? 'border-yellow-400 text-yellow-400 bg-slate-950'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Participant Rankings ({participants.length})
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            className={`px-4 py-2.5 rounded-t-xl border-b-2 transition-all flex items-center space-x-1.5 ${
              activeTab === 'feedback'
                ? 'border-yellow-400 text-yellow-400 bg-slate-950'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Star className="w-3.5 h-3.5 text-yellow-400 fill-current" />
            <span>Event Feedback ({feedbackList.length})</span>
          </button>
        </div>

        {/* MODAL BODY CONTENT */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-slate-950">
          
          {/* TAB 1: OVERVIEW SUMMARY */}
          {activeTab === 'summary' && (
            <div className="space-y-6">
              
              {/* Primary Stats Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                  <div className="flex items-center space-x-2 text-slate-400 text-xs font-bold uppercase mb-1">
                    <Users className="w-4 h-4 text-cyan-400" />
                    <span>Participants</span>
                  </div>
                  <p className="text-3xl font-black text-white">{totalParticipants}</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                  <div className="flex items-center space-x-2 text-slate-400 text-xs font-bold uppercase mb-1">
                    <HelpCircle className="w-4 h-4 text-yellow-400" />
                    <span>Questions</span>
                  </div>
                  <p className="text-3xl font-black text-white">{totalQuestions}</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                  <div className="flex items-center space-x-2 text-slate-400 text-xs font-bold uppercase mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Avg Accuracy</span>
                  </div>
                  <p className="text-3xl font-black text-emerald-400">{averageAccuracy}%</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
                  <div className="flex items-center space-x-2 text-slate-400 text-xs font-bold uppercase mb-1">
                    <Clock className="w-4 h-4 text-pink-400" />
                    <span>Avg Response Time</span>
                  </div>
                  <p className="text-3xl font-black text-white">{averageResponseTime}s</p>
                </div>
              </div>

              {/* Secondary Stats Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Total Answers Submitted */}
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-2">
                  <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider block">Answer Response Volume</span>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-2xl font-black text-white">{totalAnswersSubmitted}</span>
                    <span className="text-xs text-slate-400">Total answers submitted</span>
                  </div>
                  <div className="flex items-center justify-between text-xs font-bold pt-2 border-t border-slate-800">
                    <span className="text-emerald-400">✓ {totalCorrectAnswers} Correct</span>
                    <span className="text-rose-400">✗ {totalIncorrectAnswers} Incorrect</span>
                  </div>
                </div>

                {/* Fastest Response Record */}
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-2">
                  <div className="flex items-center space-x-1.5 text-xs font-extrabold text-yellow-400 uppercase tracking-wider">
                    <Zap className="w-4 h-4 fill-current" />
                    <span>Fastest Response</span>
                  </div>
                  <p className="text-2xl font-black text-white">
                    {fastestResponseSec === Infinity ? 'N/A' : `${fastestResponseSec}s`}
                  </p>
                  <p className="text-xs text-slate-400 font-bold truncate">
                    by {fastestParticipantName}
                  </p>
                </div>

                {/* Feedback Average */}
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-2">
                  <div className="flex items-center space-x-1.5 text-xs font-extrabold text-yellow-400 uppercase tracking-wider">
                    <Star className="w-4 h-4 fill-current" />
                    <span>Participant Rating</span>
                  </div>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-2xl font-black text-white">{avgFeedbackRating > 0 ? `${avgFeedbackRating} / 5` : 'No ratings'}</span>
                    <span className="text-xs text-slate-400">({feedbackList.length} reviews)</span>
                  </div>
                </div>

              </div>

              {/* Hardest vs Easiest Questions Spotlight */}
              {hardestQuestion && easiestQuestion && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-5 bg-rose-950/40 border border-rose-500/30 rounded-2xl space-y-2">
                    <span className="px-2.5 py-0.5 bg-rose-500/20 text-rose-300 rounded text-[10px] font-black uppercase">
                      Most Challenging Question
                    </span>
                    <p className="font-bold text-white text-sm">{hardestQuestion.question.question}</p>
                    <div className="flex items-center justify-between text-xs font-bold text-slate-400 pt-1">
                      <span>Correct: {hardestQuestion.accuracyPercent}%</span>
                      <span>Avg Time: {hardestQuestion.avgTimeSec}s</span>
                    </div>
                  </div>

                  <div className="p-5 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl space-y-2">
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-black uppercase">
                      Easiest Question
                    </span>
                    <p className="font-bold text-white text-sm">{easiestQuestion.question.question}</p>
                    <div className="flex items-center justify-between text-xs font-bold text-slate-400 pt-1">
                      <span>Correct: {easiestQuestion.accuracyPercent}%</span>
                      <span>Avg Time: {easiestQuestion.avgTimeSec}s</span>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB 2: QUESTION BREAKDOWN */}
          {activeTab === 'questions' && (
            <div className="space-y-4">
              {questionMetrics.map((qm) => (
                <div key={qm.question.id} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 bg-yellow-400 text-slate-950 font-black text-xs rounded-xl">
                      Q{qm.index}
                    </span>
                    <span className="text-xs font-bold text-cyan-400 uppercase">{qm.question.category}</span>
                  </div>

                  <h3 className="font-extrabold text-white text-base">{qm.question.question}</h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-bold pt-2 border-t border-slate-800">
                    <div className="text-slate-400">
                      Correct Choice: <strong className="text-emerald-400">{String.fromCharCode(65 + qm.question.correctAnswer)}</strong>
                    </div>
                    <div className="text-slate-400">
                      Accuracy: <strong className="text-white">{qm.accuracyPercent}%</strong>
                    </div>
                    <div className="text-slate-400">
                      Submitted: <strong className="text-white">{qm.submitted}</strong>
                    </div>
                    <div className="text-slate-400">
                      Avg Time: <strong className="text-white">{qm.avgTimeSec}s</strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: PARTICIPANT RANKINGS & ANALYTICS */}
          {activeTab === 'participants' && (
            <div className="space-y-3">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-x-auto">
                <table className="w-full text-left text-xs font-bold whitespace-nowrap">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="p-3">Rank</th>
                      <th className="p-3">Participant</th>
                      <th className="p-3 text-right">Score</th>
                      <th className="p-3 text-center">Correct</th>
                      <th className="p-3 text-center">Accuracy</th>
                      <th className="p-3 text-center">Avg Speed</th>
                      <th className="p-3 text-center">Fastest</th>
                      <th className="p-3 text-center">Max Streak</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {participants.map((p: any, idx: number) => {
                      const pStats = p.answers ? calculateParticipantStats(p as Participant, totalQuestions) : null;
                      const pScore = p.score || 0;
                      const pCorrect = pStats ? pStats.correctAnswers : (p.correctCount || 0);
                      const pAccuracy = pStats ? pStats.accuracy : (totalQuestions > 0 ? Math.round((pCorrect / totalQuestions) * 100) : 0);
                      const pAvgTime = pStats ? pStats.averageResponseTime : (p.avgTime || p.totalResponseTime || 0);
                      const pFastest = pStats ? pStats.fastestResponse : (p.fastestResponseSec || pAvgTime);
                      const pStreak = pStats ? pStats.longestCorrectStreak : (p.maxStreak || p.streak || 0);

                      return (
                        <tr key={p.id || idx} className="hover:bg-slate-850 transition">
                          <td className="p-3 font-black text-yellow-400">#{p.rank || idx + 1}</td>
                          <td className="p-3 flex items-center space-x-2 text-white font-bold">
                            <span className="text-base">{p.avatar || '⚡'}</span>
                            <span>{p.name}</span>
                          </td>
                          <td className="p-3 text-right font-mono text-emerald-400 font-extrabold">{pScore} pts</td>
                          <td className="p-3 text-center text-slate-200">{pCorrect} / {totalQuestions}</td>
                          <td className="p-3 text-center">
                            <span className={`px-2 py-0.5 rounded-md font-extrabold text-[11px] ${
                              pAccuracy >= 80 ? 'bg-emerald-500/20 text-emerald-300' :
                              pAccuracy >= 50 ? 'bg-amber-500/20 text-amber-300' : 'bg-rose-500/20 text-rose-300'
                            }`}>
                              {pAccuracy}%
                            </span>
                          </td>
                          <td className="p-3 text-center text-slate-300 font-mono">{pAvgTime}s</td>
                          <td className="p-3 text-center text-cyan-300 font-mono">{pFastest > 0 ? `${pFastest}s` : 'N/A'}</td>
                          <td className="p-3 text-center">
                            <span className="inline-flex items-center space-x-1 text-amber-400 font-extrabold">
                              <span>🔥 {pStreak}</span>
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: EVENT FEEDBACK */}
          {activeTab === 'feedback' && (
            <div className="space-y-4">
              {feedbackList.length === 0 ? (
                <div className="text-center py-12 text-slate-500 font-semibold text-sm bg-slate-900 rounded-2xl border border-slate-800 p-8">
                  No feedback collected for this session yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {feedbackList.map((fb) => (
                    <div key={fb.id} className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="text-xl">{fb.participantAvatar || '⚡'}</span>
                          <span className="font-bold text-white text-sm">{fb.participantName}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-yellow-400">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`w-4 h-4 ${star <= fb.rating ? 'fill-current text-yellow-400' : 'text-slate-700'}`}
                            />
                          ))}
                        </div>
                      </div>

                      {fb.comment && (
                        <p className="text-xs text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800 font-medium">
                          "{fb.comment}"
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
