import React, { useState, useEffect } from 'react';
import { Lightbulb, X } from 'lucide-react';

interface HostQuickTipProps {
  tipId: string;
  tipText: string;
  category?: string;
}

export const HostQuickTip: React.FC<HostQuickTipProps> = ({ tipId, tipText, category }) => {
  const storageKey = `quizpulse_tip_dismissed_${tipId}`;
  const [isDismissed, setIsDismissed] = useState<boolean>(true);

  useEffect(() => {
    const dismissed = localStorage.getItem(storageKey);
    if (dismissed !== 'true') {
      setIsDismissed(false);
    }
  }, [storageKey]);

  const handleDismiss = () => {
    setIsDismissed(true);
    localStorage.setItem(storageKey, 'true');
  };

  if (isDismissed) return null;

  return (
    <div className="bg-amber-400/10 border border-amber-400/30 rounded-2xl p-4 flex items-start justify-between space-x-3 my-4 shadow-md">
      <div className="flex items-start space-x-3">
        <div className="p-2 bg-amber-400/20 text-amber-300 rounded-xl flex-shrink-0 mt-0.5">
          <Lightbulb className="w-4 h-4 stroke-[2.5]" />
        </div>
        <div>
          {category && (
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-400 block mb-0.5">
              Host Pro Tip ({category})
            </span>
          )}
          <p className="text-xs text-amber-100 font-medium leading-relaxed">
            {tipText}
          </p>
        </div>
      </div>
      <button
        onClick={handleDismiss}
        className="text-amber-300/70 hover:text-amber-200 p-1 hover:bg-amber-400/20 rounded-lg transition"
        title="Dismiss tip"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
