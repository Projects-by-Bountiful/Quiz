import React, { useState, useEffect, useRef } from 'react';
import { 
  Clock, Pause, Play, SkipForward, CheckCircle2, XCircle, Flame, Trophy, 
  Users, HelpCircle, Sparkles, ArrowRight, Square, Command, Plus, Minus, Maximize2, Zap, Layers, ListOrdered, ArrowRightLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { GameSession, Question, Participant } from '../types';
import { soundEffects } from '../utils/sound';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';
import { MultipleChoiceQuestion } from './questions/MultipleChoiceQuestion';
import { FastestFingersQuestion } from './questions/FastestFingersQuestion';
import { FillBlankQuestion } from './questions/FillBlankQuestion';
import { OrderingQuestion } from './questions/OrderingQuestion';
import { MatchingQuestion } from './questions/MatchingQuestion';
import { useSynchronizedTimer } from '../utils/useSynchronizedTimer';

interface QuestionViewProps {
  session: GameSession;
  isHost: boolean;
  participantId?: string;
  onSubmitAnswer: (rawAnswer: any, timeTakenSec: number) => void;
  onHostAction: (action: string, payload?: any) => void;
  soundEnabled: boolean;
  connectionStatus?: 'connected' | 'reconnecting' | 'disconnected';
  showBackOnlineToast?: boolean;
}

export const QuestionView: React.FC<QuestionViewProps> = ({
  session,
  isHost,
  participantId,
  onSubmitAnswer,
  onHostAction,
  soundEnabled,
  connectionStatus,
  showBackOnlineToast
}) => {
  const currentQ: Question | undefined = session.questions[session.currentQuestionIndex];
  const participant: Participant | undefined = participantId ? session.participants[participantId] : undefined;
  
  const existingAnswer = currentQ ? participant?.answers[currentQ.id] : undefined;

  const [localAnswer, setLocalAnswer] = useState<any>(() => {
    if (existingAnswer) {
      if (existingAnswer.selectedOption !== undefined) return existingAnswer.selectedOption;
      if (existingAnswer.textAnswer !== undefined) return existingAnswer.textAnswer;
      if (existingAnswer.orderAnswer !== undefined) return existingAnswer.orderAnswer;
      if (existingAnswer.matchingAnswer !== undefined) return existingAnswer.matchingAnswer;
      if (existingAnswer.rawAnswer !== undefined) return existingAnswer.rawAnswer;
    }
    return null;
  });

  const [showSidebar, setShowSidebar] = useState(true);
  const [showShortcutsModal, setShowShortcutsModal] = useState(false);

  const isRevealPhase = session.status === 'ANSWER_REVEAL';
  const totalTimeLimit = currentQ?.estimatedTimeSec || session.settings.timerDurationSec || 20;

  // Authoritative Synchronized Countdown
  const synchronizedRemaining = useSynchronizedTimer({
    questionStartTime: session.questionStartTime || session.settings?.questionStartTime,
    timerDurationSec: totalTimeLimit,
    isPaused: session.isTimerPaused,
    isHost,
    onExpire: () => {
      if (isHost && !isRevealPhase) {
        onHostAction('REVEAL_ANSWER');
      }
    }
  });

  const timerRemaining = isRevealPhase ? 0 : synchronizedRemaining;
  const revealRemaining = session.revealTimerRemaining !== undefined ? session.revealTimerRemaining : 5;

  const bonusFiredRef = useRef<Set<string>>(new Set());

  // Trigger lightweight confetti burst for speed bonus
  useEffect(() => {
    if (!isHost && currentQ && existingAnswer && existingAnswer.isCorrect && existingAnswer.speedBonus > 0) {
      if (!bonusFiredRef.current.has(currentQ.id)) {
        bonusFiredRef.current.add(currentQ.id);
        try {
          confetti({
            particleCount: 30,
            spread: 60,
            ticks: 100,
            origin: { y: 0.7 },
            colors: ['#facc15', '#22d3ee', '#38bdf8']
          });
        } catch (e) {}
      }
    }
  }, [currentQ?.id, existingAnswer?.isCorrect, existingAnswer?.speedBonus, isHost]);

  // Urgent sound effects & confetti on reveal
  useEffect(() => {
    if (soundEnabled && !isRevealPhase && timerRemaining > 0 && timerRemaining <= 5 && !session.isTimerPaused) {
      soundEffects.urgentTick();
    }
  }, [timerRemaining, soundEnabled, session.isTimerPaused, isRevealPhase]);

  useEffect(() => {
    if (isRevealPhase) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  }, [isRevealPhase]);

  // Reset or initialize local answer when question changes
  useEffect(() => {
    if (existingAnswer) {
      if (existingAnswer.selectedOption !== undefined) setLocalAnswer(existingAnswer.selectedOption);
      else if (existingAnswer.textAnswer !== undefined) setLocalAnswer(existingAnswer.textAnswer);
      else if (existingAnswer.orderAnswer !== undefined) setLocalAnswer(existingAnswer.orderAnswer);
      else if (existingAnswer.matchingAnswer !== undefined) setLocalAnswer(existingAnswer.matchingAnswer);
      else if (existingAnswer.rawAnswer !== undefined) setLocalAnswer(existingAnswer.rawAnswer);
    } else {
      setLocalAnswer(null);
    }
  }, [session.currentQuestionIndex, currentQ?.id, existingAnswer]);

  // Host Keyboard Shortcuts Listener
  useEffect(() => {
    if (!isHost) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      if (activeEl && ['INPUT', 'TEXTAREA', 'SELECT'].includes(activeEl.tagName)) {
        return;
      }

      const key = e.key.toLowerCase();

      if (key === ' ') {
        e.preventDefault();
        onHostAction('PAUSE_TIMER');
      } else if (key === 's' || key === 'r') {
        onHostAction('SKIP_QUESTION');
      } else if (key === 'n') {
        onHostAction('NEXT_QUESTION');
      } else if (key === 'l') {
        setShowSidebar(prev => !prev);
      } else if (key === 'c') {
        confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
      } else if (key === 'f') {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      } else if (key === 'k') {
        setShowShortcutsModal(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isHost, onHostAction]);

  if (!currentQ) {
    return (
      <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white flex items-center justify-center p-6">
        <p className="text-xl font-bold text-slate-400 animate-pulse">Loading question data...</p>
      </div>
    );
  }

  const handleGenericSubmitAnswer = (rawAns: any) => {
    if (isHost || isRevealPhase) return;
    if (existingAnswer && !session.settings.allowAnswerChange) return;

    const taken = Math.max(0.5, totalTimeLimit - timerRemaining);
    setLocalAnswer(rawAns);
    onSubmitAnswer(rawAns, taken);

    if (soundEnabled) {
      soundEffects.click();
    }
  };

  const participantsList = (Object.values(session.participants || {}) as Participant[])
    .sort((a, b) => (b.score || 0) - (a.score || 0));

  const totalResponded = participantsList.filter(p => p.answers && p.answers[currentQ.id]).length;
  const timerPercent = Math.max(0, Math.min(100, (timerRemaining / totalTimeLimit) * 100));
  const isUserCorrect = existingAnswer ? existingAnswer.isCorrect : false;

  const qType = currentQ.type || 'multiple_choice';
  const typeBadgeStyle = getQuestionTypeBadgeColor(qType);
  const typeLabel = getQuestionTypeLabel(qType);

  const isLocked = !isHost && existingAnswer !== undefined && !session.settings.allowAnswerChange;

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white p-3 sm:p-6 md:p-8 font-sans">
      
      {/* Top Header Controls Bar */}
      <div className="max-w-7xl mx-auto mb-6 flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl">
        
        {/* Question Counter & Category Badge */}
        <div className="flex items-center space-x-3">
          <span className="px-4 py-1.5 bg-yellow-400 text-slate-950 rounded-2xl text-xs sm:text-sm font-black uppercase tracking-wider shadow-md shadow-yellow-400/20">
            Q {session.currentQuestionIndex + 1} / {session.questions.length}
          </span>
          <span className={`px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider border ${typeBadgeStyle.bg} ${typeBadgeStyle.text} ${typeBadgeStyle.border}`}>
            {typeLabel}
          </span>
          <span className="text-xs sm:text-sm text-cyan-400 font-extrabold uppercase tracking-widest hidden md:inline">
            {currentQ.category} • {currentQ.difficulty}
          </span>
        </div>

        {/* Sync Timer Display & Live Controls */}
        <div className="flex items-center space-x-3">
          
          {/* Host Live Timer Controls */}
          {isHost && (
            <div className="flex items-center space-x-1.5 mr-2">
              <button
                onClick={() => onHostAction('ADJUST_TIMER', { deltaSec: -5 })}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-rose-400 text-xs font-black rounded-xl border border-slate-700 transition-colors"
                title="Subtract 5s"
              >
                <Minus className="w-3.5 h-3.5 inline mr-0.5" />5s
              </button>
              <button
                onClick={() => onHostAction('ADJUST_TIMER', { deltaSec: 5 })}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-black rounded-xl border border-slate-700 transition-colors"
                title="Add 5s"
              >
                <Plus className="w-3.5 h-3.5 inline mr-0.5" />5s
              </button>
            </div>
          )}

          {/* Master Synchronized Timer Badge */}
          <div className={`flex items-center space-x-2 px-5 py-2 rounded-2xl font-mono text-xl sm:text-2xl font-black shadow-lg transition-colors border ${
            timerRemaining <= 5 && !isRevealPhase
              ? 'bg-rose-500/20 border-rose-500 text-rose-400 animate-pulse ring-2 ring-rose-500/50'
              : session.isTimerPaused
              ? 'bg-amber-500/20 border-amber-400 text-amber-300'
              : 'bg-slate-800/90 border-slate-700 text-white'
          }`}>
            <Clock className={`w-5 h-5 ${timerRemaining <= 5 && !isRevealPhase ? 'text-rose-400' : 'text-yellow-400'}`} />
            <span>
              {isRevealPhase ? `Reveal (${revealRemaining}s)` : `${timerRemaining}s`}
            </span>
          </div>

          {/* Host Control Action Buttons */}
          {isHost && (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => onHostAction('PAUSE_TIMER')}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-2xl border border-slate-700 transition-colors"
                title={session.isTimerPaused ? "Resume Timer (Space)" : "Pause Timer (Space)"}
              >
                {session.isTimerPaused ? <Play className="w-5 h-5 text-emerald-400" /> : <Pause className="w-5 h-5 text-yellow-400" />}
              </button>

              {!isRevealPhase ? (
                <button
                  onClick={() => onHostAction('SKIP_QUESTION')}
                  className="px-4 py-2.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-2xl transition-all shadow-md"
                  title="Reveal Answer (S)"
                >
                  <SkipForward className="w-4 h-4 inline mr-1" />
                  <span>Reveal</span>
                </button>
              ) : (
                <button
                  onClick={() => onHostAction('NEXT_QUESTION')}
                  className="px-4 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-2xl transition-all shadow-md"
                  title="Next Question (N)"
                >
                  <ArrowRight className="w-4 h-4 inline mr-1" />
                  <span>Next Q</span>
                </button>
              )}

              <button
                onClick={() => setShowShortcutsModal(true)}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-yellow-400 rounded-2xl border border-slate-700 transition-colors hidden sm:block"
                title="Host Keyboard Shortcuts (K)"
              >
                <Command className="w-5 h-5" />
              </button>

              <button
                onClick={() => {
                  if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen().catch(() => {});
                  } else {
                    document.exitFullscreen().catch(() => {});
                  }
                }}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl border border-slate-700 transition-colors hidden sm:block"
                title="Toggle Fullscreen Presenter Mode (F)"
              >
                <Maximize2 className="w-5 h-5" />
              </button>

              <button
                onClick={() => onHostAction('END_GAME')}
                className="px-3.5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wider rounded-2xl transition-all shadow-md flex items-center space-x-1.5"
                title="End session immediately"
              >
                <Square className="w-4 h-4 fill-current" />
                <span className="hidden md:inline">Stop</span>
              </button>
            </div>
          )}
        </div>

      </div>

      {/* Main Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Question Content & Choices */}
        <div className={`${showSidebar ? 'lg:col-span-8' : 'lg:col-span-12'} space-y-6 transition-all`}>
          
          {/* Synchronized Timer Progress Line */}
          {!isRevealPhase && (
            <div className="w-full bg-slate-900 rounded-full h-3 sm:h-4 overflow-hidden border border-slate-800 p-0.5 shadow-inner">
              <div
                className={`h-full rounded-full transition-all duration-300 ease-linear ${
                  timerRemaining <= 5 ? 'bg-rose-500 shadow-rose-500/50' : 'bg-gradient-to-r from-emerald-400 via-cyan-400 to-yellow-400'
                }`}
                style={{ width: `${timerPercent}%` }}
              />
            </div>
          )}

          {/* Connection Recovery Toasts */}
          {connectionStatus === 'reconnecting' && (
            <div className="bg-amber-500/20 border border-amber-400/40 rounded-2xl p-3 px-5 flex items-center justify-between text-amber-200 text-xs font-bold shadow-lg animate-pulse">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Connection interrupted. Reconnecting...</span>
              </div>
              <span className="text-[10px] text-amber-300 uppercase tracking-wider font-extrabold">Auto-syncing</span>
            </div>
          )}

          {showBackOnlineToast && (
            <div className="bg-emerald-500/20 border border-emerald-400/40 rounded-2xl p-3 px-5 flex items-center justify-between text-emerald-200 text-xs font-bold shadow-lg">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Back online. Sync restored!</span>
              </div>
            </div>
          )}

          {/* Answer Submission Status Badge */}
          {!isRevealPhase && !isHost && (localAnswer !== null || existingAnswer) && (
            <div className="bg-emerald-950/90 border border-emerald-400/50 rounded-2xl p-3 px-5 flex items-center justify-between text-emerald-200 text-xs font-bold shadow-lg">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>
                  {qType === 'multiple_choice' || qType === 'fastest_fingers'
                    ? `Answer Locked (Option ${String.fromCharCode(65 + Number(localAnswer))})`
                    : 'Response Submitted & Recorded'}
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-900/80 px-2.5 py-1 rounded-full uppercase tracking-wider font-extrabold border border-emerald-400/30">
                SAVED
              </span>
            </div>
          )}

          {/* Answer Outcome Banner (During Reveal Phase) */}
          {isRevealPhase && !isHost && existingAnswer && (
            <div
              className={`p-6 rounded-3xl border-2 flex items-center justify-between shadow-2xl ${
                isUserCorrect ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100 shadow-emerald-500/20' : 'bg-rose-950/90 border-rose-500 text-rose-100 shadow-rose-500/20'
              }`}
            >
              <div className="flex items-center space-x-4">
                {isUserCorrect ? (
                  <div className="w-14 h-14 rounded-2xl bg-emerald-400 text-slate-950 flex items-center justify-center font-black flex-shrink-0 shadow-lg">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-rose-500 text-white flex items-center justify-center font-black flex-shrink-0 shadow-lg">
                    <XCircle className="w-8 h-8" />
                  </div>
                )}
                <div>
                  <h3 className="text-2xl font-black tracking-tight">
                    {isUserCorrect ? 'Bingo! Correct Answer!' : 'Incorrect'}
                  </h3>
                  <p className="text-sm font-bold opacity-90 mt-0.5">
                    {isUserCorrect ? `+${existingAnswer.scoreGained} Points (${existingAnswer.speedBonus > 0 ? `+${existingAnswer.speedBonus} speed bonus` : 'base score'})` : 'Better luck on the next question!'}
                  </p>
                </div>
              </div>

              {participant && participant.streak > 1 && (
                <div className="flex items-center space-x-1.5 px-4 py-2 bg-yellow-400 text-slate-950 rounded-2xl text-xs font-black shadow-lg animate-bounce">
                  <Flame className="w-4 h-4 fill-current text-slate-950" />
                  <span>{participant.streak} STREAK</span>
                </div>
              )}
            </div>
          )}

          {/* Question Display Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 text-white shadow-2xl relative overflow-hidden border-t-4 border-t-yellow-400 min-h-[160px] flex flex-col justify-between">
            <div className="flex items-center justify-between mb-3">
              <span className="text-yellow-400 font-black text-xs uppercase tracking-widest inline-block">
                {currentQ.category}
              </span>
              <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-lg uppercase tracking-wider border ${typeBadgeStyle.bg} ${typeBadgeStyle.text} ${typeBadgeStyle.border}`}>
                {typeLabel}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black leading-tight tracking-tight text-white break-words">
              {currentQ.question}
            </h2>
          </div>

          {/* Dynamic Question Type Interactive Engine */}
          <div className="w-full min-h-[220px]">
            {qType === 'multiple_choice' && (
              <MultipleChoiceQuestion
                question={currentQ}
                selectedOption={typeof localAnswer === 'number' ? localAnswer : null}
                onSelectOption={handleGenericSubmitAnswer}
                disabled={isLocked || isRevealPhase}
                isHost={isHost}
              />
            )}

            {qType === 'fastest_fingers' && (
              <FastestFingersQuestion
                question={currentQ}
                selectedOption={typeof localAnswer === 'number' ? localAnswer : null}
                onSelectOption={handleGenericSubmitAnswer}
                disabled={isLocked || isRevealPhase}
                isHost={isHost}
              />
            )}

            {qType === 'fill_blank' && (
              <FillBlankQuestion
                question={currentQ}
                submittedAnswer={typeof localAnswer === 'string' ? localAnswer : null}
                onSubmitAnswer={handleGenericSubmitAnswer}
                disabled={isLocked || isRevealPhase}
                isHost={isHost}
              />
            )}

            {qType === 'ordering' && (
              <OrderingQuestion
                question={currentQ}
                submittedOrder={Array.isArray(localAnswer) ? localAnswer : null}
                onSubmitOrder={handleGenericSubmitAnswer}
                disabled={isLocked || isRevealPhase}
                isHost={isHost}
              />
            )}

            {qType === 'matching' && (
              <MatchingQuestion
                question={currentQ}
                submittedMatches={localAnswer && typeof localAnswer === 'object' && !Array.isArray(localAnswer) ? localAnswer : null}
                onSubmitMatches={handleGenericSubmitAnswer}
                disabled={isLocked || isRevealPhase}
                isHost={isHost}
              />
            )}
          </div>

          {/* Explanation Box */}
          {isRevealPhase && currentQ.explanation && (
            <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl text-sm text-slate-200 flex items-start space-x-4 shadow-xl border-l-4 border-l-cyan-400">
              <HelpCircle className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-black text-cyan-400 block mb-1 uppercase tracking-wider text-xs">Explanation</span>
                <p className="leading-relaxed font-semibold text-base">{currentQ.explanation}</p>
              </div>
            </div>
          )}

          {/* Host Real-Time Answer Counter */}
          {isHost && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 font-black uppercase tracking-wider">
                <span className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-yellow-400" />
                  <span>Responses In: {totalResponded} / {participantsList.length}</span>
                </span>
                <span className="text-emerald-400 font-bold">● Synchronized Live</span>
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Compact Real-Time Leaderboard Sidebar */}
        {showSidebar && (
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4 sticky top-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-400 fill-current" />
                <h3 className="text-base font-black text-white">Live Leaderboard</h3>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-400/10 px-2.5 py-0.5 rounded-full border border-emerald-400/30 font-extrabold uppercase tracking-wider">
                {participantsList.length} Players
              </span>
            </div>

            {participantsList.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs font-semibold">
                Waiting for players to join & answer...
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-1">
                {participantsList.map((p, idx) => {
                  const hasAnsweredCurrent = currentQ && p.answers && p.answers[currentQ.id];
                  const isLeader = idx === 0;

                  return (
                    <div
                      key={p.id || `participant-${idx}`}
                      className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                        isLeader
                          ? 'bg-yellow-400/10 border-yellow-400/60 text-white shadow-md'
                          : 'bg-slate-950/80 border-slate-800 text-slate-100'
                      }`}
                    >
                      <div className="flex items-center space-x-3 overflow-hidden">
                        <span className={`w-8 h-8 rounded-xl font-black text-xs flex items-center justify-center flex-shrink-0 ${
                          idx === 0
                            ? 'bg-yellow-400 text-slate-950 shadow'
                            : idx === 1
                            ? 'bg-cyan-400 text-slate-950'
                            : idx === 2
                            ? 'bg-pink-500 text-white'
                            : 'bg-slate-800 text-slate-300'
                        }`}>
                          {idx === 0 ? '👑' : `#${idx + 1}`}
                        </span>

                        <span className="text-2xl flex-shrink-0">{p.avatar}</span>

                        <div className="truncate">
                          <div className="flex items-center space-x-1.5">
                            <p className="font-bold text-sm truncate">{p.name}</p>
                            {p.id === participantId && (
                              <span className="text-[9px] bg-yellow-400/20 px-1.5 py-0.5 rounded text-yellow-300 font-black">YOU</span>
                            )}
                          </div>

                          <div className="flex items-center space-x-2 mt-0.5">
                            {hasAnsweredCurrent ? (
                              <span className="text-[10px] text-emerald-400 font-bold flex items-center">
                                <CheckCircle2 className="w-3 h-3 mr-0.5 inline" />
                                Locked In
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-500 font-semibold italic">
                                Thinking...
                              </span>
                            )}

                            {p.streak > 1 && (
                              <span className="text-[10px] text-yellow-400 font-extrabold flex items-center">
                                <Flame className="w-3 h-3 mr-0.5 fill-current" />
                                {p.streak}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right flex-shrink-0 ml-2">
                        <p className="font-black text-yellow-400 text-sm font-mono">{p.score} pts</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

      </div>

      {/* Host Keyboard Shortcuts Cheatsheet Modal */}
      {showShortcutsModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
              <Command className="w-5 h-5 text-yellow-400" />
              <h3 className="text-lg font-black text-white">Host Keyboard Shortcuts</h3>
            </div>

            <div className="space-y-2 text-xs font-semibold">
              <div className="flex justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-300">Spacebar</span>
                <span className="text-yellow-400 font-black">Pause / Resume Timer</span>
              </div>
              <div className="flex justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-300">S or R key</span>
                <span className="text-yellow-400 font-black">Skip Question / Reveal Answer</span>
              </div>
              <div className="flex justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-300">N key</span>
                <span className="text-yellow-400 font-black">Next Question</span>
              </div>
              <div className="flex justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-300">L key</span>
                <span className="text-yellow-400 font-black">Toggle Leaderboard Sidebar</span>
              </div>
              <div className="flex justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-300">F key</span>
                <span className="text-yellow-400 font-black">Toggle Fullscreen Presenter Mode</span>
              </div>
              <div className="flex justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-300">C key</span>
                <span className="text-yellow-400 font-black">Trigger Confetti Celebration</span>
              </div>
            </div>

            <button
              onClick={() => setShowShortcutsModal(false)}
              className="w-full py-3 bg-yellow-400 text-slate-950 font-black text-xs rounded-xl mt-2"
            >
              Close Cheatsheet
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
