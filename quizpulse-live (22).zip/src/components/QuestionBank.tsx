import React, { useState } from 'react';
import { 
  Folder, Plus, Search, Filter, Download, Upload, Trash2, Edit2, Copy, 
  Check, ArrowLeft, ArrowRightLeft, CheckSquare, Square, BookOpen, AlertCircle,
  FolderPlus, MoveRight, Layers, FileText, Zap, Play, Eye, ListOrdered
} from 'lucide-react';
import { Question, Category, Difficulty, QuestionType, DEFAULT_CATEGORIES } from '../types';
import { exportQuestionsToCSV } from '../utils/csv';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';
import { BulkPasteModal } from './BulkPasteModal';
import { CSVImportModal } from './CSVImportModal';
import { AddQuestionRepeaterModal } from './AddQuestionRepeaterModal';
import { QuizCreationWizardModal } from './QuizCreationWizardModal';
import { ParticipantQuestionPreviewModal } from './ParticipantQuestionPreviewModal';

interface QuestionBankProps {
  questions: Question[];
  categories: Category[];
  onAddCategory: (categoryName: string) => void;
  onRenameCategory: (oldName: string, newName: string) => void;
  onDeleteCategory: (categoryName: string) => void;
  onAddQuestion: (newQ: Question) => void;
  onUpdateQuestion: (updatedQ: Question) => void;
  onDeleteQuestion: (id: string) => void;
  onBulkDeleteQuestions: (ids: string[]) => void;
  onMoveQuestionsCategory: (ids: string[], newCategory: Category) => void;
  onImportQuestions: (imported: Question[]) => Promise<{ success: boolean; count?: number; error?: string }> | void;
  onCreateSession?: (title: string, settings: any, selectedQuestionIds?: string[]) => void;
}

export const QuestionBank: React.FC<QuestionBankProps> = ({
  questions = [],
  categories = [],
  onAddCategory,
  onRenameCategory,
  onDeleteCategory,
  onAddQuestion,
  onUpdateQuestion,
  onDeleteQuestion,
  onBulkDeleteQuestions,
  onMoveQuestionsCategory,
  onImportQuestions,
  onCreateSession
}) => {
  const safeQuestions = questions || [];
  const safeCategories = categories || [];

  // Navigation view: null = Category Cards Grid; string = Category detail view
  const [activeCategoryView, setActiveCategoryView] = useState<Category | null>(null);

  // Filters & selection
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | 'All'>('All');
  const [selectedType, setSelectedType] = useState<QuestionType | 'All'>('All');
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<Set<string>>(new Set());

  // Modals
  const [isBulkPasteOpen, setIsBulkPasteOpen] = useState(false);
  const [isCSVModalOpen, setIsCSVModalOpen] = useState(false);
  const [uploadedCSVText, setUploadedCSVText] = useState('');
  const [isRepeaterModalOpen, setIsRepeaterModalOpen] = useState(false);
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [editingCategoryName, setEditingCategoryName] = useState<string | null>(null);
  const [renameInputValue, setRenameInputValue] = useState('');

  // Move category modal
  const [isMoveModalOpen, setIsMoveModalOpen] = useState(false);
  const [targetMoveCategory, setTargetMoveCategory] = useState<Category>(safeCategories[0] || 'General Knowledge');

  // CSV / Deletion Import feedback banner
  const [importNotification, setImportNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // All available category list combined with existing question categories
  const allCategories = Array.from(new Set([...DEFAULT_CATEGORIES, ...safeCategories, ...safeQuestions.map(q => q.category)]));

  // Category statistics map
  const categoryCounts = allCategories.reduce((acc, cat) => {
    acc[cat] = safeQuestions.filter(q => q && q.category && q.category.toLowerCase() === cat.toLowerCase()).length;
    return acc;
  }, {} as Record<string, number>);

  // Questions filtered for current category detail view
  const categoryQuestions = activeCategoryView 
    ? questions.filter(q => q.category.toLowerCase() === activeCategoryView.toLowerCase())
    : [];

  const filteredQuestions = categoryQuestions.filter(q => {
    const qType = q.type || 'multiple_choice';
    const matchesDiff = selectedDifficulty === 'All' || q.difficulty === selectedDifficulty;
    const matchesType = selectedType === 'All' || qType === selectedType;
    const matchesSearch = searchTerm.trim() === '' || 
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesDiff && matchesType && matchesSearch;
  });

  // Handlers
  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCategoryInput.trim()) {
      onAddCategory(newCategoryInput.trim());
      setNewCategoryInput('');
      setIsAddingCategory(false);
    }
  };

  const handleStartRenameCategory = (cat: string) => {
    setEditingCategoryName(cat);
    setRenameInputValue(cat);
  };

  const handleSaveRenameCategory = (oldCat: string) => {
    if (renameInputValue.trim() && renameInputValue.trim() !== oldCat) {
      onRenameCategory(oldCat, renameInputValue.trim());
      if (activeCategoryView === oldCat) {
        setActiveCategoryView(renameInputValue.trim());
      }
    }
    setEditingCategoryName(null);
  };

  const handleDeleteCategoryWithConfirm = (cat: string) => {
    const count = categoryCounts[cat] || 0;
    if (confirm(`Are you sure you want to delete the category "${cat}"? ${count > 0 ? `This will also remove ${count} questions!` : ''}`)) {
      onDeleteCategory(cat);
      if (activeCategoryView === cat) {
        setActiveCategoryView(null);
      }
      setImportNotification({
        message: `Deleted category "${cat}" and ${count} associated questions.`,
        type: 'success'
      });
    }
  };

  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const csvText = event.target?.result as string;
        if (csvText) {
          setUploadedCSVText(csvText);
          setIsCSVModalOpen(true);
        }
      };
      reader.readAsText(file);
      e.target.value = ''; // Reset input
    }
  };

  const handleToggleSelectQuestion = (id: string) => {
    const next = new Set(selectedQuestionIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedQuestionIds(next);
  };

  const handleSelectAllInView = () => {
    if (selectedQuestionIds.size === filteredQuestions.length) {
      setSelectedQuestionIds(new Set());
    } else {
      setSelectedQuestionIds(new Set(filteredQuestions.map(q => q.id)));
    }
  };

  const handleDeleteSingleQuestion = (id: string) => {
    if (confirm('Are you sure you want to delete this question?')) {
      onDeleteQuestion(id);
      setSelectedQuestionIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      setImportNotification({
        message: 'Question successfully deleted.',
        type: 'success'
      });
    }
  };

  const handleBulkDelete = () => {
    if (selectedQuestionIds.size === 0) return;
    const count = selectedQuestionIds.size;
    if (confirm(`Are you sure you want to delete ${count} selected questions?`)) {
      onBulkDeleteQuestions(Array.from(selectedQuestionIds));
      setSelectedQuestionIds(new Set());
      setImportNotification({
        message: `Successfully deleted ${count} questions.`,
        type: 'success'
      });
    }
  };

  const handleConfirmMoveCategory = () => {
    if (selectedQuestionIds.size === 0) return;
    onMoveQuestionsCategory(Array.from(selectedQuestionIds), targetMoveCategory);
    setSelectedQuestionIds(new Set());
    setIsMoveModalOpen(false);
    setImportNotification({
      message: `Moved ${selectedQuestionIds.size} questions to "${targetMoveCategory}".`,
      type: 'success'
    });
  };

  const handleQuestionsAddedFromRepeater = (newQuestions: Question[]) => {
    onImportQuestions(newQuestions);
    setImportNotification({
      message: `Successfully added ${newQuestions.length} ${newQuestions.length === 1 ? 'question' : 'questions'} via repeater form!`,
      type: 'success'
    });
  };

  const handleQuestionUpdatedFromModal = (updatedQuestion: Question) => {
    onUpdateQuestion(updatedQuestion);
    setImportNotification({
      message: 'Question updated successfully.',
      type: 'success'
    });
  };

  const handleDuplicate = (q: Question) => {
    const dup: Question = {
      ...q,
      id: `q_${Date.now()}_dup`,
      question: `${q.question} (Copy)`
    };
    onAddQuestion(dup);
    setImportNotification({
      message: 'Question duplicated.',
      type: 'success'
    });
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white p-4 sm:p-6 md:p-8 max-w-7xl mx-auto w-full space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-yellow-400 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-yellow-400/20">
            <Layers className="w-7 h-7 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Question Bank Management
            </h1>
            <p className="text-xs text-slate-400 font-semibold mt-0.5">
              Category-Driven Database • {questions.length} Total Questions across {allCategories.length} Categories
            </p>
          </div>
        </div>

        {/* Global Action Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          {onCreateSession && (
            <button
              onClick={() => setIsSessionModalOpen(true)}
              className="px-4 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black text-xs sm:text-sm rounded-2xl shadow-lg shadow-yellow-400/20 flex items-center space-x-2 transition-transform active:scale-95"
            >
              <Zap className="w-4 h-4 fill-current text-slate-950" />
              <span>Launch Quiz Session</span>
            </button>
          )}

          <button
            onClick={() => setIsBulkPasteOpen(true)}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 font-bold text-xs sm:text-sm rounded-2xl flex items-center space-x-2 transition-transform active:scale-95"
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>Bulk Paste Questions</span>
          </button>

          <button
            onClick={() => {
              setEditingQuestion(null);
              setIsRepeaterModalOpen(true);
            }}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs sm:text-sm rounded-2xl shadow flex items-center space-x-2 transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>+ Add Questions (Repeater)</span>
          </button>

          <label className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm rounded-2xl border border-slate-700 cursor-pointer flex items-center space-x-2">
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Import CSV</span>
            <input type="file" accept=".csv" onChange={handleCSVUpload} className="hidden" />
          </label>

          <button
            onClick={() => exportQuestionsToCSV(questions, { category: activeCategoryView || undefined })}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm rounded-2xl border border-slate-700 flex items-center space-x-2"
          >
            <Download className="w-4 h-4 text-amber-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Notification Banner */}
      {importNotification && (
        <div className={`p-4 rounded-2xl border text-xs sm:text-sm font-bold flex items-center justify-between ${
          importNotification.type === 'success' 
            ? 'bg-emerald-950/80 border-emerald-400 text-emerald-300' 
            : 'bg-rose-950/80 border-rose-500 text-rose-300'
        }`}>
          <span>{importNotification.message}</span>
          <button onClick={() => setImportNotification(null)} className="text-xs uppercase font-black underline ml-4">Dismiss</button>
        </div>
      )}

      {/* VIEW 1: CATEGORY GRID VIEW */}
      {!activeCategoryView ? (
        <div className="space-y-6">
          
          {/* Section Header & Add Category Button */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-black text-white">Quiz Categories</h2>
              <p className="text-xs text-slate-400">Select a category to manage, search, or edit contained questions</p>
            </div>

            <button
              onClick={() => setIsAddingCategory(true)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-yellow-400 font-bold text-xs rounded-2xl border border-slate-700 flex items-center space-x-1.5"
            >
              <FolderPlus className="w-4 h-4" />
              <span>+ Add Custom Category</span>
            </button>
          </div>

          {/* Add Category Form Modal / Inline Box */}
          {isAddingCategory && (
            <form onSubmit={handleCreateCategory} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center space-x-3">
              <input
                type="text"
                value={newCategoryInput}
                onChange={(e) => setNewCategoryInput(e.target.value)}
                placeholder="Enter custom category name (e.g. Freelancer360, Cybersecurity...)"
                className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-yellow-400"
                autoFocus
                required
              />
              <button type="submit" className="px-5 py-2.5 bg-yellow-400 text-slate-950 font-black text-xs rounded-xl">
                Create
              </button>
              <button type="button" onClick={() => setIsAddingCategory(false)} className="px-4 py-2.5 bg-slate-800 text-slate-400 text-xs rounded-xl">
                Cancel
              </button>
            </form>
          )}

          {/* Categories Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {allCategories.map((cat) => {
              const count = categoryCounts[cat] || 0;
              const isEditing = editingCategoryName === cat;

              return (
                <div
                  key={cat}
                  className="bg-slate-900 border border-slate-800 hover:border-yellow-400/60 rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between transition-all group relative"
                >
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 text-yellow-400 flex items-center justify-center font-black group-hover:scale-110 transition-transform shadow-inner">
                      <Folder className="w-6 h-6 stroke-[2.5]" />
                    </div>

                    {/* Category Menu Actions */}
                    <div className="flex items-center space-x-1 opacity-80 group-hover:opacity-100">
                      <button
                        onClick={() => handleStartRenameCategory(cat)}
                        className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                        title="Rename Category"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategoryWithConfirm(cat)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800"
                        title="Delete Category"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div>
                    {isEditing ? (
                      <div className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={renameInputValue}
                          onChange={(e) => setRenameInputValue(e.target.value)}
                          className="px-2.5 py-1 bg-slate-950 border border-yellow-400 rounded-lg text-white text-sm font-bold w-full"
                          autoFocus
                        />
                        <button
                          onClick={() => handleSaveRenameCategory(cat)}
                          className="px-3 py-1 bg-yellow-400 text-slate-950 font-black text-xs rounded-lg"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <>
                        <h3 className="text-xl font-black text-white group-hover:text-yellow-300 transition-colors">
                          {cat}
                        </h3>
                        <p className="text-xs text-slate-400 font-bold mt-1">
                          {count} Questions Available
                        </p>
                      </>
                    )}
                  </div>

                  <button
                    onClick={() => setActiveCategoryView(cat)}
                    className="w-full py-3 px-4 bg-slate-950 hover:bg-yellow-400 hover:text-slate-950 text-slate-200 font-black text-xs rounded-2xl border border-slate-800 transition-all flex items-center justify-between"
                  >
                    <span>VIEW CATEGORY QUESTIONS</span>
                    <ArrowRightLeft className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>

        </div>
      ) : (
        
        /* VIEW 2: DEDICATED CATEGORY DETAIL VIEW */
        <div className="space-y-6">
          
          {/* Category Detail Navigation Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => {
                  setActiveCategoryView(null);
                  setSelectedQuestionIds(new Set());
                }}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl transition-colors"
                title="Back to Categories"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-black uppercase text-yellow-400 tracking-wider">Category View</span>
                  <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 text-[10px] font-black">
                    {categoryQuestions.length} Questions
                  </span>
                </div>
                <h2 className="text-2xl font-black text-white">{activeCategoryView}</h2>
              </div>
            </div>

            {/* Bulk Action Controls */}
            {selectedQuestionIds.size > 0 && (
              <div className="flex flex-wrap items-center gap-2 bg-slate-950 p-2 rounded-2xl border border-slate-800">
                <span className="text-xs font-black text-yellow-400 px-3">
                  {selectedQuestionIds.size} Selected
                </span>

                {onCreateSession && (
                  <button
                    onClick={() => setIsSessionModalOpen(true)}
                    className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl flex items-center space-x-1.5 shadow"
                  >
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    <span>Launch Quiz ({selectedQuestionIds.size})</span>
                  </button>
                )}

                <button
                  onClick={() => setIsMoveModalOpen(true)}
                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl flex items-center space-x-1.5"
                >
                  <MoveRight className="w-3.5 h-3.5" />
                  <span>Move to Category</span>
                </button>

                <button
                  onClick={handleBulkDelete}
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl flex items-center space-x-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Selected</span>
                </button>
              </div>
            )}
          </div>

          {/* Search, Difficulty Filter, Type Filter & Select All Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
            
            {/* Search Input */}
            <div className="sm:col-span-2 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`Search questions inside ${activeCategoryView}...`}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-yellow-400 font-medium"
              />
            </div>

            {/* Question Type Filter */}
            <div>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as any)}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-yellow-400 font-semibold"
              >
                <option value="All">All Question Types</option>
                <option value="multiple_choice">Multiple Choice</option>
                <option value="fastest_fingers">Fastest Fingers</option>
                <option value="fill_blank">Fill in the Blank</option>
                <option value="ordering">Ordering / Ranking</option>
                <option value="matching">Matching Pairs</option>
              </select>
            </div>

            {/* Difficulty Filter */}
            <div>
              <select
                value={selectedDifficulty}
                onChange={(e) => setSelectedDifficulty(e.target.value as any)}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-yellow-400 font-semibold"
              >
                <option value="All">All Difficulties</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>

            {/* Select All Checkbox */}
            <div className="flex items-center justify-end">
              <button
                onClick={handleSelectAllInView}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 flex items-center justify-center space-x-2"
              >
                {selectedQuestionIds.size === filteredQuestions.length && filteredQuestions.length > 0 ? (
                  <>
                    <CheckSquare className="w-4 h-4 text-yellow-400" />
                    <span>Deselect All ({filteredQuestions.length})</span>
                  </>
                ) : (
                  <>
                    <Square className="w-4 h-4 text-slate-400" />
                    <span>Select All ({filteredQuestions.length})</span>
                  </>
                )}
              </button>
            </div>

          </div>

          {/* Question List in Category */}
          <div className="space-y-3">
            {filteredQuestions.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-500">
                <BookOpen className="w-12 h-12 stroke-1 mx-auto mb-2 text-slate-600" />
                <p className="text-base font-bold text-slate-400">No questions found in this category.</p>
                <p className="text-xs text-slate-500 mt-1">Add a new question or use Bulk Paste to populate questions rapidly!</p>
              </div>
            ) : (
              filteredQuestions.map((q) => {
                const isSelected = selectedQuestionIds.has(q.id);
                const qType = q.type || 'multiple_choice';
                const badge = getQuestionTypeBadgeColor(qType);
                const typeLabel = getQuestionTypeLabel(qType);

                return (
                  <div
                    key={q.id}
                    className={`bg-slate-900 border rounded-3xl p-5 sm:p-6 transition-all space-y-3 shadow-lg ${
                      isSelected ? 'border-yellow-400 bg-slate-900/90 ring-1 ring-yellow-400/40' : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      
                      <div className="flex items-start space-x-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelectQuestion(q.id)}
                          className="mt-1 w-5 h-5 accent-yellow-400 cursor-pointer"
                        />
                        
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${badge.bg} ${badge.text} ${badge.border}`}>
                              {typeLabel}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 text-[10px] font-black uppercase tracking-wider">
                              {q.category}
                            </span>
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                              q.difficulty === 'Easy' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
                              q.difficulty === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                              'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                            }`}>
                              {q.difficulty}
                            </span>
                          </div>

                          <h3 className="text-base sm:text-lg font-black text-white leading-snug">
                            {q.question}
                          </h3>
                        </div>
                      </div>

                      {/* Question Item Actions */}
                      <div className="flex items-center space-x-1 flex-shrink-0">
                        <button
                          onClick={() => handleDuplicate(q)}
                          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
                          title="Duplicate Question"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setEditingQuestion(q)}
                          className="p-2 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded-xl transition-colors"
                          title="Edit Question"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteSingleQuestion(q.id)}
                          className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-xl transition-colors"
                          title="Delete Question"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                    </div>

                    {/* Question Content Previews based on type */}
                    {(qType === 'multiple_choice' || qType === 'fastest_fingers') && q.options && q.options.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1 pl-8">
                        {q.options.map((opt, idx) => (
                          <div
                            key={idx}
                            className={`p-3 rounded-2xl border flex items-center justify-between ${
                              idx === q.correctAnswer
                                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-bold'
                                : 'bg-slate-950/60 border-slate-800 text-slate-400'
                            }`}
                          >
                            <span>{['A', 'B', 'C', 'D'][idx] || idx + 1}. {opt}</span>
                            {idx === q.correctAnswer && <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />}
                          </div>
                        ))}
                      </div>
                    )}

                    {qType === 'fill_blank' && (
                      <div className="pl-8 pt-1 flex flex-wrap items-center gap-2 text-xs">
                        <span className="text-slate-400 font-bold">Accepted Answer(s):</span>
                        {(q.acceptedAnswers || []).map((ans, i) => (
                          <span key={i} className="px-3 py-1 bg-emerald-500/15 border border-emerald-400/40 text-emerald-300 rounded-xl font-black">
                            "{ans}"
                          </span>
                        ))}
                      </div>
                    )}

                    {qType === 'ordering' && (
                      <div className="pl-8 pt-1 space-y-1.5 text-xs">
                        <span className="text-cyan-400 font-bold block">Correct Chronological / Ranked Order:</span>
                        <div className="flex flex-wrap gap-2">
                          {(q.orderItems || q.options || []).map((item, idx) => (
                            <span key={idx} className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 rounded-xl font-bold flex items-center space-x-1.5">
                              <span className="w-4 h-4 rounded-full bg-cyan-400 text-slate-950 text-[10px] font-black inline-flex items-center justify-center">
                                {idx + 1}
                              </span>
                              <span>{item}</span>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {qType === 'matching' && (
                      <div className="pl-8 pt-1 space-y-1.5 text-xs">
                        <span className="text-purple-400 font-bold block">Matching Pairs:</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {(q.matchingPairs || []).map((pair, idx) => (
                            <div key={pair.id || idx} className="p-2.5 bg-purple-950/20 border border-purple-500/30 rounded-xl flex items-center justify-between font-bold">
                              <span className="text-white">{pair.left}</span>
                              <span className="text-purple-300 font-black text-[11px] bg-purple-500/20 px-2 py-0.5 rounded-lg">↔ {pair.right}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {q.explanation && (
                      <p className="text-xs text-slate-400 italic bg-slate-950/60 p-3 rounded-2xl border border-slate-800 ml-8">
                        💡 {q.explanation}
                      </p>
                    )}

                  </div>
                );
              })
            )}
          </div>

        </div>
      )}

      {/* Bulk Paste Modal */}
      <BulkPasteModal
        isOpen={isBulkPasteOpen}
        onClose={() => setIsBulkPasteOpen(false)}
        categories={allCategories}
        defaultCategory={activeCategoryView || 'General Knowledge'}
        onQuestionsImported={async (imported) => {
          const res = await onImportQuestions(imported);
          if (res?.success) {
            setImportNotification({
              message: `${res.count || imported.length} Questions Imported Successfully to Supabase`,
              type: 'success'
            });
          } else {
            setImportNotification({
              message: `Failed to import questions to Supabase: ${res?.error || 'Database error'}`,
              type: 'error'
            });
          }
        }}
      />

      {/* CSV Import Preview Modal */}
      <CSVImportModal
        isOpen={isCSVModalOpen}
        onClose={() => setIsCSVModalOpen(false)}
        csvText={uploadedCSVText}
        existingQuestions={questions}
        onQuestionsImported={async (imported) => {
          const res = await onImportQuestions(imported);
          if (res?.success) {
            setImportNotification({
              message: `${res.count || imported.length} Questions Imported Successfully to Supabase`,
              type: 'success'
            });
          } else {
            setImportNotification({
              message: `Failed to import questions to Supabase: ${res?.error || 'Database error'}`,
              type: 'error'
            });
          }
        }}
      />

      {/* Move Category Modal */}
      {isMoveModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-white">Move {selectedQuestionIds.size} Questions</h3>
            <p className="text-xs text-slate-400">Select the destination category for selected questions:</p>
            
            <select
              value={targetMoveCategory}
              onChange={(e) => setTargetMoveCategory(e.target.value)}
              className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm font-semibold"
            >
              {allCategories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={() => setIsMoveModalOpen(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmMoveCategory}
                className="px-5 py-2 bg-yellow-400 text-slate-950 font-black text-xs rounded-xl"
              >
                Confirm Move
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Multi-Question Add / Single Question Edit Repeater Modal */}
      <AddQuestionRepeaterModal
        isOpen={isRepeaterModalOpen || Boolean(editingQuestion)}
        onClose={() => {
          setIsRepeaterModalOpen(false);
          setEditingQuestion(null);
        }}
        categories={allCategories}
        defaultCategory={activeCategoryView || 'General Knowledge'}
        editingQuestion={editingQuestion}
        onQuestionsAdded={handleQuestionsAddedFromRepeater}
        onQuestionUpdated={handleQuestionUpdatedFromModal}
      />

      {/* Session Settings Launcher Wizard Modal */}
      {onCreateSession && (
        <QuizCreationWizardModal
          isOpen={isSessionModalOpen}
          onClose={() => setIsSessionModalOpen(false)}
          onCreateSession={(title, settings, selectedQIds) => {
            onCreateSession(title, settings, selectedQIds);
            setIsSessionModalOpen(false);
          }}
          availableCategories={allCategories}
          allQuestions={questions}
          initialSelectedQuestionIds={Array.from(selectedQuestionIds)}
          initialCategory={activeCategoryView}
        />
      )}

    </div>
  );
};
