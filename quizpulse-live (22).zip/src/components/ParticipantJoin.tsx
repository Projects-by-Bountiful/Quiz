import React, { useState, useEffect } from 'react';
import { Play, QrCode, Sparkles, AlertCircle, Users, ArrowRight, Loader2 } from 'lucide-react';

interface ParticipantJoinProps {
  onJoin: (code: string, name: string, avatar: string) => void | Promise<void>;
  errorMessage?: string | null;
  initialCode?: string;
  onQuickHost?: () => void;
}

const AVATARS = ['🦊', '🐯', '🦁', '🦉', '🚀', '⚡', '🧠', '🦄', '🐼', '🎨', '🔥', '👑'];

export const ParticipantJoin: React.FC<ParticipantJoinProps> = ({
  onJoin,
  errorMessage,
  initialCode = '',
  onQuickHost
}) => {
  const [code, setCode] = useState(initialCode);
  const [name, setName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isJoining, setIsJoining] = useState(false);

  useEffect(() => {
    if (initialCode) {
      setCode(initialCode);
    }
  }, [initialCode]);

  // If an external error message arrives, re-enable the button so user can retry
  useEffect(() => {
    if (errorMessage) {
      setIsJoining(false);
    }
  }, [errorMessage]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isJoining) return; // Prevent multiple clicks / double taps

    setValidationError(null);

    const cleanCode = code.trim().toUpperCase();
    const cleanName = name.trim();

    if (!cleanCode || cleanCode.length < 4) {
      setValidationError('Please enter a valid game join code.');
      return;
    }

    if (!cleanName) {
      setValidationError('Please enter your display name.');
      return;
    }

    // Immediately disable the Join button & show loading state
    setIsJoining(true);

    try {
      await onJoin(cleanCode, cleanName, selectedAvatar);
    } catch (err: any) {
      console.error('Join error in UI:', err);
      setIsJoining(false);
      setValidationError(err?.message || 'Failed to join game. Please try again.');
    }
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-indigo-950 text-white flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden">
      
      {/* Background Ambient Glows */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-indigo-600/30 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-amber-500/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-md bg-indigo-900/70 backdrop-blur-md rounded-3xl border border-indigo-500/30 p-6 sm:p-8 shadow-2xl relative z-10">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-amber-400 text-indigo-950 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-amber-400/30 mb-4 animate-bounce">
            <Sparkles className="w-8 h-8 fill-current" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Join Live Quiz
          </h1>
          <p className="text-xs sm:text-sm text-indigo-200 mt-1 font-semibold">
            Enter the host join code to jump into the competition
          </p>
        </div>

        {/* Error Messages */}
        {(errorMessage || validationError) && (
          <div className="mb-6 p-3.5 bg-rose-500/20 border border-rose-500/40 rounded-xl flex items-center space-x-3 text-rose-200 text-sm font-semibold">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400" />
            <span>{errorMessage || validationError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Join Code Input */}
          <div>
            <label className="block text-xs font-black text-indigo-200 uppercase tracking-widest mb-2">
              Game Join Code
            </label>
            <div className="relative">
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="XJ-902"
                maxLength={8}
                disabled={isJoining}
                className="w-full px-4 py-3.5 text-center text-3xl font-black tracking-widest bg-indigo-950/80 border-2 border-indigo-400/40 rounded-2xl text-amber-400 placeholder-indigo-500 focus:outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/20 transition-all uppercase disabled:opacity-60 disabled:cursor-not-allowed"
                required
              />
            </div>
          </div>

          {/* Display Name */}
          <div>
            <label className="block text-xs font-black text-indigo-200 uppercase tracking-widest mb-2">
              Your Display Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Sarah_Design, DevAlex99"
              maxLength={20}
              disabled={isJoining}
              className="w-full px-4 py-3.5 bg-indigo-950/80 border border-indigo-500/40 rounded-2xl text-white placeholder-indigo-400 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all font-bold disabled:opacity-60 disabled:cursor-not-allowed"
              required
            />
          </div>

          {/* Avatar Picker */}
          <div>
            <label className="block text-xs font-black text-indigo-200 uppercase tracking-widest mb-2">
              Choose Your Avatar
            </label>
            <div className="grid grid-cols-6 gap-2">
              {AVATARS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  disabled={isJoining}
                  onClick={() => setSelectedAvatar(emoji)}
                  className={`h-11 rounded-2xl text-xl flex items-center justify-center transition-all ${
                    selectedAvatar === emoji
                      ? 'bg-amber-400 text-indigo-950 ring-4 ring-amber-400/40 scale-110 shadow-lg font-bold'
                      : 'bg-indigo-950/80 hover:bg-indigo-800 text-indigo-200 border border-indigo-700/50'
                  } disabled:opacity-60 disabled:cursor-not-allowed`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Submit Button with Multi-click Prevention & Loading Indicator */}
          <button
            type="submit"
            disabled={isJoining}
            className={`w-full py-4 px-6 font-black text-lg rounded-2xl shadow-xl transition-all flex items-center justify-center space-x-2 select-none touch-manipulation ${
              isJoining
                ? 'bg-amber-500/60 text-indigo-950/80 cursor-not-allowed shadow-none'
                : 'bg-amber-400 hover:bg-amber-300 text-indigo-950 shadow-amber-400/20 transform active:scale-98 cursor-pointer'
            }`}
          >
            {isJoining ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Joining...</span>
              </>
            ) : (
              <>
                <span>Enter Live Lobby</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </form>

        {/* Secondary Host Link */}
        {onQuickHost && (
          <div className="mt-8 pt-6 border-t border-indigo-700/50 text-center">
            <p className="text-xs text-indigo-300 font-medium mb-3">Are you hosting an event?</p>
            <button
              onClick={onQuickHost}
              disabled={isJoining}
              className="w-full py-3 px-4 bg-indigo-800/60 hover:bg-indigo-700 text-indigo-100 text-sm font-bold rounded-2xl border border-indigo-500/30 transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              <Users className="w-4 h-4 text-amber-400" />
              <span>Host a New Quiz Session</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
