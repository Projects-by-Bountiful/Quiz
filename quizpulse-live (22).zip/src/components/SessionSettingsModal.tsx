import React, { useState, useEffect } from 'react';
import { Zap, X, Sliders, Check, Shield, Clock, Search, Layers, HelpCircle, ArrowRight, Loader2, Play } from 'lucide-react';
import { Category, Question, SessionSettings } from '../types';

interface SessionSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateSession: (title: string, settings: Partial<SessionSettings>, selectedQuestionIds?: string[]) => void;
  availableCategories: Category[];
  allQuestions: Question[];
  initialSelectedQuestionIds?: string[];
  initialCategory?: Category | null;
}

export const SessionSettingsModal: React.FC<SessionSettingsModalProps> = ({
  isOpen,
  onClose,
  onCreateSession,
  availableCategories = [],
  allQuestions = [],
  initialSelectedQuestionIds = [],
  initialCategory = null
}) => {
  const safeAvailableCategories = availableCategories || [];
  const safeAllQuestions = allQuestions || [];
  const [title, setTitle] = useState('QuizPulse Live Challenge');
  const [activeTab, setActiveTab] = useState<'auto' | 'manual'>('auto');

  // Auto Selection State
  const [selectedCategories, setSelectedCategories] = useState<Category[]>([]);
  const [questionCount, setQuestionCount] = useState<number>(10);

  // Manual Selection State
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<string[]>(initialSelectedQuestionIds);
  const [searchFilter, setSearchFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Rules & Timing State
  const [timerDurationSec, setTimerDurationSec] = useState<number>(20);
  const [maxParticipants, setMaxParticipants] = useState<number>(50);
  const [isRandom, setIsRandom] = useState<boolean>(true);
  const [enableBonusSpeedPoints, setEnableBonusSpeedPoints] = useState<boolean>(true);
  const [allowAnswerChange, setAllowAnswerChange] = useState<boolean>(false);
  const [showCorrectAnswer, setShowCorrectAnswer] = useState<boolean>(true);
  const [enableLeaderboard, setEnableLeaderboard] = useState<boolean>(true);
  const [enableSoundEffects, setEnableSoundEffects] = useState<boolean>(true);
  const [enableCelebrations, setEnableCelebrations] = useState<boolean>(true);
  const [enableFeedback, setEnableFeedback] = useState<boolean>(true);

  // Loading State
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (initialCategory) {
        setSelectedCategories([initialCategory]);
        setTitle(`${initialCategory} Quiz Challenge`);
      }
      if (initialSelectedQuestionIds && initialSelectedQuestionIds.length > 0) {
        setSelectedQuestionIds(initialSelectedQuestionIds);
        setActiveTab('manual');
        setTitle(`Custom Hand-Picked Quiz (${initialSelectedQuestionIds.length} Questions)`);
      }
    }
  }, [initialCategory, initialSelectedQuestionIds?.join(','), isOpen]);

  if (!isOpen) return null;

  const toggleCategory = (cat: Category) => {
    if (selectedCategories.includes(cat)) {
      setSelectedCategories(selectedCategories.filter(c => c !== cat));
    } else {
      setSelectedCategories([...selectedCategories, cat]);
    }
  };

  const toggleSelectQuestion = (qId: string) => {
    if (selectedQuestionIds.includes(qId)) {
      setSelectedQuestionIds(selectedQuestionIds.filter(id => id !== qId));
    } else {
      setSelectedQuestionIds([...selectedQuestionIds, qId]);
    }
  };

  // Compute calculated pool count
  let filteredQuestions = allQuestions;
  if (categoryFilter !== 'ALL') {
    filteredQuestions = filteredQuestions.filter(q => q.category === categoryFilter);
  }
  if (searchFilter.trim()) {
    const qTerm = searchFilter.toLowerCase();
    filteredQuestions = filteredQuestions.filter(q =>
      q.question.toLowerCase().includes(qTerm) ||
      q.category.toLowerCase().includes(qTerm)
    );
  }

  // Calculate preview count for auto mode
  let autoPool = allQuestions;
  if (selectedCategories.length > 0) {
    autoPool = autoPool.filter(q => selectedCategories.includes(q.category));
  }
  const effectiveCount = activeTab === 'manual'
    ? selectedQuestionIds.length
    : Math.min(questionCount, autoPool.length > 0 ? autoPool.length : allQuestions.length);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (activeTab === 'manual' && selectedQuestionIds.length > 0) {
        await onCreateSession(
          title,
          {
            categories: [],
            questionCount: selectedQuestionIds.length,
            timerDurationSec,
            isRandom,
            enableBonusSpeedPoints,
            allowAnswerChange,
            showCorrectAnswer,
            enableLeaderboard,
            enableSoundEffects,
            enableCelebrations,
            enableFeedback,
            maxParticipants
          },
          selectedQuestionIds
        );
      } else {
        await onCreateSession(
          title,
          {
            categories: selectedCategories,
            questionCount,
            timerDurationSec,
            isRandom,
            enableBonusSpeedPoints,
            allowAnswerChange,
            showCorrectAnswer,
            enableLeaderboard,
            enableSoundEffects,
            enableCelebrations,
            enableFeedback,
            maxParticipants
          }
        );
      }
    } finally {
      setIsSubmitting(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 sm:p-8 shadow-2xl relative space-y-6">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-yellow-400/20">
            <Zap className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">Create Quiz Session</h2>
            <p className="text-xs text-slate-400 font-semibold">
              Configure event parameters & questions for live host presentation
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 text-sm">
          
          {/* Title Input */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Quiz Event Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Freelancer360 Quiz Night, React Fundamentals..."
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:border-yellow-400 font-bold"
              required
            />
          </div>

          {/* Selection Strategy Tabs */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                Question Selection Method
              </label>
              <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveTab('auto')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'auto'
                      ? 'bg-yellow-400 text-slate-950 shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ⚡ Auto Category Filter
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('manual')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'manual'
                      ? 'bg-yellow-400 text-slate-950 shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  🎯 Hand-Pick ({selectedQuestionIds.length})
                </button>
              </div>
            </div>

            {/* TAB 1: Auto Category & Count */}
            {activeTab === 'auto' && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">
                    Include Categories (Leave empty for all {allQuestions.length} questions)
                  </label>
                  <div className="flex flex-wrap gap-2 max-h-28 overflow-y-auto pr-1">
                    {availableCategories.map((cat) => {
                      const isSel = selectedCategories.includes(cat);
                      const catCount = allQuestions.filter(q => q.category === cat).length;
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => toggleCategory(cat)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                            isSel
                              ? 'bg-indigo-600 text-white shadow'
                              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                          }`}
                        >
                          <span>{cat}</span>
                          <span className="text-[10px] opacity-70">({catCount})</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">
                    Number of Questions to Launch
                  </label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="number"
                      min={1}
                      max={Math.max(1, autoPool.length)}
                      value={questionCount}
                      onChange={(e) => setQuestionCount(Math.min(autoPool.length, Math.max(1, Number(e.target.value))))}
                      className="w-28 px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-black text-center"
                    />
                    <div className="flex flex-wrap gap-1.5">
                      {[5, 10, 15, 20, autoPool.length].map((cnt, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setQuestionCount(cnt)}
                          className={`px-3 py-1 rounded-xl text-xs font-bold ${
                            questionCount === cnt ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                          }`}
                        >
                          {cnt === autoPool.length ? `All (${cnt})` : `${cnt} Qs`}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: Manual Hand-Pick Checklist */}
            {activeTab === 'manual' && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search questions..."
                      value={searchFilter}
                      onChange={(e) => setSearchFilter(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
                    />
                  </div>

                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="py-1.5 px-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 font-semibold"
                  >
                    <option value="ALL">All Categories</option>
                    {availableCategories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>

                  <button
                    type="button"
                    onClick={() => {
                      if (selectedQuestionIds.length === filteredQuestions.length) {
                        setSelectedQuestionIds([]);
                      } else {
                        setSelectedQuestionIds(filteredQuestions.map(q => q.id));
                      }
                    }}
                    className="text-xs text-amber-400 font-bold hover:underline"
                  >
                    {selectedQuestionIds.length === filteredQuestions.length ? 'Deselect All' : 'Select All Filtered'}
                  </button>
                </div>

                <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                  {filteredQuestions.map((q) => {
                    const isChecked = selectedQuestionIds.includes(q.id);
                    return (
                      <div
                        key={q.id}
                        onClick={() => toggleSelectQuestion(q.id)}
                        className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-center justify-between transition-colors ${
                          isChecked
                            ? 'bg-yellow-400/10 border-yellow-400/60 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center space-x-3 overflow-hidden pr-2">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="w-4 h-4 accent-yellow-400 rounded cursor-pointer"
                          />
                          <div className="truncate">
                            <span className="font-bold text-white block truncate">{q.question}</span>
                            <span className="text-[10px] text-slate-500 font-semibold">{q.category} • {q.difficulty}</span>
                          </div>
                        </div>
                        <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono flex-shrink-0">
                          {q.options.length} Opts
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Timing & Scoring Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Question Countdown
              </label>
              <select
                value={timerDurationSec}
                onChange={(e) => setTimerDurationSec(Number(e.target.value))}
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold"
              >
                <option value={5}>5 Seconds</option>
                <option value={10}>10 Seconds</option>
                <option value={15}>15 Seconds</option>
                <option value={20}>20 Seconds</option>
                <option value={30}>30 Seconds</option>
                <option value={60}>60 Seconds</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Max Participants
              </label>
              <select
                value={maxParticipants}
                onChange={(e) => setMaxParticipants(Number(e.target.value))}
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold"
              >
                <option value={20}>👥 20 Players</option>
                <option value={30}>👥 30 Players</option>
                <option value={50}>👥 50 Players</option>
                <option value={100}>👥 100 Players</option>
                <option value={200}>👥 200 Players</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Order & Experience Rules
              </label>
              <div className="flex flex-col space-y-1.5 text-xs">
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isRandom}
                    onChange={(e) => setIsRandom(e.target.checked)}
                    className="w-4 h-4 accent-yellow-400"
                  />
                  <span>Shuffle question order</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableBonusSpeedPoints}
                    onChange={(e) => setEnableBonusSpeedPoints(e.target.checked)}
                    className="w-4 h-4 accent-yellow-400"
                  />
                  <span>Enable Speed Bonus Points</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableSoundEffects}
                    onChange={(e) => setEnableSoundEffects(e.target.checked)}
                    className="w-4 h-4 accent-yellow-400"
                  />
                  <span>Sound Effects: ON</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableCelebrations}
                    onChange={(e) => setEnableCelebrations(e.target.checked)}
                    className="w-4 h-4 accent-yellow-400"
                  />
                  <span>Celebrations & Confetti: ON</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableFeedback}
                    onChange={(e) => setEnableFeedback(e.target.checked)}
                    className="w-4 h-4 accent-yellow-400"
                  />
                  <span>Collect Participant Feedback</span>
                </label>
              </div>
            </div>
          </div>

          {/* Live Summary Bar & Launch Button */}
          <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-400 font-semibold">
              Selected: <span className="text-yellow-400 font-black text-sm">{effectiveCount} Questions</span> • Approx duration: <span className="text-white font-bold">{Math.round((effectiveCount * (timerDurationSec + 5)) / 60)} min</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || effectiveCount === 0}
              className="w-full sm:w-auto py-3.5 px-8 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-amber-400/20 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span>INITIALIZING LOBBY...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current text-slate-950" />
                  <span>LAUNCH QUIZ SESSION NOW</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
