import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { 
  Maximize2, Minimize2, Volume2, VolumeX, Sparkles, Trophy, Clock, 
  Users, CheckCircle2, XCircle, Flame, ArrowRight, Play, Pause, SkipForward, QrCode, Copy, Check,
  ListOrdered, ArrowRightLeft, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { GameSession, Question, Participant } from '../types';
import { soundEffects } from '../utils/sound';
import { getParticipantJoinUrl } from '../utils/url';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';
import { useSynchronizedTimer } from '../utils/useSynchronizedTimer';

interface PresenterModeViewProps {
  session: GameSession;
  isHost: boolean;
  onExitPresenter: () => void;
  onHostAction?: (action: string, payload?: any) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  celebrationsEnabled: boolean;
  onToggleCelebrations: () => void;
}

export const PresenterModeView: React.FC<PresenterModeViewProps> = ({
  session,
  isHost,
  onExitPresenter,
  onHostAction,
  soundEnabled,
  onToggleSound,
  celebrationsEnabled,
  onToggleCelebrations
}) => {
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const joinUrl = getParticipantJoinUrl(session.id);
  const currentQ: Question | undefined = session.questions[session.currentQuestionIndex];
  const participantsList: Participant[] = (Object.values(session.participants || {}) as Participant[])
    .sort((a, b) => (b.score || 0) - (a.score || 0));

  useEffect(() => {
    if (session.status === 'LOBBY' && qrCanvasRef.current) {
      QRCode.toCanvas(qrCanvasRef.current, joinUrl, {
        width: 140,
        margin: 2,
        color: {
          dark: '#020617',
          light: '#ffffff'
        }
      }, (err) => {
        if (err) console.error('[QuizPulse] Presenter QR error:', err);
      });
    }
  }, [session.status, joinUrl]);

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(joinUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = joinUrl;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const totalTimeLimit = currentQ?.estimatedTimeSec || session.settings.timerDurationSec || 20;
  const isRevealPhase = session.status === 'ANSWER_REVEAL';

  const synchronizedRemaining = useSynchronizedTimer({
    questionStartTime: session.questionStartTime || session.settings?.questionStartTime,
    timerDurationSec: totalTimeLimit,
    isPaused: session.isTimerPaused,
    isHost,
    onExpire: () => {
      if (isHost && session.status === 'QUESTION' && onHostAction) {
        onHostAction('REVEAL_ANSWER');
      }
    }
  });

  const timerRemaining = isRevealPhase ? 0 : synchronizedRemaining;
  const totalResponded = currentQ 
    ? participantsList.filter(p => p.answers && p.answers[currentQ.id]).length 
    : 0;

  // Toggle Fullscreen browser mode
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Sound triggers
  useEffect(() => {
    if (soundEnabled && session.status === 'QUESTION' && timerRemaining > 0 && timerRemaining <= 5 && !session.isTimerPaused) {
      if (session.settings.soundConfig?.countdownSound !== false) {
        soundEffects.urgentTick();
      }
    }
  }, [timerRemaining, session.status, soundEnabled, session.isTimerPaused, session.settings.soundConfig]);

  // Confetti on Reveal & Winner
  useEffect(() => {
    if (celebrationsEnabled && session.settings.enableCelebrations !== false) {
      if (session.status === 'ANSWER_REVEAL') {
        confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
        if (soundEnabled && session.settings.soundConfig?.correctAnswerSound !== false) {
          soundEffects.correct();
        }
      } else if (session.status === 'ENDED') {
        confetti({ particleCount: 150, spread: 100, origin: { y: 0.5 } });
        if (soundEnabled && session.settings.soundConfig?.winnerSound !== false) {
          soundEffects.winner();
        }
      }
    }
  }, [session.status, celebrationsEnabled, soundEnabled, session.settings]);

  const qType = currentQ?.type || 'multiple_choice';
  const typeBadge = getQuestionTypeBadgeColor(qType);
  const typeLabel = getQuestionTypeLabel(qType);

  const optionColors = [
    { letter: 'A', bg: 'bg-blue-600', border: 'border-blue-400', text: 'text-blue-100' },
    { letter: 'B', bg: 'bg-rose-600', border: 'border-rose-400', text: 'text-rose-100' },
    { letter: 'C', bg: 'bg-amber-500', border: 'border-amber-300', text: 'text-amber-100' },
    { letter: 'D', bg: 'bg-emerald-600', border: 'border-emerald-400', text: 'text-emerald-100' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-6 md:p-10 select-none overflow-hidden font-sans">
      
      {/* TOP FLOATING PRESENTER CONTROL BAR */}
      <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 backdrop-blur-md rounded-2xl px-4 sm:px-6 py-3 shadow-2xl z-20">
        
        {/* Left: Event Branding & Status */}
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 rounded-xl bg-yellow-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-md shadow-yellow-400/20 flex-shrink-0">
            📺
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-black text-yellow-400 uppercase tracking-widest">Presenter Mode</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <h1 className="text-sm font-extrabold text-white truncate max-w-xs sm:max-w-md">{session.title}</h1>
          </div>
        </div>

        {/* Center: Audio & Celebration Toggles */}
        <div className="hidden sm:flex items-center space-x-3 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs font-bold">
          <button
            onClick={onToggleSound}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all ${
              soundEnabled ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-900 text-slate-500'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            <span>{soundEnabled ? 'Sound ON' : 'Muted'}</span>
          </button>

          <button
            onClick={onToggleCelebrations}
            className={`px-3 py-1.5 rounded-lg flex items-center space-x-1.5 transition-all ${
              celebrationsEnabled ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40' : 'bg-slate-900 text-slate-500'
            }`}
          >
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span>FX ON</span>
          </button>
        </div>

        {/* Right: Controls & Exit Fullscreen */}
        <div className="flex items-center space-x-3">
          {isHost && onHostAction && (
            <>
              <button
                onClick={() => onHostAction('PAUSE_TIMER')}
                className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-colors"
                title="Pause / Resume Timer"
              >
                {session.isTimerPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4 text-yellow-400" />}
              </button>

              {!isRevealPhase ? (
                <button
                  onClick={() => onHostAction('SKIP_QUESTION')}
                  className="px-3.5 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-black uppercase rounded-xl transition-all shadow"
                >
                  <SkipForward className="w-3.5 h-3.5 inline mr-1" />
                  <span>Reveal</span>
                </button>
              ) : (
                <button
                  onClick={() => onHostAction('NEXT_QUESTION')}
                  className="px-3.5 py-1.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black uppercase rounded-xl transition-all shadow"
                >
                  <ArrowRight className="w-3.5 h-3.5 inline mr-1" />
                  <span>Next Q</span>
                </button>
              )}
            </>
          )}

          <button
            onClick={toggleFullscreen}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-colors hidden sm:block"
            title="Toggle Browser Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onExitPresenter}
            className="px-3.5 sm:px-4 py-2 bg-slate-800 hover:bg-rose-900/40 hover:border-rose-500 text-slate-300 hover:text-white rounded-xl border border-slate-700 text-xs font-black uppercase tracking-wider transition-all"
          >
            Exit
          </button>
        </div>

      </div>

      {/* MAIN VIEW AREA */}
      <div className="flex-1 flex flex-col justify-center items-center py-4 sm:py-6 px-2 md:px-6 overflow-y-auto">
        
        {/* VIEW 1: LOBBY */}
        {session.status === 'LOBBY' && (
          <div className="w-full max-w-4xl text-center space-y-8">
            <div className="space-y-3">
              <span className="px-4 py-1.5 bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 rounded-full text-xs font-black tracking-widest uppercase inline-block">
                LIVE LOBBY
              </span>
              <h1 className="text-4xl md:text-6xl font-black text-white tracking-tight">{session.title}</h1>
              <p className="text-slate-400 text-base md:text-lg max-w-2xl mx-auto font-medium">
                {session.description || "Join the interactive quiz session right now on your mobile device!"}
              </p>
            </div>

            {/* Room Code & QR Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col sm:flex-row items-center justify-around gap-6">
              <div className="space-y-3 text-center sm:text-left">
                <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Join on your phone</span>
                <p className="text-base text-slate-300 font-bold">Go to quizpulse.app or scan QR code</p>
                
                <div className="inline-block p-4 bg-slate-950 rounded-2xl border-2 border-yellow-400 shadow-xl">
                  <span className="text-xs font-extrabold text-slate-400 block uppercase">ENTER GAME PIN</span>
                  <span className="text-4xl sm:text-5xl font-black text-yellow-400 font-mono tracking-wider">{session.id}</span>
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleCopyLink}
                    className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-md flex items-center space-x-2 transition-all mx-auto sm:mx-0"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-800 stroke-[3]" />
                        <span>✓ Link Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-950" />
                        <span>Copy Join Link</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="p-3 bg-white rounded-2xl shadow-xl flex flex-col items-center">
                <canvas ref={qrCanvasRef} />
                <span className="text-[10px] text-slate-800 font-extrabold mt-1 uppercase tracking-wider">SCAN TO JOIN</span>
              </div>
            </div>

            {/* Live Joined Participants */}
            <div className="space-y-4">
              <div className="flex items-center justify-center space-x-2 text-lg font-black text-emerald-400">
                <Users className="w-6 h-6" />
                <span>{participantsList.length} Participants Connected</span>
              </div>

              <div className="flex flex-wrap justify-center gap-3 max-h-48 overflow-y-auto p-2">
                {participantsList.map((p) => (
                  <div
                    key={p.id}
                    className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-2xl flex items-center space-x-2 text-sm font-bold shadow"
                  >
                    <span className="text-xl">{p.avatar}</span>
                    <span className="text-white">{p.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2 & 3: QUESTION & ANSWER_REVEAL */}
        {(session.status === 'QUESTION' || session.status === 'ANSWER_REVEAL') && currentQ && (
          <div className="w-full max-w-6xl space-y-6 flex flex-col justify-between h-full">
            
            {/* Question Header & Circular Timer */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
              
              <div className="space-y-3 flex-1">
                <div className="flex items-center space-x-3">
                  <span className="px-4 py-1.5 bg-yellow-400 text-slate-950 font-black text-sm uppercase rounded-xl">
                    Question {session.currentQuestionIndex + 1} of {session.questions.length}
                  </span>
                  <span className={`px-3 py-1 text-xs font-black uppercase rounded-xl border ${typeBadge.bg} ${typeBadge.text} ${typeBadge.border}`}>
                    {typeLabel}
                  </span>
                  <span className="text-xs text-cyan-400 font-extrabold uppercase tracking-widest hidden sm:inline">
                    {currentQ.category}
                  </span>
                </div>

                <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-white leading-tight tracking-tight break-words">
                  {currentQ.question}
                </h2>
              </div>

              {/* Countdown Timer Display */}
              <div className="flex-shrink-0 flex flex-col items-center">
                <div className={`w-24 h-24 sm:w-28 sm:h-28 rounded-3xl border-4 flex flex-col items-center justify-center font-black shadow-2xl transition-all ${
                  isRevealPhase
                    ? 'bg-yellow-400 border-yellow-300 text-slate-950'
                    : timerRemaining <= 5
                    ? 'bg-rose-600 border-rose-400 text-white animate-bounce'
                    : 'bg-slate-950 border-yellow-400 text-yellow-400'
                }`}>
                  <Clock className="w-5 h-5 sm:w-6 sm:h-6 mb-1" />
                  <span className="text-2xl sm:text-3xl font-mono">{isRevealPhase ? `${session.revealTimerRemaining || 0}s` : `${timerRemaining}s`}</span>
                </div>
                <span className="text-[10px] text-slate-400 font-bold uppercase mt-2">
                  {isRevealPhase ? 'Next Q Countdown' : 'Time Remaining'}
                </span>
              </div>

            </div>

            {/* PRESENTATION BY QUESTION TYPE */}
            {(qType === 'multiple_choice' || qType === 'fastest_fingers') && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 flex-1">
                {(currentQ.options || []).map((optionText, idx) => {
                  const colors = optionColors[idx] || optionColors[0];
                  const isCorrect = isRevealPhase && currentQ.correctAnswer === idx;

                  let cardStyle = `bg-slate-900 border-2 border-slate-800 text-white`;
                  if (isRevealPhase) {
                    if (isCorrect) {
                      cardStyle = `bg-emerald-950 border-4 border-emerald-400 text-emerald-100 ring-8 ring-emerald-400/30 scale-[1.02] shadow-2xl`;
                    } else {
                      cardStyle = `bg-slate-950/60 border-slate-900 text-slate-600 opacity-40`;
                    }
                  }

                  return (
                    <div
                      key={idx}
                      className={`p-5 sm:p-8 rounded-3xl flex items-center justify-between transition-all duration-300 shadow-xl ${cardStyle}`}
                    >
                      <div className="flex items-center space-x-4 sm:space-x-6 overflow-hidden">
                        <div className={`w-12 h-12 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center font-black text-xl sm:text-2xl shadow-lg flex-shrink-0 ${
                          isRevealPhase && isCorrect ? 'bg-emerald-400 text-slate-950' : `${colors.bg} text-white`
                        }`}>
                          {colors.letter}
                        </div>

                        <span className="text-xl sm:text-3xl font-bold tracking-tight leading-snug break-words">
                          {optionText}
                        </span>
                      </div>

                      {isRevealPhase && isCorrect && (
                        <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12 text-emerald-400 flex-shrink-0 ml-4 animate-bounce" />
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Fill in Blank Presentation */}
            {qType === 'fill_blank' && (
              <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl text-center">
                <div className="text-sm font-black uppercase tracking-widest text-emerald-400">
                  Fill in the missing word on your mobile device
                </div>
                {isRevealPhase && (
                  <div className="pt-2 space-y-2">
                    <span className="text-xs text-slate-400 font-bold uppercase">Accepted Answer(s):</span>
                    <div className="flex flex-wrap justify-center gap-3">
                      {(currentQ.acceptedAnswers || []).map((ans, i) => (
                        <span key={i} className="text-2xl font-black px-6 py-2 bg-emerald-500/20 border-2 border-emerald-400 text-emerald-300 rounded-2xl">
                          "{ans}"
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Ordering Presentation */}
            {qType === 'ordering' && (
              <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
                <div className="text-sm font-black uppercase tracking-widest text-cyan-400 flex items-center space-x-2">
                  <ListOrdered className="w-5 h-5" />
                  <span>{isRevealPhase ? 'Correct Chronological Sequence' : 'Sequence items in correct order on phone'}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(currentQ.orderItems || currentQ.options || []).map((item, idx) => (
                    <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex items-center space-x-3 text-lg font-bold">
                      <span className="w-8 h-8 rounded-xl bg-cyan-400 text-slate-950 font-black flex items-center justify-center text-sm flex-shrink-0">
                        {idx + 1}
                      </span>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Matching Presentation */}
            {qType === 'matching' && (
              <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
                <div className="text-sm font-black uppercase tracking-widest text-purple-400 flex items-center space-x-2">
                  <ArrowRightLeft className="w-5 h-5" />
                  <span>{isRevealPhase ? 'Correct Matched Pairs' : 'Connect matching pairs on phone'}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(currentQ.matchingPairs || []).map((pair, idx) => (
                    <div key={pair.id || idx} className="p-4 bg-purple-950/30 border border-purple-500/40 rounded-2xl flex items-center justify-between text-base font-bold">
                      <span className="text-white">{pair.left}</span>
                      <span className="text-sm px-3 py-1 bg-purple-500/20 border border-purple-400 text-purple-300 rounded-xl">
                        ↔ {pair.right}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Response Progress Bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-xl">
              <div className="flex items-center space-x-3 text-sm font-black text-slate-300">
                <Users className="w-5 h-5 text-yellow-400" />
                <span>Responses Submitted: <strong className="text-yellow-400 text-lg">{totalResponded}</strong> / {participantsList.length}</span>
              </div>

              <div className="w-48 sm:w-64 bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
                <div 
                  className="bg-yellow-400 h-full rounded-full transition-all duration-300"
                  style={{ width: `${participantsList.length > 0 ? (totalResponded / participantsList.length) * 100 : 0}%` }}
                />
              </div>
            </div>

          </div>
        )}

        {/* VIEW 4: LEADERBOARD */}
        {session.status === 'LEADERBOARD' && (
          <div className="w-full max-w-4xl space-y-8 text-center">
            <div className="space-y-2">
              <Trophy className="w-16 h-16 text-amber-400 mx-auto animate-bounce" />
              <h2 className="text-4xl font-black text-white">Event Leaderboard</h2>
              <p className="text-sm text-slate-400 font-bold">Current standings across all participants</p>
            </div>

            <div className="space-y-3">
              {participantsList.slice(0, 8).map((p, idx) => (
                <div
                  key={p.id}
                  className={`p-5 rounded-3xl border-2 flex items-center justify-between shadow-xl ${
                    idx === 0
                      ? 'bg-yellow-400/20 border-yellow-400 text-white scale-[1.02]'
                      : idx === 1
                      ? 'bg-cyan-400/10 border-cyan-400/50 text-white'
                      : idx === 2
                      ? 'bg-rose-400/10 border-rose-400/50 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center space-x-5">
                    <span className={`w-10 h-10 rounded-2xl font-black text-base flex items-center justify-center ${
                      idx === 0 ? 'bg-yellow-400 text-slate-950' : 'bg-slate-800 text-slate-200'
                    }`}>
                      #{idx + 1}
                    </span>
                    <span className="text-3xl">{p.avatar}</span>
                    <span className="text-2xl font-black">{p.name}</span>
                  </div>

                  <span className="text-2xl font-black text-yellow-400 font-mono">{p.score} PTS</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW 5: ENDED / WINNER PODIUM */}
        {session.status === 'ENDED' && (
          <div className="w-full max-w-4xl text-center space-y-8">
            <div className="space-y-3">
              <div className="text-6xl animate-bounce">🏆</div>
              <h1 className="text-5xl font-black text-white">Quiz Champion</h1>
              <p className="text-base text-slate-400 font-bold">{session.title}</p>
            </div>

            {/* Winner Spotlight */}
            {participantsList[0] && (
              <div
                className="bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-300 text-slate-950 rounded-3xl p-8 shadow-2xl text-center border-4 border-yellow-200 space-y-2"
              >
                <span className="px-4 py-1.5 bg-slate-950 text-yellow-400 font-black text-xs uppercase tracking-widest rounded-full inline-block">
                  GRAND WINNER
                </span>
                <div className="text-7xl">{participantsList[0].avatar}</div>
                <h2 className="text-4xl font-black text-slate-950">{participantsList[0].name}</h2>
                <p className="text-5xl font-black font-mono text-slate-950">{participantsList[0].score} POINTS</p>
              </div>
            )}

            {/* Runner Ups */}
            <div className="grid grid-cols-2 gap-4">
              {participantsList.slice(1, 3).map((p, idx) => (
                <div key={p.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center space-y-1">
                  <span className="text-xs font-black text-slate-400 uppercase">Rank #{idx + 2}</span>
                  <div className="text-4xl">{p.avatar}</div>
                  <h3 className="text-xl font-black text-white">{p.name}</h3>
                  <p className="text-2xl font-black text-yellow-400 font-mono">{p.score} PTS</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* FOOTER PRESENTATION BADGE */}
      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold border-t border-slate-900 pt-3">
        <span>Designed for Big Screen Presentations • Projectors & LED Displays</span>
        <span>Press <kbd className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-mono text-[10px]">Esc</kbd> or click button to exit</span>
      </div>

    </div>
  );
};
