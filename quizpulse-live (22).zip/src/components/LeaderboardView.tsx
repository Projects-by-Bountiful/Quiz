import React, { useEffect } from 'react';
import { Trophy, Flame, ArrowRight, Square } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GameSession, Participant } from '../types';
import { soundEffects } from '../utils/sound';

interface LeaderboardViewProps {
  session: GameSession;
  isHost: boolean;
  onHostAction: (action: string) => void;
  soundEnabled: boolean;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  session,
  isHost,
  onHostAction,
  soundEnabled
}) => {
  const participantsList: Participant[] = (Object.values(session.participants || {}) as Participant[])
    .sort((a, b) => b.score - a.score);

  const top3 = participantsList.slice(0, 3);
  const remainingRanked = participantsList.slice(3);

  const isLastQuestion = session.currentQuestionIndex >= session.questions.length - 1;

  useEffect(() => {
    if (soundEnabled && isHost) {
      soundEffects.fanfare();
    }
  }, [soundEnabled, isHost]);

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white flex flex-col p-4 sm:p-6 md:p-8 relative justify-between max-w-5xl mx-auto w-full space-y-8">
      
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 bg-yellow-400 text-slate-950 rounded-full text-xs font-black uppercase tracking-widest shadow-lg shadow-yellow-400/20">
          <Trophy className="w-4 h-4 fill-current" />
          <span>Live Leaderboard Standings</span>
        </div>
        <h1 className="text-3xl sm:text-6xl font-black text-white tracking-tight">
          Current Rankings
        </h1>
        <p className="text-sm sm:text-base text-cyan-300 font-bold">
          Question {session.currentQuestionIndex + 1} of {session.questions.length} Complete
        </p>
      </div>

      {/* Top 3 Animated Podium */}
      {top3.length > 0 && (
        <div className="grid grid-cols-3 gap-3 sm:gap-6 items-end justify-center pt-8 pb-4">
          
          {/* 2nd Place */}
          {top3[1] ? (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 sm:w-22 sm:h-22 rounded-2xl bg-slate-900 border-4 border-cyan-400 flex items-center justify-center text-3xl sm:text-4xl shadow-xl shadow-cyan-500/20 mb-3 relative">
                {top3[1].avatar}
                <span className="absolute -top-2 -right-2 w-7 h-7 bg-cyan-400 text-slate-950 font-black rounded-full text-xs flex items-center justify-center shadow">
                  2nd
                </span>
              </div>
              <p className="text-sm sm:text-base font-bold text-white truncate max-w-[110px] text-center">{top3[1].name}</p>
              <p className="text-xs sm:text-sm font-black text-cyan-400 mt-0.5">{top3[1].score} pts</p>
              <div className="w-full h-24 sm:h-32 bg-gradient-to-t from-cyan-600 via-cyan-500 to-cyan-400 text-slate-950 rounded-t-3xl mt-3 flex items-center justify-center font-black text-3xl shadow-lg">
                🥈
              </div>
            </motion.div>
          ) : <div />}

          {/* 1st Place */}
          {top3[0] ? (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="flex flex-col items-center z-10"
            >
              <div className="w-20 h-20 sm:w-28 sm:h-28 rounded-3xl bg-yellow-400 border-4 border-amber-300 flex items-center justify-center text-4xl sm:text-6xl shadow-2xl shadow-yellow-400/40 mb-3 relative animate-bounce">
                {top3[0].avatar}
                <span className="absolute -top-3 -right-2 w-8 h-8 bg-amber-300 text-slate-950 font-black rounded-full text-sm flex items-center justify-center shadow-lg ring-2 ring-white">
                  👑
                </span>
              </div>
              <p className="text-base sm:text-xl font-black text-yellow-300 truncate max-w-[130px] text-center">{top3[0].name}</p>
              <p className="text-sm sm:text-lg font-black text-yellow-400 mt-0.5">{top3[0].score} pts</p>
              <div className="w-full h-32 sm:h-44 bg-gradient-to-t from-amber-500 via-yellow-400 to-yellow-300 text-slate-950 rounded-t-3xl mt-3 flex items-center justify-center font-black text-4xl shadow-2xl">
                🏆
              </div>
            </motion.div>
          ) : <div />}

          {/* 3rd Place */}
          {top3[2] ? (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 sm:w-22 sm:h-22 rounded-2xl bg-slate-900 border-4 border-pink-500 flex items-center justify-center text-3xl sm:text-4xl shadow-xl shadow-pink-500/20 mb-3 relative">
                {top3[2].avatar}
                <span className="absolute -top-2 -right-2 w-7 h-7 bg-pink-500 text-white font-black rounded-full text-xs flex items-center justify-center shadow">
                  3rd
                </span>
              </div>
              <p className="text-sm sm:text-base font-bold text-white truncate max-w-[110px] text-center">{top3[2].name}</p>
              <p className="text-xs sm:text-sm font-black text-pink-400 mt-0.5">{top3[2].score} pts</p>
              <div className="w-full h-20 sm:h-24 bg-gradient-to-t from-pink-600 to-pink-400 text-slate-950 rounded-t-3xl mt-3 flex items-center justify-center font-black text-2xl shadow-lg">
                🥉
              </div>
            </motion.div>
          ) : <div />}

        </div>
      )}

      {/* Ranks 4+ Animated List */}
      {remainingRanked.length > 0 && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-2xl space-y-3">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Challengers Leaderboard</h3>
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            <AnimatePresence mode="popLayout">
              {remainingRanked.map((p, idx) => (
                <motion.div
                  key={p.id ? `${p.id}-${idx}` : `lb-${p.name || idx}-${idx}`}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ type: "spring", stiffness: 350, damping: 25 }}
                  className="flex items-center justify-between p-3.5 bg-slate-950/90 rounded-2xl border border-slate-800"
                >
                  <div className="flex items-center space-x-3">
                    <span className="w-8 h-8 rounded-xl bg-slate-800 text-slate-300 font-black text-xs flex items-center justify-center border border-slate-700">
                      #{idx + 4}
                    </span>
                    <span className="text-2xl">{p.avatar}</span>
                    <span className="font-bold text-white text-base">{p.name}</span>
                  </div>

                  <div className="flex items-center space-x-4">
                    {p.streak > 1 && (
                      <span className="text-xs text-yellow-400 font-bold flex items-center bg-yellow-400/10 px-2.5 py-1 rounded-full border border-yellow-400/30">
                        <Flame className="w-3.5 h-3.5 mr-1 fill-current text-yellow-400" />
                        {p.streak} Streak
                      </span>
                    )}
                    <span className="font-black text-yellow-400 text-base">{p.score} pts</span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Host Control Actions */}
      {isHost && (
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-800">
          <button
            onClick={() => onHostAction('END_GAME')}
            className="py-3 px-6 bg-rose-600 hover:bg-rose-500 text-white font-black text-sm rounded-2xl shadow-lg transition-all flex items-center space-x-2"
          >
            <Square className="w-4 h-4 fill-current" />
            <span>Stop & End Game</span>
          </button>

          <button
            onClick={() => onHostAction(isLastQuestion ? 'END_GAME' : 'NEXT_QUESTION')}
            className="py-4 px-8 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-lg rounded-2xl shadow-xl shadow-yellow-400/20 transition-all flex items-center space-x-2"
          >
            <span>{isLastQuestion ? 'FINISH GAME & SEE RESULTS' : 'PROCEED TO NEXT QUESTION'}</span>
            <ArrowRight className="w-6 h-6" />
          </button>
        </div>
      )}

    </div>
  );
};
