import React, { useState } from 'react';
import { 
  CreditCard, ShieldAlert, CheckCircle2, XCircle, AlertTriangle, 
  X, Loader2, ArrowRight, RefreshCw, Sparkles, Lock, Layers, Users
} from 'lucide-react';
import { formatPrice, calculateGamePrice, CURRENCY_SYMBOL } from '../config/pricingConfig';
import { PaymentInitResult, PaymentVerificationResult, GameEntitlement } from '../services/payment/types';
import { paymentService } from '../services/payment/paymentService';

interface MockPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initData: PaymentInitResult;
  hostId: string;
  hostEmail?: string;
  onPaymentSuccess: (verification: PaymentVerificationResult, entitlement?: GameEntitlement) => void;
}

export const MockPaymentModal: React.FC<MockPaymentModalProps> = ({
  isOpen,
  onClose,
  initData,
  hostId,
  hostEmail,
  onPaymentSuccess
}) => {
  const [processingState, setProcessingState] = useState<'idle' | 'processing' | 'success' | 'failed'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSimulatePayment = async (simulateFailure: boolean = false) => {
    if (processingState === 'processing') return; // Prevent double-clicks

    setProcessingState('processing');
    setErrorMessage(null);

    try {
      const result = await paymentService.verifyAndUnlockGame(
        initData.reference,
        {
          hostId,
          hostEmail,
          quizTitle: initData.quizTitle,
          playerCapacity: initData.playerCapacity
        },
        simulateFailure
      );

      if (result.success && result.status === 'SUCCESS') {
        setProcessingState('success');
        setTimeout(() => {
          onPaymentSuccess(result, result.entitlement);
        }, 1200);
      } else {
        setProcessingState('failed');
        setErrorMessage(result.error || 'Payment was declined by the test simulator.');
      }
    } catch (err: any) {
      setProcessingState('failed');
      setErrorMessage(err?.message || 'Payment simulation encountered an error.');
    }
  };

  const formattedAmount = formatPrice(initData.amount);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 sm:p-8 shadow-2xl relative space-y-6 my-4 overflow-hidden">
        
        {/* Test Mode Top Watermark Badge */}
        <div className="bg-amber-500/15 border-b border-amber-500/30 -mx-6 sm:-mx-8 -mt-6 sm:-mt-8 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
            <span className="text-xs font-black text-amber-300 uppercase tracking-widest">
              Test Payment (Mock Mode)
            </span>
          </div>
          <span className="text-[11px] font-mono font-bold text-amber-400/80 bg-amber-950/70 px-2 py-0.5 rounded border border-amber-500/30">
            PROVIDER: MOCK
          </span>
        </div>

        {/* Close Button */}
        {processingState !== 'processing' && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/80 hover:bg-slate-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Header */}
        <div className="text-center pt-2 space-y-1">
          <div className="w-14 h-14 bg-gradient-to-tr from-yellow-400 to-amber-500 text-slate-950 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-yellow-400/20 mb-3">
            <CreditCard className="w-7 h-7 stroke-[2.5]" />
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">Test Payment</h2>
          <p className="text-xs text-slate-400 font-semibold">
            Simulate a pay-as-you-go checkout to unlock your live room
          </p>
        </div>

        {/* Order Summary Card */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
          <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
            <span className="text-slate-400 font-bold">Quiz Event:</span>
            <span className="text-white font-extrabold text-right truncate max-w-[200px]">{initData.quizTitle}</span>
          </div>

          <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
            <span className="text-slate-400 font-bold flex items-center space-x-1">
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Player Capacity:</span>
            </span>
            <span className="text-amber-300 font-bold">{initData.playerCapacity} Players</span>
          </div>

          <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
            <span className="text-slate-400 font-bold">Payment Reference:</span>
            <span className="text-slate-300 font-mono text-[11px]">{initData.reference}</span>
          </div>

          <div className="flex justify-between items-center pt-1">
            <span className="text-sm font-black text-white uppercase tracking-wider">Total Amount:</span>
            <span className="text-xl sm:text-2xl font-black text-yellow-400">{formattedAmount}</span>
          </div>
        </div>

        {/* Notice Card */}
        <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl text-xs text-slate-300 flex items-start space-x-2.5">
          <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <span>
            This is a mock payment simulation. <strong>No actual bank account or credit card will be charged.</strong>
          </span>
        </div>

        {/* Dynamic State Alerts */}
        {processingState === 'success' && (
          <div className="p-4 bg-emerald-500/15 border border-emerald-500/40 rounded-2xl flex items-start space-x-3 text-emerald-300 animate-fadeIn">
            <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-black text-white">Payment successful</h4>
              <p className="text-xs text-emerald-200 mt-0.5">
                Your live game is ready. Unlocking your quiz room...
              </p>
            </div>
          </div>
        )}

        {processingState === 'failed' && (
          <div className="p-4 bg-rose-500/15 border border-rose-500/40 rounded-2xl flex items-start space-x-3 text-rose-300 animate-fadeIn">
            <XCircle className="w-6 h-6 text-rose-400 flex-shrink-0" />
            <div className="space-y-1">
              <h4 className="text-sm font-black text-white">Payment failed</h4>
              <p className="text-xs text-rose-200">
                Your game has not been launched. No payment was recorded.
              </p>
              {errorMessage && (
                <p className="text-[11px] text-rose-400 font-mono pt-1">
                  Reason: {errorMessage}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="space-y-2.5 pt-2">
          {processingState === 'processing' ? (
            <button
              disabled
              className="w-full py-4 rounded-2xl bg-yellow-400/70 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center space-x-2 cursor-wait shadow-lg"
            >
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Processing Payment...</span>
            </button>
          ) : processingState === 'success' ? (
            <div className="w-full py-3.5 rounded-2xl bg-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-2">
              <CheckCircle2 className="w-4 h-4 stroke-[3]" />
              <span>Launching Live Room...</span>
            </div>
          ) : (
            <>
              <button
                type="button"
                onClick={() => handleSimulatePayment(false)}
                className="w-full py-3.5 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center space-x-2 shadow-lg shadow-yellow-400/20 active:scale-98"
              >
                <CheckCircle2 className="w-4 h-4 stroke-[3]" />
                <span>Simulate Successful Payment</span>
              </button>

              <button
                type="button"
                onClick={() => handleSimulatePayment(true)}
                className="w-full py-3 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-rose-200 border border-rose-500/40 font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center space-x-2"
              >
                <XCircle className="w-4 h-4" />
                <span>Simulate Failed Payment</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white font-bold text-xs uppercase tracking-wider transition-colors"
              >
                Cancel
              </button>
            </>
          )}
        </div>

      </div>
    </div>
  );
};
