import React, { useState, useEffect } from 'react';
import { 
  CreditCard, Search, Filter, CheckCircle2, XCircle, Clock, 
  RefreshCw, Users, ShieldCheck, Download, AlertCircle, ArrowUpRight 
} from 'lucide-react';
import { PaymentRecord, PaymentStatus } from '../services/payment/types';
import { paymentService } from '../services/payment/paymentService';
import { formatPrice, CURRENCY_SYMBOL } from '../config/pricingConfig';

interface PaymentHistoryViewProps {
  hostId: string;
  onOpenPricing?: () => void;
  onOpenWizard?: () => void;
}

export const PaymentHistoryView: React.FC<PaymentHistoryViewProps> = ({
  hostId,
  onOpenPricing,
  onOpenWizard
}) => {
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | PaymentStatus>('ALL');

  const loadPayments = async () => {
    setLoading(true);
    try {
      const records = await paymentService.fetchHostPayments(hostId);
      setPayments(records);
    } catch (err) {
      console.error('Failed to load host payments:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPayments();
  }, [hostId]);

  const filteredPayments = payments.filter((p) => {
    const matchesSearch = 
      p.quiz_title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.reference?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalSpent = payments
    .filter(p => p.status === 'SUCCESS')
    .reduce((sum, p) => sum + (p.amount || 0), 0);

  const successfulCount = payments.filter(p => p.status === 'SUCCESS').length;

  const getStatusBadge = (status: PaymentStatus) => {
    switch (status) {
      case 'SUCCESS':
        return (
          <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3" />
            <span>Success</span>
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-rose-500/15 text-rose-400 border border-rose-500/30">
            <XCircle className="w-3 h-3" />
            <span>Failed</span>
          </span>
        );
      case 'PENDING':
      default:
        return (
          <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <Clock className="w-3 h-3" />
            <span>Pending</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center space-x-2">
            <CreditCard className="w-6 h-6 text-yellow-400" />
            <span>Billing & Payments</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 font-semibold mt-1">
            Track your pay-as-you-go live game transactions and entitlements
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={loadPayments}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors"
            title="Refresh payment records"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          {onOpenPricing && (
            <button
              onClick={onOpenPricing}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-yellow-400 border border-yellow-400/30 text-xs font-black uppercase tracking-wider transition-all flex items-center space-x-1.5"
            >
              <span>View Pricing Tiers</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-1">
          <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Total Games Funded</span>
          <div className="text-2xl font-black text-white">{successfulCount}</div>
          <span className="text-[11px] text-emerald-400 font-semibold">Pay-As-You-Go unlocked</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-1">
          <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Total Investment</span>
          <div className="text-2xl font-black text-yellow-400">{formatPrice(totalSpent)}</div>
          <span className="text-[11px] text-slate-400 font-semibold">No recurring charges</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-1">
          <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Active Provider</span>
          <div className="text-lg font-black text-white uppercase flex items-center space-x-2">
            <span>Mock Gateway</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">Sandbox</span>
          </div>
          <span className="text-[11px] text-slate-400 font-semibold">Paystack ready</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by quiz or reference..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-950/80 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-yellow-400"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto overflow-x-auto">
          {(['ALL', 'SUCCESS', 'FAILED', 'PENDING'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-yellow-400 text-slate-950 font-black'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Payment Records Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {loading ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-yellow-400" />
            <p className="text-xs font-semibold">Loading payment transactions...</p>
          </div>
        ) : filteredPayments.length === 0 ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-500 mx-auto flex items-center justify-center">
              <CreditCard className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="text-base font-extrabold text-white">No payment transactions found</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {searchQuery || statusFilter !== 'ALL'
                  ? 'Try adjusting your search query or status filter.'
                  : 'You have not made any paid live game checkouts yet. Free games (0–5 players) do not require payments.'}
              </p>
            </div>
            {onOpenWizard && (
              <button
                onClick={onOpenWizard}
                className="px-5 py-2 rounded-xl bg-yellow-400 text-slate-950 text-xs font-black uppercase tracking-wider hover:bg-yellow-300 transition-colors"
              >
                Create a Live Quiz
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] font-black tracking-wider border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Date & Time</th>
                  <th className="px-5 py-3.5">Quiz Event</th>
                  <th className="px-5 py-3.5">Capacity</th>
                  <th className="px-5 py-3.5">Amount</th>
                  <th className="px-5 py-3.5">Status</th>
                  <th className="px-5 py-3.5">Reference</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {filteredPayments.map((pay) => (
                  <tr key={pay.id || pay.reference} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-4 text-slate-400 whitespace-nowrap">
                      {new Date(pay.created_at).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}{' '}
                      <span className="text-[10px] text-slate-500">
                        {new Date(pay.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </td>
                    <td className="px-5 py-4 font-bold text-white max-w-[220px] truncate">
                      {pay.quiz_title}
                    </td>
                    <td className="px-5 py-4 text-slate-300">
                      <span className="flex items-center space-x-1.5">
                        <Users className="w-3.5 h-3.5 text-slate-500" />
                        <span>{pay.player_capacity} Players</span>
                      </span>
                    </td>
                    <td className="px-5 py-4 font-black text-yellow-400 whitespace-nowrap">
                      {formatPrice(pay.amount)}
                    </td>
                    <td className="px-5 py-4 whitespace-nowrap">
                      {getStatusBadge(pay.status)}
                    </td>
                    <td className="px-5 py-4 font-mono text-[11px] text-slate-400 select-all whitespace-nowrap">
                      {pay.reference}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
