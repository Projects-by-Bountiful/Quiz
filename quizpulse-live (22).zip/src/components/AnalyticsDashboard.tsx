import React from 'react';
import { BarChart3, Users, Trophy, Award, Target, HelpCircle, TrendingUp, Clock, Zap, Timer, Flame } from 'lucide-react';
import { GameHistoryRecord, Question } from '../types';
import { calculateSessionSummary } from '../utils/stats';
import { AnalyticsData } from '../lib/supabaseService';

interface AnalyticsDashboardProps {
  history?: GameHistoryRecord[];
  historyRecords?: GameHistoryRecord[];
  questions?: Question[];
  analyticsData?: AnalyticsData | null;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  history,
  historyRecords,
  questions,
  analyticsData
}) => {
  const safeHistory = history || historyRecords || [];
  const safeQuestions = questions || [];

  let totalGames = safeHistory.length;
  let totalParticipants = 0;
  let accuracySum = 0;
  let scoreSum = 0;
  let totalResponseTimeSum = 0;
  let responseTimeCount = 0;
  let highestScore = 0;
  let fastestResponse = 999;
  let totalDurationSecSum = 0;

  const winnerCounts: Record<string, number> = {};

  safeHistory.forEach(rec => {
    if (rec.fullSession) {
      const summary = calculateSessionSummary(rec.fullSession);
      totalParticipants += summary.totalParticipants;
      accuracySum += summary.averageAccuracy;
      scoreSum += summary.averageScore;
      if (summary.averageResponseTime > 0) {
        totalResponseTimeSum += summary.averageResponseTime;
        responseTimeCount++;
      }
      if (summary.highestScore > highestScore) {
        highestScore = summary.highestScore;
      }
      if (summary.fastestResponse > 0 && summary.fastestResponse < fastestResponse) {
        fastestResponse = summary.fastestResponse;
      }
      totalDurationSecSum += summary.sessionDurationSec;
    } else {
      const pCount = rec.totalParticipants || (rec.participants || []).length;
      totalParticipants += pCount;
      accuracySum += rec.averageAccuracy || 0;

      const avgScore = rec.averageScore || (rec.participants?.length ? Math.round(rec.participants.reduce((s, p) => s + (p.score || 0), 0) / rec.participants.length) : 0);
      scoreSum += avgScore;

      if (rec.participants && rec.participants.length > 0) {
        const gameAvgTime = rec.participants.reduce((s, p) => s + (p.avgTime || 0), 0) / rec.participants.length;
        if (gameAvgTime > 0) {
          totalResponseTimeSum += gameAvgTime;
          responseTimeCount++;
        }
        rec.participants.forEach(p => {
          if (p.avgTime > 0 && p.avgTime < fastestResponse) {
            fastestResponse = p.avgTime;
          }
        });
      }

      const wScore = rec.winnerScore || 0;
      if (wScore > highestScore) {
        highestScore = wScore;
      }

      totalDurationSecSum += (rec.totalQuestions || 10) * 20;
    }

    if (rec.winnerName && rec.winnerName !== 'N/A') {
      winnerCounts[rec.winnerName] = (winnerCounts[rec.winnerName] || 0) + 1;
    }
  });

  const computedAvgPlatformAccuracy = totalGames > 0 ? Math.round(accuracySum / totalGames) : 0;
  const computedAvgPlatformScore = totalGames > 0 ? Math.round(scoreSum / totalGames) : 0;
  const computedAvgResponseTime = responseTimeCount > 0 ? Number((totalResponseTimeSum / responseTimeCount).toFixed(1)) : 0;
  const computedValidFastestResponse = fastestResponse < 999 ? Number(fastestResponse.toFixed(1)) : 0;
  const computedAvgSessionDurationSec = totalGames > 0 ? Math.round(totalDurationSecSum / totalGames) : 0;

  const computedTopRepeatWinners = Object.entries(winnerCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const displayTotalGames = analyticsData?.totalGames ?? totalGames;
  const displayTotalParticipants = analyticsData?.totalParticipants ?? totalParticipants;
  const displayAvgAccuracy = analyticsData?.avgPlatformAccuracy ?? computedAvgPlatformAccuracy;
  const displayAvgScore = analyticsData?.avgPlatformScore ?? computedAvgPlatformScore;
  const displayAvgResponseTime = analyticsData?.avgResponseTime ?? computedAvgResponseTime;
  const displayHighestScore = analyticsData?.highestScore ?? highestScore;
  const displayFastestResponse = analyticsData?.fastestResponse ?? computedValidFastestResponse;
  const displayAvgDurationSec = analyticsData?.avgSessionDurationSec ?? computedAvgSessionDurationSec;
  const displayTopRepeatWinners = analyticsData?.topRepeatWinners ?? computedTopRepeatWinners;

  return (
    <div className="w-full space-y-8 min-w-0">
      
      {/* Header */}
      <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl">
        <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center space-x-3">
          <div className="p-2.5 bg-amber-400 text-indigo-950 rounded-2xl shadow">
            <BarChart3 className="w-6 h-6 stroke-[2.5]" />
          </div>
          <span>Platform Analytics & Historical Insights</span>
        </h1>
        <p className="text-xs text-indigo-200 mt-2 font-semibold">
          Aggregated metrics derived from completed sessions, participant answers, and question performance
        </p>
      </div>

      {/* Metric Cards Grid - Row 1 (Mobile 1, Tablet 2, Desktop 4) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Total Games Hosted</span>
            <Trophy className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayTotalGames}</p>
          <span className="text-[10px] text-emerald-400 font-bold mt-1 inline-block">Completed Sessions</span>
        </div>

        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Total Participants</span>
            <Users className="w-5 h-5 text-cyan-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayTotalParticipants}</p>
          <span className="text-[10px] text-cyan-300 font-bold mt-1 inline-block">Active Competitors</span>
        </div>

        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Average Accuracy</span>
            <Target className="w-5 h-5 text-emerald-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayAvgAccuracy}%</p>
          <span className="text-[10px] text-emerald-400 font-bold mt-1 inline-block">Overall Correct Ratio</span>
        </div>

        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Average Score</span>
            <Award className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayAvgScore} <span className="text-sm font-normal text-indigo-300">pts</span></p>
          <span className="text-[10px] text-amber-300 font-bold mt-1 inline-block">Per Player / Game</span>
        </div>

      </div>

      {/* Metric Cards Grid - Row 2 (Mobile 1, Tablet 2, Desktop 4) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Avg Response Time</span>
            <Clock className="w-5 h-5 text-cyan-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayAvgResponseTime} <span className="text-sm font-normal text-indigo-300">sec</span></p>
          <span className="text-[10px] text-cyan-300 font-bold mt-1 inline-block">Per Answer Submission</span>
        </div>

        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Highest Score</span>
            <Flame className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayHighestScore} <span className="text-sm font-normal text-indigo-300">pts</span></p>
          <span className="text-[10px] text-amber-400 font-bold mt-1 inline-block">All-Time High Score</span>
        </div>

        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Fastest Response</span>
            <Zap className="w-5 h-5 text-yellow-400" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{displayFastestResponse} <span className="text-sm font-normal text-indigo-300">sec</span></p>
          <span className="text-[10px] text-yellow-400 font-bold mt-1 inline-block">Record Answer Speed</span>
        </div>

        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Avg Session Duration</span>
            <Timer className="w-5 h-5 text-indigo-300" />
          </div>
          <p className="text-3xl font-black text-white mt-2">{Math.floor(displayAvgDurationSec / 60)}m {displayAvgDurationSec % 60}s</p>
          <span className="text-[10px] text-indigo-300 font-bold mt-1 inline-block">Per Full Quiz Event</span>
        </div>

      </div>

      {/* Main Insights Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Top Winners */}
        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
          <h2 className="text-base font-black text-white flex items-center space-x-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span>Repeat Champions</span>
          </h2>

          {displayTopRepeatWinners.length === 0 ? (
            <p className="text-xs text-indigo-300 italic py-4">No completed game history records yet.</p>
          ) : (
            <div className="space-y-2">
              {displayTopRepeatWinners.map(([name, count], idx) => (
                <div key={`${name}-${idx}`} className="flex items-center justify-between p-3.5 bg-indigo-950/70 rounded-2xl border border-indigo-500/30">
                  <div className="flex items-center space-x-3">
                    <span className="w-6 h-6 rounded-lg bg-amber-400 text-indigo-950 font-black text-xs flex items-center justify-center">
                      #{idx + 1}
                    </span>
                    <span className="font-bold text-white text-sm">{name}</span>
                  </div>
                  <span className="text-xs font-black text-amber-400 bg-amber-400/20 px-3 py-1 rounded-full border border-amber-400/30">
                    {count} {count === 1 ? 'Victory' : 'Victories'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Categories Distribution */}
        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
          <h2 className="text-base font-black text-white flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-amber-400" />
            <span>Question Bank Category Distribution</span>
          </h2>

          <div className="space-y-4">
            {['Web Development', 'JavaScript & React', 'AI & Machine Learning', 'UI/UX Design', 'Business & Finance'].map((cat) => {
              const count = safeQuestions.filter(q => q.category === cat).length;
              const percent = safeQuestions.length > 0 ? Math.round((count / safeQuestions.length) * 100) : 0;
              return (
                <div key={cat} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-indigo-100">{cat}</span>
                    <span className="text-amber-400">{count} ({percent}%)</span>
                  </div>
                  <div className="w-full h-2.5 bg-indigo-950 rounded-full overflow-hidden border border-indigo-700/50">
                    <div className="h-full bg-amber-400 rounded-full" style={{ width: `${percent}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};

