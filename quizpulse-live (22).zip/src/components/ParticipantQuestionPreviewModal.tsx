import React, { useState } from 'react';
import { Eye, X, CheckCircle, Clock, Sparkles, Smartphone, Monitor } from 'lucide-react';
import { Question } from '../types';

interface ParticipantQuestionPreviewModalProps {
  question: Question | null;
  isOpen: boolean;
  onClose: () => void;
  timerDurationSec?: number;
}

export const ParticipantQuestionPreviewModal: React.FC<ParticipantQuestionPreviewModalProps> = ({
  question,
  isOpen,
  onClose,
  timerDurationSec = 20
}) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [viewMode, setViewMode] = useState<'mobile' | 'desktop'>('mobile');

  if (!isOpen || !question) return null;

  const optionColors = [
    'bg-indigo-600 hover:bg-indigo-500 border-indigo-400 text-white',
    'bg-emerald-600 hover:bg-emerald-500 border-emerald-400 text-white',
    'bg-amber-600 hover:bg-amber-500 border-amber-400 text-white',
    'bg-rose-600 hover:bg-rose-500 border-rose-400 text-white'
  ];

  const optionLabels = ['A', 'B', 'C', 'D'];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 shadow-2xl relative space-y-5">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                Participant Screen Preview
              </h3>
              <p className="text-xs text-slate-400 font-semibold">
                Simulated view of live game question on player devices
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setViewMode('mobile')}
                className={`p-1.5 rounded-lg flex items-center space-x-1 transition-all ${
                  viewMode === 'mobile' ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                }`}
                title="Mobile View"
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('desktop')}
                className={`p-1.5 rounded-lg flex items-center space-x-1 transition-all ${
                  viewMode === 'desktop' ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                }`}
                title="Desktop View"
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Device Frame Simulation */}
        <div className={`mx-auto transition-all ${viewMode === 'mobile' ? 'max-w-sm' : 'w-full'}`}>
          <div className="bg-indigo-950 border-4 border-slate-800 rounded-3xl p-5 shadow-2xl relative space-y-4">
            
            {/* Top Device Bar */}
            <div className="flex items-center justify-between text-xs text-indigo-200 border-b border-indigo-800/60 pb-3">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="font-black text-white text-[11px] tracking-wide">QuizPulse Live</span>
              </div>
              <div className="flex items-center space-x-1 bg-amber-400/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-400/30 text-[11px] font-black">
                <Clock className="w-3 h-3" />
                <span>{timerDurationSec}s</span>
              </div>
            </div>

            {/* Category & Difficulty Header */}
            <div className="flex items-center justify-between text-[11px]">
              <span className="px-2.5 py-0.5 bg-indigo-900/80 text-indigo-200 font-bold rounded-lg border border-indigo-700/50">
                {question.category}
              </span>
              <span className="px-2.5 py-0.5 bg-slate-800 text-slate-300 font-bold rounded-lg border border-slate-700">
                {question.difficulty}
              </span>
            </div>

            {/* Question Text */}
            <div className="bg-indigo-900/40 border border-indigo-700/40 rounded-2xl p-4 min-h-[80px] flex items-center justify-center text-center">
              <h4 className="text-sm sm:text-base font-black text-white leading-snug">
                {question.question}
              </h4>
            </div>

            {/* Options List */}
            <div className="grid grid-cols-1 gap-2.5">
              {question.options.map((optText, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = question.correctAnswer === idx;

                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedOption(idx)}
                    className={`w-full p-3 rounded-2xl font-bold text-xs sm:text-sm text-left flex items-center justify-between border-2 transition-all transform active:scale-98 ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-lg shadow-amber-400/20'
                        : 'bg-indigo-900/60 text-slate-100 border-indigo-800/80 hover:border-indigo-500'
                    }`}
                  >
                    <div className="flex items-center space-x-3 overflow-hidden pr-2">
                      <span className={`w-6 h-6 rounded-lg font-black text-xs flex items-center justify-center flex-shrink-0 ${
                        isSelected ? 'bg-slate-950 text-amber-400' : 'bg-indigo-950 text-indigo-200'
                      }`}>
                        {optionLabels[idx]}
                      </span>
                      <span className="truncate">{optText}</span>
                    </div>

                    {isCorrect && (
                      <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase rounded-md border border-emerald-400/40 flex items-center space-x-1 flex-shrink-0">
                        <CheckCircle className="w-3 h-3 text-emerald-400" />
                        <span>Correct</span>
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation Note (Host Preview Info) */}
            {question.explanation && (
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-300 space-y-1">
                <span className="font-bold text-amber-400 uppercase tracking-wider block text-[10px]">
                  💡 Explanation Preview:
                </span>
                <p className="italic text-slate-400">{question.explanation}</p>
              </div>
            )}

          </div>
        </div>

        {/* Footer info */}
        <div className="text-center pt-2 text-xs text-slate-400 font-semibold">
          Click any option above to test selection state. Participants will see this layout on their screens.
        </div>

      </div>
    </div>
  );
};
