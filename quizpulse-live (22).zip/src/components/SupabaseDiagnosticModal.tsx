import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, XCircle, AlertTriangle, RefreshCw, Copy, Check, ExternalLink, Terminal, ShieldCheck, Layers } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../utils/supabase';

interface SupabaseDiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TableStatus {
  name: string;
  exists: boolean;
  count: number | null;
  error?: string;
  status: 'checking' | 'ok' | 'error' | 'missing';
}

export const SupabaseDiagnosticModal: React.FC<SupabaseDiagnosticModalProps> = ({ isOpen, onClose }) => {
  const [testing, setTesting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [overallStatus, setOverallStatus] = useState<'checking' | 'connected' | 'warning' | 'error'>('checking');
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [tables, setTables] = useState<TableStatus[]>([
    { name: 'profiles', exists: false, count: null, status: 'checking' },
    { name: 'categories', exists: false, count: null, status: 'checking' },
    { name: 'questions', exists: false, count: null, status: 'checking' },
    { name: 'quiz_rooms', exists: false, count: null, status: 'checking' },
    { name: 'participants', exists: false, count: null, status: 'checking' },
    { name: 'answers', exists: false, count: null, status: 'checking' },
    { name: 'game_results', exists: false, count: null, status: 'checking' },
  ]);

  const metaEnv = (import.meta as any).env || {};
  const supabaseUrl = metaEnv.VITE_SUPABASE_URL || process.env.VITE_SUPABASE_URL || '';
  const hasKeys = isSupabaseConfigured();

  const runDiagnostics = async () => {
    setTesting(true);
    setOverallStatus('checking');

    if (!supabase) {
      setOverallStatus('error');
      setTesting(false);
      return;
    }

    const startTime = performance.now();
    const updatedTables: TableStatus[] = [];
    let hasAnyError = false;
    let hasMissingTable = false;

    const tableNames = ['questions', 'quiz_rooms', 'participants', 'answers', 'game_results'];

    for (const tableName of tableNames) {
      try {
        const { data, count, error } = await supabase
          .from(tableName)
          .select('*', { count: 'exact', head: true });

        if (error) {
          if (error.code === '42P01') { // Table missing
            updatedTables.push({
              name: tableName,
              exists: false,
              count: null,
              error: 'Table does not exist yet',
              status: 'missing'
            });
            hasMissingTable = true;
          } else if (error.code === '42501' || error.message?.includes('row-level security')) {
            updatedTables.push({
              name: tableName,
              exists: true,
              count: null,
              error: 'Row-Level Security (RLS) enabled. Disable RLS using the SQL script below.',
              status: 'error'
            });
            hasAnyError = true;
          } else {
            updatedTables.push({
              name: tableName,
              exists: true,
              count: null,
              error: error.message,
              status: 'error'
            });
            hasAnyError = true;
          }
        } else {
          updatedTables.push({
            name: tableName,
            exists: true,
            count: count ?? 0,
            status: 'ok'
          });
        }
      } catch (err: any) {
        updatedTables.push({
          name: tableName,
          exists: false,
          count: null,
          error: err?.message || 'Unknown network error',
          status: 'error'
        });
        hasAnyError = true;
      }
    }

    const duration = Math.round(performance.now() - startTime);
    setLatencyMs(duration);
    setTables(updatedTables);

    if (hasMissingTable) {
      setOverallStatus('warning');
    } else if (hasAnyError) {
      setOverallStatus('error');
    } else {
      setOverallStatus('connected');
    }

    setTesting(false);
  };

  useEffect(() => {
    if (isOpen) {
      runDiagnostics();
    }
  }, [isOpen]);

  const sqlSchema = `-- Copy & Paste into your Supabase SQL Editor:
CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  location TEXT,
  industry TEXT,
  company TEXT,
  job_title TEXT,
  timezone TEXT DEFAULT 'UTC',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY,
  question TEXT NOT NULL,
  options JSONB NOT NULL,
  correct_answer INT NOT NULL,
  category TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  explanation TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS quiz_rooms (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  host_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'LOBBY',
  current_question_index INT DEFAULT 0,
  timer_duration_sec INT DEFAULT 20,
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  questions JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS participants (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES quiz_rooms(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  avatar TEXT,
  score INT DEFAULT 0,
  streak INT DEFAULT 0,
  joined_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS answers (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES quiz_rooms(id) ON DELETE CASCADE,
  participant_id TEXT NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
  question_index INT NOT NULL,
  selected_option INT NOT NULL,
  is_correct BOOLEAN NOT NULL,
  points_awarded INT DEFAULT 0,
  time_taken_ms INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS game_results (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL,
  title TEXT NOT NULL,
  participant_count INT DEFAULT 0,
  leaderboard JSONB NOT NULL DEFAULT '[]'::jsonb,
  completed_at TIMESTAMPTZ DEFAULT NOW()
);

-- Disable Row Level Security (RLS) to allow public access for quiz app:
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE questions DISABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_rooms DISABLE ROW LEVEL SECURITY;
ALTER TABLE participants DISABLE ROW LEVEL SECURITY;
ALTER TABLE answers DISABLE ROW LEVEL SECURITY;
ALTER TABLE game_results DISABLE ROW LEVEL SECURITY;

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE quiz_rooms, participants, answers;`;

  const copySql = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl text-white max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-5 mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">Supabase Connection Diagnostics</h2>
              <p className="text-xs text-slate-400 font-medium">Real-time status & schema verifier for QuizPulse</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Status Summary Banner */}
        <div className={`p-4 rounded-2xl border mb-6 flex items-start space-x-4 ${
          overallStatus === 'connected' 
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            : overallStatus === 'warning'
            ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
            : 'bg-red-500/10 border-red-500/30 text-red-300'
        }`}>
          {overallStatus === 'connected' && <CheckCircle2 className="w-6 h-6 shrink-0 text-emerald-400 mt-0.5" />}
          {overallStatus === 'warning' && <AlertTriangle className="w-6 h-6 shrink-0 text-amber-400 mt-0.5" />}
          {overallStatus === 'error' && <XCircle className="w-6 h-6 shrink-0 text-red-400 mt-0.5" />}

          <div className="flex-1">
            <h3 className="font-bold text-sm uppercase tracking-wider">
              {overallStatus === 'connected' && 'Supabase Connected & Operational'}
              {overallStatus === 'warning' && 'Supabase Client Connected (Tables Pending Setup)'}
              {overallStatus === 'error' && 'Supabase Connection Error'}
              {overallStatus === 'checking' && 'Testing Connection...'}
            </h3>
            <p className="text-xs opacity-90 mt-1">
              {overallStatus === 'connected' && `Successfully connected to ${supabaseUrl}. All required tables are accessible.`}
              {overallStatus === 'warning' && `Connected to ${supabaseUrl}, but one or more tables are missing in your database schema.`}
              {overallStatus === 'error' && (!hasKeys ? 'VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are not configured.' : 'Failed to communicate with Supabase backend.')}
            </p>
            {latencyMs !== null && (
              <span className="inline-block mt-2 text-[10px] font-mono bg-slate-950/40 px-2 py-0.5 rounded border border-slate-700/50">
                Response Time: {latencyMs}ms
              </span>
            )}
          </div>

          <button
            onClick={runDiagnostics}
            disabled={testing}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition-all flex items-center space-x-1.5 border border-slate-700 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
            <span>Retest</span>
          </button>
        </div>

        {/* Credentials Info */}
        <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 mb-6 space-y-2 text-xs">
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Endpoint URL:</span>
            <span className="font-mono text-slate-200 truncate max-w-[280px]">{supabaseUrl || 'Not configured'}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Anon Key Status:</span>
            <span className={`font-semibold ${hasKeys ? 'text-emerald-400' : 'text-red-400'}`}>
              {hasKeys ? 'Present (Valid Format)' : 'Missing'}
            </span>
          </div>
        </div>

        {/* Table Diagnostic List */}
        <div className="mb-6">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center space-x-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>Database Tables Health Check</span>
          </h4>

          <div className="space-y-2">
            {tables.map(t => (
              <div 
                key={t.name} 
                className="bg-slate-950/40 border border-slate-800 p-3 rounded-xl flex items-center justify-between text-xs"
              >
                <div className="flex items-center space-x-3">
                  {t.status === 'ok' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  {t.status === 'missing' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                  {t.status === 'error' && <XCircle className="w-4 h-4 text-red-400" />}
                  {t.status === 'checking' && <RefreshCw className="w-4 h-4 text-slate-400 animate-spin" />}
                  
                  <span className="font-mono font-bold text-slate-200">{t.name}</span>
                </div>

                <div className="flex items-center space-x-3">
                  {t.status === 'ok' && (
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded text-[11px] font-mono">
                      {t.count !== null ? `${t.count} records` : 'Ready'}
                    </span>
                  )}
                  {t.status === 'missing' && (
                    <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded text-[11px]">
                      Table missing
                    </span>
                  )}
                  {t.status === 'error' && (
                    <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded text-[11px] truncate max-w-[200px]" title={t.error}>
                      {t.error}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SQL Migration Assistant */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2 text-xs font-bold text-yellow-400">
              <Terminal className="w-4 h-4" />
              <span>Supabase SQL Migration Script</span>
            </div>
            <button
              onClick={copySql}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors flex items-center space-x-1"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy SQL'}</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-400 mb-3">
            If any tables show as missing or if you are setting up a fresh Supabase project, execute this script in your Supabase SQL Editor:
          </p>
          <pre className="bg-slate-900 border border-slate-800/80 p-3 rounded-xl text-[11px] font-mono text-slate-300 max-h-40 overflow-y-auto whitespace-pre">
            {sqlSchema}
          </pre>
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-bold text-white transition-colors"
          >
            Close Diagnostics
          </button>
        </div>

      </div>
    </div>
  );
};
