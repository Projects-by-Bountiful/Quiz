import React, { useState } from 'react';
import { Star, Send, CheckCircle2, MessageSquare } from 'lucide-react';

interface EventFeedbackComponentProps {
  onSubmitFeedback: (rating: number, comment?: string) => void;
}

export const EventFeedbackComponent: React.FC<EventFeedbackComponentProps> = ({
  onSubmitFeedback
}) => {
  const [rating, setRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [comment, setComment] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) return;
    onSubmitFeedback(rating, comment);
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center space-y-3 shadow-2xl animate-fade-in">
        <div className="w-12 h-12 bg-emerald-400 text-slate-950 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
          <CheckCircle2 className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-black text-white">Feedback Submitted!</h3>
        <p className="text-xs text-slate-400 font-semibold">Thank you for helping us improve the event experience.</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
      <div className="flex items-center space-x-2 text-yellow-400 font-black text-xs uppercase tracking-widest">
        <MessageSquare className="w-4 h-4" />
        <span>Event Feedback</span>
      </div>

      <div className="space-y-1">
        <h3 className="text-lg font-black text-white">How was your session experience?</h3>
        <p className="text-xs text-slate-400 font-medium">Rate the quiz and leave an optional comment for the host.</p>
      </div>

      {/* Interactive 5-Star Rating Selector */}
      <div className="flex items-center justify-center space-x-2 py-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoverRating(star)}
            onMouseLeave={() => setHoverRating(0)}
            className="p-1 transition-transform hover:scale-125 focus:outline-none"
          >
            <Star
              className={`w-8 h-8 ${
                star <= (hoverRating || rating)
                  ? 'text-yellow-400 fill-current drop-shadow-md'
                  : 'text-slate-700'
              }`}
            />
          </button>
        ))}
      </div>

      {/* Optional Comment Field */}
      <form onSubmit={handleSubmit} className="space-y-3">
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Share your thoughts with the host (optional)..."
          rows={2}
          className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-yellow-400 transition-all resize-none"
        />

        <button
          type="submit"
          disabled={rating === 0}
          className={`w-full py-3 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all shadow-lg ${
            rating > 0
              ? 'bg-yellow-400 hover:bg-yellow-300 text-slate-950 cursor-pointer active:scale-95'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
          <span>Submit Rating</span>
        </button>
      </form>
    </div>
  );
};
