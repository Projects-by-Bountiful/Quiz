import React, { useState } from 'react';
import { 
  PlayCircle, Volume2, VolumeX, Home, Sparkles, User, LogOut, 
  LayoutDashboard, Menu, X, Zap 
} from 'lucide-react';
import { Role } from '../types';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  currentRole: Role;
  onSelectRole: (role: Role) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  activeSessionCode?: string;
  onOpenDiagnostic?: () => void;
  onToggleHostMobileDrawer?: () => void;
  isHostMobileDrawerOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onSelectRole,
  soundEnabled,
  onToggleSound,
  activeSessionCode,
  onOpenDiagnostic,
  onToggleHostMobileDrawer,
  isHostMobileDrawerOpen
}) => {
  const { user, profile, signOutHost } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isHostAuthenticated = Boolean(user || profile);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    if (currentRole !== 'landing') {
      onSelectRole('landing');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  // Show the Host Workspace Header when viewing a host workspace section
  if (isHostAuthenticated && currentRole.startsWith('host_')) {
    return (
      <header className="bg-slate-950 border-b border-slate-800 text-white h-[68px] flex-shrink-0 z-40 shadow-lg font-sans w-full block">
        <div className="w-full max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
          
          {/* Brand Logo */}
          <div 
            onClick={() => onSelectRole('host_dashboard')}
            className="flex items-center space-x-3 cursor-pointer group flex-shrink-0"
          >
            <div className="w-9 h-9 rounded-xl bg-yellow-400 text-slate-950 flex items-center justify-center font-black text-lg shadow-md group-hover:scale-105 transition-transform">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <span className="text-lg sm:text-xl font-black tracking-tight text-white leading-tight block">
                QuizPulse
              </span>
              <p className="text-[10px] text-yellow-400 font-extrabold uppercase tracking-widest leading-none">Host Workspace</p>
            </div>
          </div>

          {/* Host Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center space-x-1.5 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => onSelectRole('host_dashboard')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                currentRole.startsWith('host_')
                  ? 'bg-yellow-400 text-slate-950 shadow-md font-black'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Workspace</span>
            </button>

            <button
              onClick={() => onSelectRole('landing')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                currentRole === 'landing'
                  ? 'bg-slate-800 text-yellow-400 border border-yellow-400/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span>Landing Page</span>
            </button>

            <button
              onClick={() => onSelectRole('participant')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                currentRole === 'participant'
                  ? 'bg-slate-800 text-yellow-400 border border-yellow-400/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <PlayCircle className="w-3.5 h-3.5" />
              <span>Join Game</span>
            </button>
          </nav>

          {/* Right Controls */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {activeSessionCode && (
              <div className="hidden sm:flex items-center space-x-2 px-3 py-1 bg-emerald-400/10 border border-emerald-400/30 rounded-xl text-xs font-black text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>ROOM: {activeSessionCode}</span>
              </div>
            )}

            <button
              onClick={onToggleSound}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors border border-slate-800"
              title={soundEnabled ? 'Mute Sounds' : 'Enable Sounds'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-yellow-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>

            <button
              onClick={signOutHost}
              className="hidden md:flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-rose-950/60 text-slate-300 hover:text-rose-400 transition-colors border border-slate-800 text-xs font-bold"
              title="Logout Host"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>

            {/* Mobile Drawer Hamburger Button */}
            <button
              onClick={onToggleHostMobileDrawer}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 md:hidden flex items-center justify-center"
              title="Toggle Workspace Menu"
              aria-label="Toggle Workspace Menu"
            >
              {isHostMobileDrawerOpen ? <X className="w-5 h-5 text-yellow-400" /> : <Menu className="w-5 h-5 text-yellow-400" />}
            </button>
          </div>
        </div>
      </header>
    );
  }

  // Otherwise, Public Landing Navigation Header (matching design image)
  return (
    <header className="bg-[#0B0E14]/90 backdrop-blur-md border-b border-white/10 text-white sticky top-0 z-50 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Brand Logo & Left Nav Items */}
        <div className="flex items-center space-x-8 lg:space-x-12">
          {/* Logo */}
          <div 
            onClick={() => onSelectRole('landing')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-2xl bg-yellow-400 text-slate-950 flex items-center justify-center font-black text-xl shadow-lg shadow-yellow-400/25 group-hover:scale-105 transition-transform">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
              QuizPulse
            </span>
          </div>

          {/* Nav Links */}
          <nav className="hidden lg:flex items-center space-x-7 text-sm font-semibold text-slate-200">
            <button 
              onClick={() => scrollToSection('features')} 
              className="hover:text-yellow-400 transition-colors"
            >
              Features
            </button>

            <button 
              onClick={() => scrollToSection('solutions')} 
              className="hover:text-yellow-400 transition-colors"
            >
              Solutions
            </button>

            <button 
              onClick={() => scrollToSection('how-it-works')} 
              className="hover:text-yellow-400 transition-colors"
            >
              How It Works
            </button>

            <button 
              onClick={() => {
                const el = document.querySelector('footer');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }} 
              className="hover:text-yellow-400 transition-colors"
            >
              Resources
            </button>

            {/* Pricing with COMING SOON badge */}
            <div className="relative inline-flex items-center">
              <button 
                onClick={() => scrollToSection('pricing')} 
                className="hover:text-yellow-400 transition-colors"
              >
                Pricing
              </button>
              <span className="absolute -top-3.5 -right-12 bg-yellow-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider shadow-sm pointer-events-none whitespace-nowrap">
                COMING SOON
              </span>
            </div>
          </nav>
        </div>

        {/* Right Nav CTAs */}
        <div className="hidden sm:flex items-center space-x-4">
          <button
            onClick={() => onSelectRole('participant')}
            className="text-sm font-bold text-slate-200 hover:text-white px-3 py-2 transition-colors"
          >
            Join Game
          </button>

          {isHostAuthenticated ? (
            <button
              onClick={() => onSelectRole('host_dashboard')}
              className="bg-yellow-400 hover:bg-yellow-300 text-slate-950 px-5 py-2.5 rounded-xl font-extrabold text-sm transition-all shadow-md hover:scale-105 active:scale-95 flex items-center gap-1.5"
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Workspace</span>
            </button>
          ) : (
            <>
              <button
                onClick={() => onSelectRole('login')}
                className="text-sm font-bold text-slate-200 hover:text-white px-3 py-2 transition-colors"
              >
                Login
              </button>

              <button
                onClick={() => onSelectRole('signup')}
                className="bg-yellow-400 hover:bg-yellow-300 text-slate-950 px-5 py-2.5 rounded-xl font-extrabold text-sm transition-all shadow-md hover:scale-105 active:scale-95 flex items-center gap-1.5"
              >
                <span>Host a Game</span>
              </button>
            </>
          )}
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center space-x-2 lg:hidden">
          <button
            onClick={() => setMobileMenuOpen(prev => !prev)}
            className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-200 hover:text-white"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0B0E14] border-b border-white/10 px-4 pt-3 pb-6 space-y-4 font-sans text-sm">
          <div className="flex flex-col space-y-3 font-semibold text-slate-200">
            <button 
              onClick={() => scrollToSection('features')} 
              className="text-left py-2 hover:text-yellow-400 border-b border-white/5"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('solutions')} 
              className="text-left py-2 hover:text-yellow-400 border-b border-white/5"
            >
              Solutions
            </button>
            <button 
              onClick={() => scrollToSection('how-it-works')} 
              className="text-left py-2 hover:text-yellow-400 border-b border-white/5"
            >
              How It Works
            </button>
            <button 
              onClick={() => {
                setMobileMenuOpen(false);
                const el = document.querySelector('footer');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }} 
              className="text-left py-2 hover:text-yellow-400 border-b border-white/5"
            >
              Resources
            </button>
            <div className="flex items-center justify-between py-2 border-b border-white/5">
              <button 
                onClick={() => scrollToSection('pricing')} 
                className="hover:text-yellow-400"
              >
                Pricing
              </button>
              <span className="bg-yellow-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider">
                COMING SOON
              </span>
            </div>
          </div>

          <div className="pt-2 flex flex-col space-y-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onSelectRole('participant');
              }}
              className="w-full py-2.5 text-center font-bold text-slate-200 bg-white/5 rounded-xl border border-white/10"
            >
              Join Game
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onSelectRole('login');
              }}
              className="w-full py-2.5 text-center font-bold text-slate-200 bg-white/5 rounded-xl border border-white/10"
            >
              Login
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onSelectRole('signup');
              }}
              className="w-full py-3 text-center font-extrabold text-slate-950 bg-yellow-400 rounded-xl"
            >
              Host a Game
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
