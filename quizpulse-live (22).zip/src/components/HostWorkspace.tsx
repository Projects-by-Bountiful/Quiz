import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Database, FolderPlus, PlusCircle, Radio, Users, 
  BarChart3, History, User, Settings, LogOut, Zap, Play, Sparkles, 
  Clock, Award, Activity, ArrowUpRight, Copy, RotateCcw, Download, Trash2,
  FileSpreadsheet, CheckCircle2, ShieldCheck, Globe, Briefcase, Building, AlertCircle,
  Menu, X, Sliders, Volume2, VolumeX, CreditCard, Tag
} from 'lucide-react';
import { Role, Question, GameSession, Category, GameHistoryRecord, HostProfile } from '../types';
import { useAuth } from '../context/AuthContext';
import { QuestionBank } from './QuestionBank';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { GameHistoryView } from './GameHistoryView';
import { PaymentHistoryView } from './PaymentHistoryView';
import { PricingModal } from './PricingModal';
import { QuizCreationWizardModal } from './QuizCreationWizardModal';
import { PresenterModeView } from './PresenterModeView';
import { HostOnboardingChecklist } from './HostOnboardingChecklist';
import { HostQuickTip } from './HostQuickTip';
import { fetchQuestionsFromSupabase, fetchGameResultsFromSupabase, fetchAnalyticsFromSupabase, AnalyticsData } from '../lib/supabaseService';
import { calculateSessionSummary } from '../utils/stats';

interface HostWorkspaceProps {
  currentTab: Role;
  onSelectTab: (tab: Role) => void;
  questions: Question[];
  categories: Category[];
  activeSession: GameSession | null;
  historyRecords: GameHistoryRecord[];
  onCreateQuestion: (question: Question) => void;
  onUpdateQuestion: (question: Question) => void;
  onDeleteQuestion: (id: string) => void;
  onBulkDeleteQuestions?: (ids: string[]) => void;
  onMoveQuestionsCategory?: (ids: string[], newCategory: Category) => void;
  onBulkImport: (questions: Question[]) => void;
  onCreateCategory: (categoryName: string) => void;
  onRenameCategory?: (oldName: string, newName: string) => void;
  onDeleteCategory: (categoryName: string) => void;
  onCreateSession: (title: string, settings: any, selectedQuestionIds?: string[]) => void;
  onOpenSession: (sessionId: string) => void;
  onDeleteHistoryRecord?: (id: string) => void;
  onOpenDiagnostic?: () => void;
  isMobileDrawerOpen?: boolean;
  onCloseMobileDrawer?: () => void;
}

export const HostWorkspace: React.FC<HostWorkspaceProps> = ({
  currentTab,
  onSelectTab,
  questions = [],
  categories = [],
  activeSession,
  historyRecords = [],
  onCreateQuestion,
  onUpdateQuestion,
  onDeleteQuestion,
  onBulkDeleteQuestions,
  onMoveQuestionsCategory,
  onBulkImport,
  onCreateCategory,
  onRenameCategory,
  onDeleteCategory,
  onCreateSession,
  onOpenSession,
  onDeleteHistoryRecord,
  onOpenDiagnostic,
  isMobileDrawerOpen,
  onCloseMobileDrawer
}) => {
  const [asyncHistory, setAsyncHistory] = useState<GameHistoryRecord[]>(historyRecords);
  const [asyncQuestions, setAsyncQuestions] = useState<Question[]>(questions);
  const [asyncAnalytics, setAsyncAnalytics] = useState<AnalyticsData | null>(null);
  const [isWidgetLoading, setIsWidgetLoading] = useState(false);
  const [isPresenterOpen, setIsPresenterOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [celebrationsEnabled, setCelebrationsEnabled] = useState(true);
  const [isPricingOpen, setIsPricingOpen] = useState(false);

  useEffect(() => {
    if (historyRecords && historyRecords.length > 0) {
      setAsyncHistory(prev => {
        if (
          prev.length === historyRecords.length &&
          prev.every((rec, i) => rec.id === historyRecords[i]?.id)
        ) {
          return prev;
        }
        return historyRecords;
      });
    }
  }, [historyRecords]);

  useEffect(() => {
    if (questions && questions.length > 0) {
      setAsyncQuestions(prev => {
        if (
          prev.length === questions.length &&
          prev.every((q, i) => q.id === questions[i]?.id)
        ) {
          return prev;
        }
        return questions;
      });
    }
  }, [questions]);

  // Load widgets like 'Recent History' and 'Analytics' asynchronously using Promise.all(),
  // allowing the host dashboard interface to render immediately upon authentication
  useEffect(() => {
    let isMounted = true;
    const loadWidgetsAsync = async () => {
      setIsWidgetLoading(true);
      try {
        const [histData, analyticsData, qsData] = await Promise.all([
          fetchGameResultsFromSupabase(),
          fetchAnalyticsFromSupabase(),
          fetchQuestionsFromSupabase()
        ]);

        if (isMounted) {
          if (histData && histData.length > 0) {
            setAsyncHistory(histData);
          }
          if (analyticsData) {
            setAsyncAnalytics(analyticsData);
          }
          if (qsData && qsData.length > 0) {
            setAsyncQuestions(qsData);
          }
        }
      } catch (e) {
        console.warn('Async widget query notice:', e);
      } finally {
        if (isMounted) {
          setIsWidgetLoading(false);
        }
      }
    };

    loadWidgetsAsync();

    return () => {
      isMounted = false;
    };
  }, []);

  const safeQuestions = questions || [];
  const safeCategories = categories || [];
  const safeHistoryRecords = asyncHistory.length > 0 ? asyncHistory : historyRecords || [];

  const { user, profile, updateHostProfile, signOutHost } = useAuth();

  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');

  // Profile Form state
  const [profFullName, setProfFullName] = useState(profile?.full_name || user?.user_metadata?.full_name || '');
  const [profPhone, setProfPhone] = useState(profile?.phone || user?.user_metadata?.phone || '');
  const [profLocation, setProfLocation] = useState(profile?.location || user?.user_metadata?.location || '');
  const [profIndustry, setProfIndustry] = useState(profile?.industry || user?.user_metadata?.industry || '');
  const [profCompany, setProfCompany] = useState(profile?.company || '');
  const [profJobTitle, setProfJobTitle] = useState(profile?.job_title || '');
  const [profTimezone, setProfTimezone] = useState(profile?.timezone || 'UTC');

  const [profileSaving, setProfileSaving] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Dynamic Activity Feed derived from real history and question bank state
  const dynamicActivityFeed = [
    ...(safeHistoryRecords.slice(0, 3).map((rec, idx) => ({
      id: `hist_${rec.id || idx}`,
      action: `Hosted "${rec.title}" Live Session (${rec.totalParticipants} players)`,
      time: rec.date || 'Recent',
      icon: Radio
    }))),
    { 
      id: 'qb_stats', 
      action: `Question Bank active with ${safeQuestions.length} questions across ${safeCategories.length} categories`, 
      time: 'Current', 
      icon: Database 
    },
    { 
      id: 'security_sync', 
      action: 'Supabase Realtime & Cloud Storage synced', 
      time: 'Live', 
      icon: CheckCircle2 
    }
  ];

  // Quiz sessions tab filter
  const [sessionTabFilter, setSessionTabFilter] = useState<'all' | 'active' | 'completed'>('all');

  // Stats calculation
  const totalQuestions = safeQuestions.length;
  const totalQuestionBanks = safeCategories.length;
  const totalQuizSessions = safeHistoryRecords.length + (activeSession ? 1 : 0);
  const totalParticipants = safeHistoryRecords.reduce((acc, curr) => acc + (curr.totalParticipants || 0), 0) + 
    (activeSession ? Object.keys(activeSession.participants || {}).length : 0);
  const gamesHosted = safeHistoryRecords.length;

  // Real aggregate accuracy strictly bounded between 0% and 100%
  let totalCorrectAcrossHistory = 0;
  let totalAnsweredAcrossHistory = 0;

  safeHistoryRecords.forEach(rec => {
    if (rec.fullSession) {
      const summary = calculateSessionSummary(rec.fullSession);
      totalCorrectAcrossHistory += Math.round((summary.averageAccuracy / 100) * (summary.totalParticipants * summary.totalQuestions));
      totalAnsweredAcrossHistory += summary.totalParticipants * summary.totalQuestions;
    } else if (rec.participants && rec.participants.length > 0) {
      rec.participants.forEach(p => {
        totalCorrectAcrossHistory += (p.correctCount || 0);
        const pAns = p.answers ? Object.keys(p.answers).length : (rec.totalQuestions || 10);
        totalAnsweredAcrossHistory += (pAns || 10);
      });
    }
  });

  const overallAvgAccuracy = totalAnsweredAcrossHistory > 0
    ? Math.min(100, Math.max(0, Math.round((totalCorrectAcrossHistory / totalAnsweredAcrossHistory) * 100)))
    : (safeHistoryRecords.length > 0
        ? Math.min(100, Math.max(0, Math.round(safeHistoryRecords.reduce((acc, curr) => acc + Math.min(100, Math.max(0, curr.averageAccuracy || 0)), 0) / safeHistoryRecords.length)))
        : (asyncAnalytics?.avgPlatformAccuracy ? Math.min(100, Math.max(0, asyncAnalytics.avgPlatformAccuracy)) : 0));

  const avgPointsScore = safeHistoryRecords.length > 0
    ? Math.round(safeHistoryRecords.reduce((acc, curr) => acc + (curr.averageScore || 0), 0) / safeHistoryRecords.length)
    : (asyncAnalytics?.avgPlatformScore || 0);

  const activeSessionsCount = activeSession ? 1 : 0;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    setProfileMsg(null);

    const res = await updateHostProfile({
      full_name: profFullName,
      phone: profPhone,
      location: profLocation,
      industry: profIndustry,
      company: profCompany,
      job_title: profJobTitle,
      timezone: profTimezone
    });

    setProfileSaving(false);

    if (res.success) {
      setProfileMsg({ text: 'Profile updated successfully!', type: 'success' });
    } else {
      setProfileMsg({ text: res.error || 'Failed to update profile.', type: 'error' });
    }
  };

  const navItems = [
    { id: 'host_dashboard' as Role, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'host_questions' as Role, label: 'Question Banks', icon: Database },
    { id: 'host_categories' as Role, label: 'Categories', icon: FolderPlus },
    { id: 'host_quizzes' as Role, label: 'Quiz Sessions', icon: Radio },
    { id: 'host_payments' as Role, label: 'Billing & Payments', icon: CreditCard },
    { id: 'host_participants' as Role, label: 'Participants', icon: Users },
    { id: 'host_analytics' as Role, label: 'Analytics', icon: BarChart3 },
    { id: 'host_history' as Role, label: 'History', icon: History },
    { id: 'host_profile' as Role, label: 'Profile', icon: User },
    { id: 'host_settings' as Role, label: 'Settings', icon: Settings },
  ];

  const [localMobileDrawerOpen, setLocalMobileDrawerOpen] = useState(false);
  const showMobileDrawer = isMobileDrawerOpen !== undefined ? isMobileDrawerOpen : localMobileDrawerOpen;
  const handleCloseDrawer = () => {
    if (onCloseMobileDrawer) onCloseMobileDrawer();
    setLocalMobileDrawerOpen(false);
  };

  return (
    <div className="w-full h-full flex flex-row overflow-hidden relative bg-slate-950 text-white min-h-0">

      {/* Desktop Fixed Sidebar Navigation (>= md: 260px wide, fixed height, scrollable) */}
      <aside className="hidden md:flex md:w-[260px] min-w-[260px] max-w-[260px] bg-slate-900 border-r border-slate-800 p-4 flex-col justify-between flex-shrink-0 h-full overflow-y-auto overflow-x-hidden">
        <div className="space-y-6">
          
          {/* Host Welcome Badge */}
          <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-yellow-400 text-slate-950 flex items-center justify-center font-black text-lg shadow-md flex-shrink-0">
              {(profile?.full_name || 'H')[0].toUpperCase()}
            </div>
            <div className="overflow-hidden min-w-0">
              <span className="text-xs text-yellow-400 font-bold uppercase tracking-wider block">Host Workspace</span>
              <h3 className="text-sm font-extrabold text-white truncate">{profile?.full_name || 'Authenticated Host'}</h3>
              <p className="text-[11px] text-slate-400 truncate">{profile?.email || user?.email}</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-extrabold transition-all ${
                    isActive
                      ? 'bg-yellow-400 text-slate-950 shadow-lg shadow-yellow-400/10'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick Action & Logout */}
        <div className="pt-6 border-t border-slate-800 space-y-2">
          <button
            onClick={() => setIsWizardOpen(true)}
            className="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-2xl shadow-md flex items-center justify-center space-x-2 transition-transform active:scale-98"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create Quiz</span>
          </button>

          <button
            onClick={signOutHost}
            className="w-full py-2.5 bg-slate-950 hover:bg-rose-950/50 text-slate-400 hover:text-rose-400 font-bold text-xs rounded-2xl border border-slate-800 flex items-center justify-center space-x-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout Workspace</span>
          </button>
        </div>
      </aside>

      {/* Slide-out Mobile Navigation Drawer (< md) */}
      {showMobileDrawer && (
        <div className="fixed inset-0 z-50 md:hidden flex justify-end">
          <div 
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
            onClick={handleCloseDrawer}
          />

          <div className="relative w-[280px] max-w-[85vw] bg-slate-900 border-l border-slate-800 h-full p-4 flex flex-col justify-between overflow-y-auto z-10 shadow-2xl">
            <div className="space-y-5">
              {/* Drawer Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-yellow-400" />
                  <span className="text-xs font-black text-white uppercase tracking-wider">Host Workspace</span>
                </div>
                <button
                  onClick={handleCloseDrawer}
                  className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
                  title="Close Menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Host Identity Badge */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-yellow-400 text-slate-950 flex items-center justify-center font-black text-sm shadow-md flex-shrink-0">
                  {(profile?.full_name || 'H')[0].toUpperCase()}
                </div>
                <div className="overflow-hidden min-w-0">
                  <h3 className="text-xs font-extrabold text-white truncate">{profile?.full_name || 'Authenticated Host'}</h3>
                  <p className="text-[10px] text-slate-400 truncate">{profile?.email || user?.email}</p>
                </div>
              </div>

              {/* Drawer Links */}
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 font-extrabold uppercase tracking-widest px-2 block mb-1">Navigation</span>
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.id);
                        handleCloseDrawer();
                      }}
                      className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-extrabold transition-all ${
                        isActive
                          ? 'bg-yellow-400 text-slate-950 shadow-md'
                          : 'text-slate-300 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick Actions & Logout */}
            <div className="pt-4 border-t border-slate-800 space-y-2 mt-4">
              <button
                onClick={() => {
                  setIsWizardOpen(true);
                  handleCloseDrawer();
                }}
                className="w-full py-2.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 transition-transform active:scale-98"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Create Quiz</span>
              </button>

              <button
                onClick={() => {
                  signOutHost();
                  handleCloseDrawer();
                }}
                className="w-full py-2.5 bg-slate-950 hover:bg-rose-950/50 text-slate-400 hover:text-rose-400 font-bold text-xs rounded-xl border border-slate-800 flex items-center justify-center space-x-2 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout Workspace</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Workspace View (Independently scrollable) */}
      <main className="flex-1 min-w-0 min-h-0 h-full overflow-y-auto overflow-x-hidden">
        <div className="w-full max-w-[1400px] mx-auto p-4 sm:p-6 md:p-8 min-w-0 pb-20 md:pb-8 space-y-8">
        
        {/* TAB 1: DASHBOARD OVERVIEW */}
        {currentTab === 'host_dashboard' && (
          <div className="space-y-8">
            
            {/* Top Banner */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-yellow-400/10 rounded-full blur-3xl pointer-events-none" />
              
              <div className="space-y-2">
                <span className="px-3 py-1 bg-yellow-400/10 text-yellow-400 text-xs font-black uppercase tracking-widest rounded-full border border-yellow-400/30">
                  Host Command Center
                </span>
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  Welcome Back, {profile?.full_name || 'Host'}
                </h1>
                <p className="text-xs sm:text-sm text-slate-400 font-semibold">
                  Manage your question banks, launch live sessions, and track participant metrics in real time.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => setIsPricingOpen(true)}
                  className="py-3.5 px-5 bg-slate-800 hover:bg-slate-700 text-yellow-400 font-bold text-xs rounded-2xl border border-yellow-400/30 flex items-center space-x-2 transition-colors"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>PAYG PRICING</span>
                </button>

                <button
                  onClick={() => setIsWizardOpen(true)}
                  className="py-3.5 px-6 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-2xl shadow-xl shadow-yellow-400/20 flex items-center space-x-2"
                >
                  <Zap className="w-4 h-4 fill-current" />
                  <span>START NEW QUIZ</span>
                </button>
              </div>
            </div>

            {/* Active Session Alert if currently hosting */}
            {activeSession && (
              <div className="bg-emerald-950/80 border-2 border-emerald-400/60 rounded-3xl p-6 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-400 text-slate-950 flex items-center justify-center font-black animate-pulse shadow-lg">
                    <Radio className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs font-black text-emerald-400 uppercase tracking-widest block">Live Session Running</span>
                    <h3 className="text-xl font-black text-white">{activeSession.title}</h3>
                    <p className="text-xs text-slate-300 font-mono">Join Code: <strong className="text-yellow-400">{activeSession.id}</strong></p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => setIsPresenterOpen(true)}
                    className="py-3 px-5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center space-x-2"
                  >
                    <span>📺 PRESENTER MODE</span>
                  </button>

                  <button
                    onClick={() => onOpenSession(activeSession.id)}
                    className="py-3 px-5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center space-x-2"
                  >
                    <span>RESUME CONTROL</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* HOST ONBOARDING CHECKLIST */}
            <HostOnboardingChecklist
              questionsCount={safeQuestions.length}
              categoriesCount={safeCategories.length}
              onNavigate={(v) => onSelectTab(v as Role)}
              onCreateRoomClick={() => setIsWizardOpen(true)}
            />

            {/* Contextual Host Pro Tip */}
            <HostQuickTip
              tipId="dashboard_welcome"
              category="Command Center"
              tipText="Start by populating your Question Bank or launching a quick room. You can open Presenter Mode for live screens and TV displays!"
            />

            {/* Summary KPI Cards Grid (Mobile 1, Tablet 2, Desktop 4) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-lg">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Question Banks</span>
                <p className="text-2xl sm:text-3xl font-black text-yellow-400">{totalQuestionBanks}</p>
                <p className="text-[11px] text-slate-500 font-semibold">{totalQuestions} total questions</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-lg">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Questions</span>
                <p className="text-2xl sm:text-3xl font-black text-white">{totalQuestions}</p>
                <p className="text-[11px] text-slate-500 font-semibold">across {safeCategories.length} categories</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-lg">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Quiz Sessions</span>
                <p className="text-2xl sm:text-3xl font-black text-emerald-400">{totalQuizSessions}</p>
                <p className="text-[11px] text-slate-500 font-semibold">{gamesHosted} hosted games</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-lg">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Participants</span>
                <p className="text-2xl sm:text-3xl font-black text-amber-300">{totalParticipants}</p>
                <p className="text-[11px] text-slate-500 font-semibold">{overallAvgAccuracy}% avg accuracy</p>
              </div>
            </div>

            {/* Quick Actions Buttons Row */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h2 className="text-lg font-black text-white flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-yellow-400" />
                <span>Quick Actions</span>
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <button
                  onClick={() => setIsWizardOpen(true)}
                  className="p-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-yellow-400/50 rounded-2xl text-center space-y-2 transition-all group"
                >
                  <PlusCircle className="w-6 h-6 text-yellow-400 mx-auto group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-extrabold text-white block">Create New Quiz</span>
                </button>

                <button
                  onClick={() => onSelectTab('host_questions')}
                  className="p-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-yellow-400/50 rounded-2xl text-center space-y-2 transition-all group"
                >
                  <FileSpreadsheet className="w-6 h-6 text-emerald-400 mx-auto group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-extrabold text-white block">Import Questions</span>
                </button>

                <button
                  onClick={() => onSelectTab('host_categories')}
                  className="p-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-yellow-400/50 rounded-2xl text-center space-y-2 transition-all group"
                >
                  <FolderPlus className="w-6 h-6 text-amber-300 mx-auto group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-extrabold text-white block">Create Category</span>
                </button>

                <button
                  onClick={() => onSelectTab('host_questions')}
                  className="p-4 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-yellow-400/50 rounded-2xl text-center space-y-2 transition-all group"
                >
                  <Database className="w-6 h-6 text-cyan-400 mx-auto group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-extrabold text-white block">Create Question</span>
                </button>

                <button
                  onClick={() => setIsWizardOpen(true)}
                  className="p-4 bg-yellow-400/10 hover:bg-yellow-400/20 border border-yellow-400/30 rounded-2xl text-center space-y-2 transition-all group col-span-2 sm:col-span-1"
                >
                  <Radio className="w-6 h-6 text-yellow-400 mx-auto group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-black text-yellow-400 block">Start Live Quiz</span>
                </button>
              </div>
            </div>

            {/* Widgets Section: Recent Sessions & Question Banks & Activity Feed */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Recent Quiz Sessions Widget */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-black text-white flex items-center space-x-2">
                    <Radio className="w-5 h-5 text-yellow-400" />
                    <span>Recent Quiz Sessions</span>
                  </h3>
                  <button
                    onClick={() => onSelectTab('host_history')}
                    className="text-xs text-yellow-400 font-bold hover:underline"
                  >
                    View All
                  </button>
                </div>

                {safeHistoryRecords.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800 text-slate-400 text-xs">
                    No hosted games recorded yet. Launch your first live quiz to see session reports!
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                          <th className="py-2.5 px-3">Quiz Name</th>
                          <th className="py-2.5 px-3">Date</th>
                          <th className="py-2.5 px-3">Participants</th>
                          <th className="py-2.5 px-3">Winner</th>
                          <th className="py-2.5 px-3">Avg Score</th>
                          <th className="py-2.5 px-3 text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 font-semibold">
                        {safeHistoryRecords.slice(0, 5).map((rec, idx) => (
                          <tr key={rec.id ? `${rec.id}-${idx}` : `rec-${idx}`} className="hover:bg-slate-800/50">
                            <td className="py-3 px-3 font-extrabold text-white">{rec.title}</td>
                            <td className="py-3 px-3 text-slate-400">{rec.date}</td>
                            <td className="py-3 px-3 text-slate-300">{rec.totalParticipants}</td>
                            <td className="py-3 px-3 text-amber-300">{rec.winnerName}</td>
                            <td className="py-3 px-3 text-emerald-400">{rec.averageScore} pts</td>
                            <td className="py-3 px-3 text-right">
                              <span className="px-2 py-0.5 bg-emerald-400/10 text-emerald-400 border border-emerald-400/30 rounded-full text-[10px] font-black">
                                Completed
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Activity Feed Widget */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                <h3 className="text-base font-black text-white flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-yellow-400" />
                  <span>Recent Activity Feed</span>
                </h3>

                <div className="space-y-3">
                  {dynamicActivityFeed.map((act) => {
                    const Icon = act.icon;
                    return (
                      <div key={act.id} className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-start space-x-3">
                        <div className="p-2 bg-yellow-400/10 text-yellow-400 rounded-xl flex-shrink-0 mt-0.5">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-bold text-slate-200">{act.action}</p>
                          <span className="text-[10px] text-slate-500 font-semibold">{act.time}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: QUESTION BANKS */}
        {currentTab === 'host_questions' && (
          <QuestionBank
            questions={questions}
            categories={categories}
            onAddCategory={onCreateCategory}
            onRenameCategory={onRenameCategory || ((oldName, newName) => {})}
            onDeleteCategory={onDeleteCategory}
            onAddQuestion={onCreateQuestion}
            onUpdateQuestion={onUpdateQuestion}
            onDeleteQuestion={onDeleteQuestion}
            onBulkDeleteQuestions={onBulkDeleteQuestions || ((ids) => ids.forEach(id => onDeleteQuestion(id)))}
            onMoveQuestionsCategory={onMoveQuestionsCategory || ((ids, cat) => {})}
            onImportQuestions={onBulkImport}
            onCreateSession={onCreateSession}
          />
        )}

        {/* TAB 3: CATEGORIES */}
        {currentTab === 'host_categories' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
              <h2 className="text-xl font-black text-white flex items-center space-x-2">
                <FolderPlus className="w-6 h-6 text-yellow-400" />
                <span>Manage Categories</span>
              </h2>
              <p className="text-xs text-slate-400">
                Organize your question banks into domain-specific categories.
              </p>

              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  if (newCatName.trim()) {
                    onCreateCategory(newCatName.trim());
                    setNewCatName('');
                  }
                }}
                className="flex items-center space-x-3 max-w-md pt-2"
              >
                <input
                  type="text"
                  placeholder="New Category Name..."
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white placeholder-slate-600 focus:outline-none"
                />
                <button
                  type="submit"
                  className="py-3 px-6 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-2xl transition-all"
                >
                  Add Category
                </button>
              </form>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {safeCategories.map((cat, idx) => {
                const count = safeQuestions.filter(q => q.category === cat).length;

                return (
                  <div key={`${cat}-${idx}`} className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex items-center justify-between">
                    <div>
                      <h4 className="font-extrabold text-white text-sm">{cat}</h4>
                      <p className="text-xs text-slate-400">{count} Questions</p>
                    </div>

                    <button
                      onClick={() => onDeleteCategory(cat)}
                      className="p-2 text-slate-500 hover:text-rose-400 transition-colors"
                      title="Delete Category"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: QUIZ SESSIONS */}
        {currentTab === 'host_quizzes' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6">
              <div>
                <h2 className="text-xl font-black text-white flex items-center space-x-2">
                  <Radio className="w-6 h-6 text-yellow-400" />
                  <span>Host Quiz Sessions</span>
                </h2>
                <p className="text-xs text-slate-400">View live active sessions, upcoming events, and past completed quizzes.</p>
              </div>

              <button
                onClick={() => setIsWizardOpen(true)}
                className="py-3 px-6 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-2xl shadow-lg flex items-center space-x-2"
              >
                <PlusCircle className="w-4 h-4" />
                <span>NEW QUIZ SESSION</span>
              </button>
            </div>

            {/* Filter Tabs */}
            <div className="flex space-x-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 w-fit text-xs font-bold">
              <button
                onClick={() => setSessionTabFilter('all')}
                className={`px-4 py-2 rounded-xl transition-all ${sessionTabFilter === 'all' ? 'bg-yellow-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
              >
                All Sessions
              </button>
              <button
                onClick={() => setSessionTabFilter('active')}
                className={`px-4 py-2 rounded-xl transition-all ${sessionTabFilter === 'active' ? 'bg-yellow-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
              >
                Active Room
              </button>
              <button
                onClick={() => setSessionTabFilter('completed')}
                className={`px-4 py-2 rounded-xl transition-all ${sessionTabFilter === 'completed' ? 'bg-yellow-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
              >
                Completed History
              </button>
            </div>

            {/* Content List */}
            {activeSession && (sessionTabFilter === 'all' || sessionTabFilter === 'active') && (
              <div className="p-6 bg-emerald-950/80 border-2 border-emerald-400/60 rounded-3xl flex items-center justify-between">
                <div>
                  <span className="px-3 py-1 bg-emerald-400/20 text-emerald-400 text-xs font-black uppercase rounded-full">Active Session</span>
                  <h3 className="text-xl font-black text-white mt-1">{activeSession.title}</h3>
                  <p className="text-xs text-slate-300 font-mono">Code: {activeSession.id} • {Object.keys(activeSession.participants || {}).length} Players</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onOpenSession(activeSession.id)}
                    className="py-2.5 px-5 bg-yellow-400 text-slate-950 font-black text-xs rounded-xl shadow-md"
                  >
                    Open Presenter Room
                  </button>
                </div>
              </div>
            )}

            {safeHistoryRecords.length > 0 && (sessionTabFilter === 'all' || sessionTabFilter === 'completed') && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {safeHistoryRecords.map((rec, idx) => (
                  <div key={rec.id ? `${rec.id}-${idx}` : `hist-${idx}`} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-400">{rec.date}</span>
                      <span className="px-2.5 py-0.5 bg-slate-800 text-slate-300 rounded-full text-[10px] font-black uppercase">
                        Completed
                      </span>
                    </div>

                    <div>
                      <h4 className="text-base font-black text-white">{rec.title}</h4>
                      <p className="text-xs text-slate-400 font-semibold mt-1">
                        Winner: <strong className="text-amber-300">{rec.winnerName}</strong> ({rec.winnerScore} pts)
                      </p>
                    </div>

                    <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-xs">
                      <span className="text-slate-400 font-bold">{rec.totalParticipants} Participants</span>
                      
                      <button
                        onClick={() => {
                          const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(rec, null, 2));
                          const anchor = document.createElement('a');
                          anchor.setAttribute("href", dataStr);
                          anchor.setAttribute("download", `${rec.title.replace(/\s+/g, '_')}_results.json`);
                          document.body.appendChild(anchor);
                          anchor.click();
                          anchor.remove();
                        }}
                        className="text-yellow-400 hover:underline font-extrabold flex items-center space-x-1"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Export Results</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: PARTICIPANTS */}
        {currentTab === 'host_participants' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
            <h2 className="text-xl font-black text-white flex items-center space-x-2">
              <Users className="w-6 h-6 text-yellow-400" />
              <span>Host Participant Analytics</span>
            </h2>
            <p className="text-xs text-slate-400">
              Overview of all participants across hosted quiz sessions.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400">Total Joined Participants</span>
                <p className="text-2xl font-black text-yellow-400">{totalParticipants}</p>
              </div>

              <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400">Average Score</span>
                <p className="text-2xl font-black text-emerald-400">{avgPointsScore} Points</p>
              </div>

              <div className="p-5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400">Active Live Room</span>
                <p className="text-2xl font-black text-amber-300">
                  {activeSession ? Object.keys(activeSession.participants || {}).length : 0} Connected
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: ANALYTICS */}
        {currentTab === 'host_analytics' && (
          <AnalyticsDashboard historyRecords={safeHistoryRecords} questions={safeQuestions} analyticsData={asyncAnalytics} />
        )}

        {/* TAB 7: HISTORY */}
        {currentTab === 'host_history' && (
          <GameHistoryView
            records={safeHistoryRecords}
            onDeleteRecord={onDeleteHistoryRecord}
          />
        )}

        {/* TAB 8: HOST PROFILE */}
        {currentTab === 'host_profile' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 max-w-3xl mx-auto space-y-8">
            <div className="flex items-center space-x-3 text-yellow-400">
              <User className="w-8 h-8" />
              <div>
                <h2 className="text-2xl font-black text-white">Host Profile Settings</h2>
                <p className="text-xs text-slate-400 font-semibold">Update your host information. Synced directly with Supabase.</p>
              </div>
            </div>

            {profileMsg && (
              <div className={`p-4 rounded-2xl border text-xs font-bold flex items-center space-x-2 ${
                profileMsg.type === 'success' 
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
              }`}>
                {profileMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                <span>{profileMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Full Name */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Full Name</label>
                  <input
                    type="text"
                    value={profFullName}
                    onChange={(e) => setProfFullName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

                {/* Email (Readonly) */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Email Address</label>
                  <input
                    type="email"
                    disabled
                    value={profile?.email || user?.email || ''}
                    className="w-full bg-slate-950/60 border border-slate-800/60 rounded-2xl py-3 px-4 text-xs font-bold text-slate-500 cursor-not-allowed"
                  />
                </div>

                {/* Phone */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Phone Number</label>
                  <input
                    type="tel"
                    value={profPhone}
                    onChange={(e) => setProfPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

                {/* Location */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Location / Country</label>
                  <input
                    type="text"
                    value={profLocation}
                    onChange={(e) => setProfLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

                {/* Industry */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Industry</label>
                  <input
                    type="text"
                    value={profIndustry}
                    onChange={(e) => setProfIndustry(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

                {/* Company */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Company / Organization</label>
                  <input
                    type="text"
                    value={profCompany}
                    onChange={(e) => setProfCompany(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

                {/* Job Title */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Job Title</label>
                  <input
                    type="text"
                    value={profJobTitle}
                    onChange={(e) => setProfJobTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

                {/* Timezone */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Timezone</label>
                  <input
                    type="text"
                    value={profTimezone}
                    onChange={(e) => setProfTimezone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-2xl py-3 px-4 text-xs font-bold text-white focus:outline-none"
                  />
                </div>

              </div>

              <button
                type="submit"
                disabled={profileSaving}
                className="py-3.5 px-8 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-2xl shadow-xl transition-all disabled:opacity-50"
              >
                {profileSaving ? 'Saving Updates...' : 'SAVE PROFILE CHANGES'}
              </button>
            </form>
          </div>
        )}

        {/* TAB 8: BILLING & PAYMENTS */}
        {currentTab === 'host_payments' && (
          <PaymentHistoryView
            hostId={user?.id || profile?.id || 'host_default'}
            onOpenPricing={() => setIsPricingOpen(true)}
          />
        )}

        {/* TAB 9: SETTINGS */}
        {currentTab === 'host_settings' && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-3xl mx-auto space-y-6">
            <h2 className="text-xl font-black text-white flex items-center space-x-2">
              <Settings className="w-6 h-6 text-yellow-400" />
              <span>Workspace Preferences</span>
            </h2>

            <div className="space-y-4 text-xs font-semibold">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Default Question Timer</span>
                  <span className="text-slate-400">Default countdown duration when creating new quizzes</span>
                </div>
                <span className="px-3 py-1 bg-yellow-400/20 text-yellow-400 font-bold rounded-xl">20 Seconds</span>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Enable Sound Effects</span>
                  <span className="text-slate-400">Play countdown ticks and leaderboard fanfare</span>
                </div>
                <span className="px-3 py-1 bg-emerald-400/20 text-emerald-400 font-bold rounded-xl">Enabled</span>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Supabase Sync</span>
                  <span className="text-slate-400">Realtime database synchronization status</span>
                </div>
                <span className="px-3 py-1 bg-emerald-400/20 text-emerald-400 font-bold rounded-xl">Connected</span>
              </div>
            </div>
          </div>
        )}

        </div>
      </main>

      {/* Fixed Mobile Bottom Navigation Bar (< md) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-slate-900/95 backdrop-blur-md border-t border-slate-800 py-2 px-3 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => onSelectTab('host_dashboard')}
          className={`flex flex-col items-center justify-center space-y-1 py-1.5 px-3 rounded-xl transition-all ${
            currentTab === 'host_dashboard'
              ? 'text-yellow-400 font-black'
              : 'text-slate-400 hover:text-slate-200 font-bold'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Dashboard</span>
        </button>

        <button
          onClick={() => onSelectTab('host_questions')}
          className={`flex flex-col items-center justify-center space-y-1 py-1.5 px-3 rounded-xl transition-all ${
            currentTab === 'host_questions'
              ? 'text-yellow-400 font-black'
              : 'text-slate-400 hover:text-slate-200 font-bold'
          }`}
        >
          <Database className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Questions</span>
        </button>

        <button
          onClick={() => onSelectTab('host_quizzes')}
          className={`flex flex-col items-center justify-center space-y-1 py-1.5 px-3 rounded-xl transition-all ${
            currentTab === 'host_quizzes'
              ? 'text-yellow-400 font-black'
              : 'text-slate-400 hover:text-slate-200 font-bold'
          }`}
        >
          <Radio className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Sessions</span>
        </button>

        <button
          onClick={() => setLocalMobileDrawerOpen(true)}
          className={`flex flex-col items-center justify-center space-y-1 py-1.5 px-3 rounded-xl transition-all ${
            ['host_categories', 'host_payments', 'host_participants', 'host_analytics', 'host_history', 'host_profile', 'host_settings'].includes(currentTab)
              ? 'text-yellow-400 font-black'
              : 'text-slate-400 hover:text-slate-200 font-bold'
          }`}
        >
          <Sliders className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">More</span>
        </button>
      </nav>

      {/* Creation Wizard Modal */}
      <QuizCreationWizardModal
        isOpen={isWizardOpen}
        onClose={() => setIsWizardOpen(false)}
        onCreateSession={(title, settings, selectedQIds) => {
          onCreateSession(title, settings, selectedQIds);
          setIsWizardOpen(false);
        }}
        availableCategories={categories}
        allQuestions={questions}
      />

      {/* Pay-As-You-Go Pricing Modal */}
      <PricingModal
        isOpen={isPricingOpen}
        onClose={() => setIsPricingOpen(false)}
        onSelectTier={(tier) => {
          setIsPricingOpen(false);
          setIsWizardOpen(true);
        }}
      />

      {/* Dedicated Presenter Mode View */}
      {isPresenterOpen && activeSession && (
        <PresenterModeView
          session={activeSession}
          isHost={true}
          onExitPresenter={() => setIsPresenterOpen(false)}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled(prev => !prev)}
          celebrationsEnabled={celebrationsEnabled}
          onToggleCelebrations={() => setCelebrationsEnabled(prev => !prev)}
        />
      )}

    </div>
  );
};
