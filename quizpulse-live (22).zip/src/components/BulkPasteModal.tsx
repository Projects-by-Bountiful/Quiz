import React, { useState } from 'react';
import { FileText, Check, AlertTriangle, Sparkles, X, ArrowRight, RefreshCw, CheckCircle2, XCircle, AlertCircle, HelpCircle, Layers, Zap, ListOrdered, ArrowRightLeft } from 'lucide-react';
import { Question, Category, Difficulty, QuestionType, FastestFingerFormat, FASTEST_FINGER_FORMAT_LABELS } from '../types';
import { parseBulkQuestions, ParsedQuestionItem } from '../utils/bulkParser';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';

interface BulkPasteModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  defaultCategory?: Category;
  onQuestionsImported: (questions: Question[]) => void;
}

const FASTEST_FINGERS_TEMPLATES: Record<FastestFingerFormat, string> = {
  true_false: `QUESTION: A freelancer should establish written agreements before beginning major project work.
A: TRUE
B: FALSE
ANSWER: A
EXPLANATION: Written agreements clarify scope, milestones, deliverables, and payment obligations.

===

QUESTION: Clarifying project deliverables and deadlines beforehand is unnecessary.
A: TRUE
B: FALSE
ANSWER: B
EXPLANATION: Pre-aligning deliverables and milestones prevents misunderstandings and scope creep.`,

  yes_no: `QUESTION: Can an independent consultant maintain active contracts with multiple clients?
A: YES
B: NO
ANSWER: A
EXPLANATION: Independent consultants operate autonomous businesses and can engage multiple concurrent clients.

===

QUESTION: Can a freelancer build multiple recurring revenue streams?
A: YES
B: NO
ANSWER: A
EXPLANATION: Freelancers frequently diversify income across retainers, productized services, and consulting.`,

  this_that: `QUESTION: Which approach provides greater long-term income predictability?
A: ONE-OFF AD-HOC GIGS
B: RECURRING CLIENT RETAINERS
ANSWER: B
EXPLANATION: Monthly retainers establish predictable recurring baseline revenue.

===

QUESTION: Which delivers higher strategic value to clients?
A: VALUE-BASED CONSULTING
B: RAW HOURLY TIME-TRACKING
ANSWER: A
EXPLANATION: Value-based pricing aligns compensation with client business outcomes.`,

  higher_lower: `QUESTION: Compared to general services, highly specialized technical domain expertise commands:
A: HIGHER MARKET RATES
B: LOWER MARKET RATES
ANSWER: A
EXPLANATION: Deep specialized domain expertise is scarce and commands premium market rates.

===

QUESTION: When client scope increases, the revised project budget should typically be:
A: HIGHER
B: LOWER
ANSWER: A
EXPLANATION: Increased scope requires proportional budget adjustment via change orders.`,

  more_less: `QUESTION: Clear asynchronous documentation and written briefs result in:
A: MORE PRODUCTIVE ASYNC ALIGNMENT
B: LESS TEAM CLARITY
ANSWER: A
EXPLANATION: High quality written documentation reduces back-and-forth ambiguity.`,

  before_after: `QUESTION: Clear payment terms, milestones, and invoice schedules should be locked in:
A: BEFORE COMMENCING WORK
B: AFTER COMPLETE DELIVERY
ANSWER: A
EXPLANATION: Commercial terms must always be finalized before labor commences.`,

  agree_disagree: `QUESTION: Maintaining a dedicated 3-to-6 month operational cash reserve is vital for business stability.
A: AGREE
B: DISAGREE
ANSWER: A
EXPLANATION: Financial reserves protect against seasonal fluctuations and delayed invoices.`,

  custom: `QUESTION: Which database paradigm is optimized for flexible JSON documents?
A: Document / NoSQL
B: Flat File Text
ANSWER: A
EXPLANATION: Document databases are specifically engineered for semi-structured JSON storage.`
};

const TEMPLATES_BY_TYPE: Record<QuestionType, string> = {
  multiple_choice: `QUESTION: Which language is responsible for styling a website?
A: HTML
B: JavaScript
C: CSS
D: SQL
ANSWER: C
EXPLANATION: CSS controls the appearance, layout, colors, and typography of web pages.

===

QUESTION: Which React hook handles side effects?
A: useState
B: useEffect
C: useMemo
D: useRef
ANSWER: B
EXPLANATION: useEffect handles side-effects like data fetching and subscriptions.`,

  fastest_fingers: FASTEST_FINGERS_TEMPLATES.true_false,

  fill_blank: `QUESTION: What is the capital city of France?
ANSWER: Paris, City of Light
EXPLANATION: Paris is the capital and most populous city of France.

===

QUESTION: Who wrote the play Romeo and Juliet?
ANSWER: William Shakespeare, Shakespeare
EXPLANATION: Written early in Shakespeare's career around 1595.`,

  ordering: `QUESTION: Order these computer storage units from smallest to largest
ITEMS:
1. Kilobyte (KB)
2. Megabyte (MB)
3. Gigabyte (GB)
4. Terabyte (TB)
EXPLANATION: 1 KB = 1024 Bytes, 1 MB = 1024 KB, 1 GB = 1024 MB, 1 TB = 1024 GB.

===

QUESTION: Arrange the planets in order of distance from the Sun (closest to farthest)
ITEMS:
1. Mercury
2. Venus
3. Earth
4. Mars
EXPLANATION: Terrestrial planets in order from the Sun.`,

  matching: `QUESTION: Match each country with its capital city
PAIRS:
Japan -> Tokyo
Australia -> Canberra
Canada -> Ottawa
Brazil -> Brasilia
EXPLANATION: Capital cities of four major nations.

===

QUESTION: Match the programming language with its primary paradigm
PAIRS:
Haskell -> Purely Functional
Rust -> Systems / Memory Safe
Python -> Multi-paradigm Scripting
SQL -> Declarative Querying
EXPLANATION: Core paradigms of popular languages.`
};

export const BulkPasteModal: React.FC<BulkPasteModalProps> = ({
  isOpen,
  onClose,
  categories,
  defaultCategory = 'General Knowledge',
  onQuestionsImported
}) => {
  const [selectedType, setSelectedType] = useState<QuestionType>('multiple_choice');
  const [ffFormat, setFfFormat] = useState<FastestFingerFormat>('true_false');
  const [pastedText, setPastedText] = useState(TEMPLATES_BY_TYPE.multiple_choice);
  const [targetCategory, setTargetCategory] = useState<Category>(defaultCategory);
  const [defaultDifficulty, setDefaultDifficulty] = useState<Difficulty>('Medium');
  const [parsedItems, setParsedItems] = useState<ParsedQuestionItem[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [hasParsed, setHasParsed] = useState(false);
  const [summary, setSummary] = useState<{ valid: number; review: number; invalid: number }>({
    valid: 0,
    review: 0,
    invalid: 0
  });

  if (!isOpen) return null;

  const handleTypeChange = (newType: QuestionType) => {
    setSelectedType(newType);
    if (!hasParsed || pastedText.trim() === '' || Object.values(TEMPLATES_BY_TYPE).includes(pastedText.trim()) || Object.values(FASTEST_FINGERS_TEMPLATES).includes(pastedText.trim())) {
      if (newType === 'fastest_fingers') {
        setPastedText(FASTEST_FINGERS_TEMPLATES[ffFormat]);
      } else {
        setPastedText(TEMPLATES_BY_TYPE[newType]);
      }
    }
  };

  const handleFfFormatChange = (newFormat: FastestFingerFormat) => {
    setFfFormat(newFormat);
    if (!hasParsed || Object.values(FASTEST_FINGERS_TEMPLATES).includes(pastedText.trim()) || Object.values(TEMPLATES_BY_TYPE).includes(pastedText.trim())) {
      setPastedText(FASTEST_FINGERS_TEMPLATES[newFormat]);
    }
  };

  const handleParse = () => {
    const res = parseBulkQuestions(pastedText, selectedType, targetCategory, defaultDifficulty, ffFormat);
    setParsedItems(res.items);

    // Auto-select valid and review items
    const importableIds = new Set(
      res.items.filter(i => i.status === 'VALID' || i.status === 'NEEDS_REVIEW').map(i => i.id)
    );
    setSelectedIds(importableIds);

    setSummary({
      valid: res.validCount,
      review: res.reviewCount,
      invalid: res.invalidCount
    });

    setHasParsed(true);
  };

  const handleToggleSelect = (id: string, status: string) => {
    if (status === 'INVALID') return;
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const handleSelectAllImportable = () => {
    const importableItems = parsedItems.filter(i => i.status !== 'INVALID');
    if (selectedIds.size === importableItems.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(importableItems.map(i => i.id)));
    }
  };

  const handleChangeCorrectAnswer = (id: string, newCorrectIdx: number) => {
    setParsedItems(prev =>
      prev.map(item => {
        if (item.id !== id) return item;

        const updatedStatus = item.status === 'NEEDS_REVIEW' ? 'VALID' : item.status;
        return {
          ...item,
          correctAnswer: newCorrectIdx,
          rawCorrectLetter: String.fromCharCode(65 + newCorrectIdx),
          status: updatedStatus,
          validationMessage: updatedStatus === 'VALID' ? undefined : item.validationMessage
        };
      })
    );

    setSelectedIds(prev => new Set([...Array.from(prev), id]));
  };

  const handleImport = () => {
    const selectedItems = parsedItems.filter(item => selectedIds.has(item.id) && item.status !== 'INVALID');

    const formattedQuestions: Question[] = selectedItems.map(item => {
      const qType = item.type || selectedType;
      
      let finalOptions: string[] = [];
      if (qType === 'fastest_fingers') {
        finalOptions = Array.isArray(item.options) ? item.options.slice(0, 2) : ['TRUE', 'FALSE'];
      } else if (qType === 'multiple_choice') {
        finalOptions = Array.isArray(item.options) ? item.options : [];
      }

      const q: Question = {
        id: `bulk_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        type: qType,
        fastestFingerFormat: qType === 'fastest_fingers' ? (item.fastestFingerFormat || ffFormat) : undefined,
        category: item.category || targetCategory,
        difficulty: item.difficulty || defaultDifficulty,
        question: item.questionText,
        options: finalOptions,
        correctAnswer: (item.correctAnswer ?? 0) as 0 | 1 | 2 | 3,
        explanation: item.explanation,
        tags: [item.category || targetCategory, item.difficulty || defaultDifficulty],
        estimatedTimeSec: qType === 'fastest_fingers' ? 10 : 20,
        status: 'active'
      };

      if (item.type === 'fill_blank') {
        q.acceptedAnswers = item.acceptedAnswers && item.acceptedAnswers.length > 0
          ? item.acceptedAnswers
          : [item.questionText];
      } else if (item.type === 'ordering') {
        q.orderItems = item.orderItems && item.orderItems.length > 0 ? item.orderItems : item.options;
      } else if (item.type === 'matching') {
        q.matchingPairs = item.matchingPairs || [];
      }

      return q;
    });

    if (formattedQuestions.length > 0) {
      onQuestionsImported(formattedQuestions);
      onClose();
      setPastedText('');
      setHasParsed(false);
    }
  };

  const badgeColor = getQuestionTypeBadgeColor(selectedType);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-5xl p-5 sm:p-8 shadow-2xl relative space-y-6 my-6">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-yellow-400/20">
            <FileText className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">Bulk Question Import & Multi-Type Parser</h2>
            <p className="text-xs text-slate-400 font-semibold">Select your question type, paste text blocks delimited by ===, and review validation before importing</p>
          </div>
        </div>

        {/* Question Type Selector & Category Config Bar */}
        <div className={`grid grid-cols-1 ${selectedType === 'fastest_fingers' ? 'sm:grid-cols-4' : 'sm:grid-cols-3'} gap-4 bg-slate-950/70 p-4 rounded-2xl border border-slate-800`}>
          
          {/* Question Type Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Question Type</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${badgeColor.bg} ${badgeColor.text} ${badgeColor.border}`}>
                {getQuestionTypeLabel(selectedType)}
              </span>
            </label>
            <select
              value={selectedType}
              onChange={(e) => handleTypeChange(e.target.value as QuestionType)}
              className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm font-bold focus:outline-none focus:border-yellow-400"
            >
              <option value="multiple_choice">Multiple Choice (4 Options)</option>
              <option value="fastest_fingers">Fastest Fingers (2 Options)</option>
              <option value="fill_blank">Fill in the Blank</option>
              <option value="ordering">Ordering / Ranking</option>
              <option value="matching">Matching Pairs</option>
            </select>
          </div>

          {/* Format selector for Fastest Fingers */}
          {selectedType === 'fastest_fingers' && (
            <div>
              <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Fastest Fingers Format</span>
                <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              </label>
              <select
                value={ffFormat}
                onChange={(e) => handleFfFormatChange(e.target.value as FastestFingerFormat)}
                className="w-full p-3 bg-slate-800 border border-amber-500/50 rounded-xl text-amber-200 text-sm font-bold focus:outline-none focus:border-amber-400"
              >
                <option value="true_false">True / False</option>
                <option value="yes_no">Yes / No</option>
                <option value="this_that">This / That</option>
                <option value="higher_lower">Higher / Lower</option>
                <option value="more_less">More / Less</option>
                <option value="before_after">Before / After</option>
                <option value="agree_disagree">Agree / Disagree</option>
                <option value="custom">Custom Two-Choice</option>
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Default Target Category
            </label>
            <select
              value={targetCategory}
              onChange={(e) => setTargetCategory(e.target.value)}
              className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm font-semibold focus:outline-none focus:border-yellow-400"
            >
              {categories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Default Difficulty
            </label>
            <select
              value={defaultDifficulty}
              onChange={(e) => setDefaultDifficulty(e.target.value as Difficulty)}
              className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm font-semibold focus:outline-none focus:border-yellow-400"
            >
              <option value="Easy">Easy (100 pts)</option>
              <option value="Medium">Medium (200 pts)</option>
              <option value="Hard">Hard (300 pts)</option>
            </select>
          </div>
        </div>

        {/* Paste Area or Preview List */}
        {!hasParsed ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Paste Questions ({selectedType === 'fastest_fingers' ? `Fastest Fingers • ${FASTEST_FINGER_FORMAT_LABELS[ffFormat]}` : getQuestionTypeLabel(selectedType)} Format)
              </span>
              <button
                type="button"
                onClick={() => {
                  if (selectedType === 'fastest_fingers') {
                    setPastedText(FASTEST_FINGERS_TEMPLATES[ffFormat]);
                  } else {
                    setPastedText(TEMPLATES_BY_TYPE[selectedType]);
                  }
                }}
                className="text-xs font-bold text-yellow-400 hover:underline flex items-center space-x-1"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Load Sample Template</span>
              </button>
            </div>

            <textarea
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder={`Paste your ${getQuestionTypeLabel(selectedType)} blocks here...`}
              rows={12}
              className="w-full p-4 bg-slate-950 border border-slate-800 rounded-2xl text-slate-200 font-mono text-xs sm:text-sm focus:outline-none focus:border-yellow-400 leading-relaxed resize-y"
            />

            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={onClose}
                className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase tracking-wider transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleParse}
                disabled={!pastedText.trim()}
                className="px-6 py-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 disabled:opacity-50 text-slate-950 text-xs font-black uppercase tracking-wider transition-all flex items-center space-x-2 shadow-lg shadow-yellow-400/20"
              >
                <span>Parse & Validate Questions</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Parser Results Summary Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1.5 text-xs font-bold text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{summary.valid} Valid</span>
                </span>
                {summary.review > 0 && (
                  <span className="flex items-center space-x-1.5 text-xs font-bold text-amber-400">
                    <AlertCircle className="w-4 h-4" />
                    <span>{summary.review} Needs Review</span>
                  </span>
                )}
                {summary.invalid > 0 && (
                  <span className="flex items-center space-x-1.5 text-xs font-bold text-rose-400">
                    <XCircle className="w-4 h-4" />
                    <span>{summary.invalid} Invalid</span>
                  </span>
                )}
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={handleSelectAllImportable}
                  className="text-xs font-bold text-yellow-400 hover:underline"
                >
                  {selectedIds.size === parsedItems.filter(i => i.status !== 'INVALID').length
                    ? 'Deselect All'
                    : 'Select All Importable'}
                </button>
                <button
                  onClick={() => setHasParsed(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center space-x-1"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Edit Source Text</span>
                </button>
              </div>
            </div>

            {/* List of Parsed Cards */}
            <div className="max-h-[50vh] overflow-y-auto space-y-4 pr-1">
              {parsedItems.map((item) => {
                const isSelected = selectedIds.has(item.id);
                const itemBadge = getQuestionTypeBadgeColor(item.type || selectedType);

                return (
                  <div
                    key={item.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      item.status === 'INVALID'
                        ? 'bg-rose-950/20 border-rose-800/40 opacity-75'
                        : isSelected
                        ? 'bg-slate-800/80 border-yellow-400/50 shadow-md'
                        : 'bg-slate-950/60 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        disabled={item.status === 'INVALID'}
                        onChange={() => handleToggleSelect(item.id, item.status)}
                        className="mt-1 w-4 h-4 rounded text-yellow-400 focus:ring-0 focus:ring-offset-0 bg-slate-800 border-slate-700 cursor-pointer disabled:cursor-not-allowed"
                      />

                      <div className="flex-1 space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                            Block #{item.blockNumber}
                          </span>
                          <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded border ${itemBadge.bg} ${itemBadge.text} ${itemBadge.border}`}>
                            {getQuestionTypeLabel(item.type || selectedType)}
                          </span>
                          {item.type === 'fastest_fingers' && item.fastestFingerFormat && (
                            <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-amber-400/15 text-amber-300 border border-amber-400/30">
                              {FASTEST_FINGER_FORMAT_LABELS[item.fastestFingerFormat]}
                            </span>
                          )}
                          <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-yellow-400/10 text-yellow-400 border border-yellow-400/20">
                            {item.category}
                          </span>
                          <span className="text-[10px] font-bold text-slate-400">
                            {item.difficulty}
                          </span>

                          {item.status === 'VALID' && (
                            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 flex items-center space-x-1 ml-auto">
                              <Check className="w-3 h-3" />
                              <span>Valid</span>
                            </span>
                          )}
                          {item.status === 'NEEDS_REVIEW' && (
                            <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 flex items-center space-x-1 ml-auto">
                              <AlertTriangle className="w-3 h-3" />
                              <span>Needs Review</span>
                            </span>
                          )}
                          {item.status === 'INVALID' && (
                            <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20 flex items-center space-x-1 ml-auto">
                              <X className="w-3 h-3" />
                              <span>Invalid</span>
                            </span>
                          )}
                        </div>

                        <p className="text-sm font-bold text-white leading-snug">
                          {item.questionText || <span className="text-rose-400 italic">No question text specified</span>}
                        </p>

                        {/* Options / Answer Preview */}
                        {(item.type === 'multiple_choice' || item.type === 'fastest_fingers') && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                            {(item.options as string[]).map((opt, optIdx) => {
                              const isCorrect = optIdx === item.correctAnswer;
                              return (
                                <div
                                  key={optIdx}
                                  onClick={() => handleChangeCorrectAnswer(item.id, optIdx)}
                                  className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                                    isCorrect
                                      ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300 font-bold'
                                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                                  }`}
                                >
                                  <span>{String.fromCharCode(65 + optIdx)}. {opt || <span className="text-rose-400 italic">Empty</span>}</span>
                                  {isCorrect && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {item.type === 'fill_blank' && (
                          <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs flex flex-wrap items-center gap-2">
                            <span className="text-slate-400 font-bold">Accepted Answer(s):</span>
                            {(item.acceptedAnswers || []).map((ans, i) => (
                              <span key={i} className="px-2.5 py-0.5 bg-emerald-500/15 border border-emerald-400/40 text-emerald-300 rounded font-bold">
                                "{ans}"
                              </span>
                            ))}
                          </div>
                        )}

                        {item.type === 'ordering' && (
                          <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs space-y-1">
                            <span className="text-cyan-400 font-bold block">Correct Sequence:</span>
                            <div className="flex flex-wrap gap-1.5">
                              {(item.orderItems || item.options || []).map((step, idx) => (
                                <span key={idx} className="px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 rounded font-bold">
                                  {idx + 1}. {step}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {item.type === 'matching' && (
                          <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs space-y-1">
                            <span className="text-purple-400 font-bold block">Matching Pairs:</span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                              {(item.matchingPairs || []).map((pair, idx) => (
                                <div key={pair.id || idx} className="p-1.5 bg-purple-950/30 border border-purple-500/30 rounded flex items-center justify-between">
                                  <span className="text-white font-bold">{pair.left}</span>
                                  <span className="text-purple-300 font-mono text-[11px]">↔ {pair.right}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {item.validationMessage && (
                          <p className="text-xs text-amber-400 flex items-center space-x-1 pt-1 font-semibold">
                            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                            <span>{item.validationMessage}</span>
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <span className="text-xs text-slate-400 font-semibold">
                {selectedIds.size} of {parsedItems.filter(i => i.status !== 'INVALID').length} ready for import
              </span>

              <div className="flex space-x-3">
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleImport}
                  disabled={selectedIds.size === 0}
                  className="px-6 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 disabled:opacity-50 text-slate-950 text-xs font-black uppercase tracking-wider transition-all flex items-center space-x-2 shadow-lg shadow-yellow-400/20"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Import {selectedIds.size} Questions</span>
                </button>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
