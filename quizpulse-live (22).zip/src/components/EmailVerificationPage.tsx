import React, { useState, useEffect } from 'react';
import { Mail, CheckCircle2, RefreshCw, ArrowRight, ShieldAlert, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface EmailVerificationPageProps {
  onVerified: () => void;
}

export const EmailVerificationPage: React.FC<EmailVerificationPageProps> = ({ onVerified }) => {
  const { user, profile, isEmailVerified, resendVerification, refreshAuth } = useAuth();

  const [resending, setResending] = useState(false);
  const [checking, setChecking] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (isEmailVerified) {
      onVerified();
      return;
    }

    const interval = setInterval(async () => {
      await refreshAuth();
    }, 3000);

    return () => clearInterval(interval);
  }, [isEmailVerified, refreshAuth]);

  const handleResend = async () => {
    setResending(true);
    setMessage('');
    const res = await resendVerification();
    setResending(false);

    if (res.success) {
      setMessage('A new verification email has been sent to ' + (user?.email || profile?.email || 'your inbox') + '.');
    } else {
      setMessage(res.error || 'Failed to resend verification email.');
    }
  };

  const handleCheckStatus = async () => {
    setChecking(true);
    setMessage('');
    await refreshAuth();
    setChecking(false);

    if (isEmailVerified) {
      onVerified();
    } else {
      setMessage('Email is not verified yet. Please click the link sent to your inbox.');
    }
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white flex items-center justify-center p-4 sm:p-6 md:p-10">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl text-center space-y-6 relative overflow-hidden">
        
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-yellow-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="w-20 h-20 bg-yellow-400/10 border-2 border-yellow-400/30 rounded-3xl flex items-center justify-center mx-auto text-yellow-400 shadow-xl">
          <Mail className="w-10 h-10 animate-bounce" />
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 bg-yellow-400/10 text-yellow-400 text-xs font-black uppercase tracking-widest rounded-full border border-yellow-400/30">
            Action Required
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Please verify your email before accessing your Host Dashboard.
          </h1>
          <p className="text-sm text-slate-300 font-semibold leading-relaxed">
            We sent a verification link to{' '}
            <strong className="text-yellow-400 font-bold">{user?.email || profile?.email || 'your email address'}</strong>.
            Please check your inbox and click the link to activate your Host Dashboard.
          </p>
        </div>

        {message && (
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs font-bold text-amber-300">
            {message}
          </div>
        )}

        <div className="space-y-3 pt-2">
          <button
            onClick={handleCheckStatus}
            disabled={checking}
            className="w-full py-4 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-yellow-400/20 transition-all flex items-center justify-center space-x-2"
          >
            {checking ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                <span>I'VE VERIFIED MY EMAIL (CHECK STATUS)</span>
              </>
            )}
          </button>

          <button
            onClick={handleResend}
            disabled={resending}
            className="w-full py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-2xl border border-slate-700 transition-colors flex items-center justify-center space-x-2"
          >
            {resending ? 'Sending Email...' : 'Resend Verification Email'}
          </button>
        </div>

        <div className="pt-4 border-t border-slate-800 text-xs text-slate-500 font-medium">
          Once verified, you will automatically be redirected to <strong className="text-slate-300">/host/dashboard</strong>.
        </div>

      </div>
    </div>
  );
};

