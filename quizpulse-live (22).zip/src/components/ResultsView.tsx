import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Download, RotateCcw, Award, Zap, Users, CheckCircle, Clock, Flame, Target, HelpCircle, FastForward, Hash, BarChart3 } from 'lucide-react';
import { GameSession, Participant } from '../types';
import { exportResultsToCSV } from '../utils/csv';
import { soundEffects } from '../utils/sound';
import { calculateParticipantStats } from '../utils/stats';
import { PostEventReportModal } from './PostEventReportModal';
import { EventFeedbackComponent } from './EventFeedbackComponent';

interface ResultsViewProps {
  session: GameSession;
  isHost: boolean;
  onHostAction: (action: string) => void;
  onNewGame: () => void;
  soundEnabled: boolean;
  onSubmitFeedback?: (rating: number, comment?: string) => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  session,
  isHost,
  onHostAction,
  onNewGame,
  soundEnabled,
  onSubmitFeedback
}) => {
  const participantsList: Participant[] = (Object.values(session.participants || {}) as Participant[])
    .sort((a, b) => b.score - a.score);

  const winner = participantsList[0];
  const totalQuestions = session.questions.length;
  const [selectedParticipantId, setSelectedParticipantId] = useState<string | null>(winner?.id || null);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);

  // Trigger celebration multi-burst confetti on mount
  useEffect(() => {
    try {
      // Primary burst
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });

      // Side cannon 1
      const timer1 = setTimeout(() => {
        confetti({
          particleCount: 60,
          angle: 60,
          spread: 60,
          origin: { x: 0, y: 0.7 }
        });
      }, 300);

      // Side cannon 2
      const timer2 = setTimeout(() => {
        confetti({
          particleCount: 60,
          angle: 120,
          spread: 60,
          origin: { x: 1, y: 0.7 }
        });
      }, 600);

      if (soundEnabled) {
        soundEffects.fanfare();
      }

      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
      };
    } catch (e) {}
  }, [soundEnabled]);

  const handleExportCSV = () => {
    exportResultsToCSV(session.title, participantsList, totalQuestions);
  };

  const selectedParticipant = participantsList.find(p => p.id === selectedParticipantId) || winner;
  const selectedStats = selectedParticipant ? calculateParticipantStats(selectedParticipant, totalQuestions, participantsList) : null;

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-indigo-950 text-white flex flex-col p-4 sm:p-6 md:p-8 relative max-w-5xl mx-auto w-full space-y-8">
      
      {/* Celebration Banner */}
      <div className="text-center space-y-3 pt-4">
        <div className="w-20 h-20 bg-amber-400 text-indigo-950 rounded-3xl mx-auto flex items-center justify-center text-4xl shadow-2xl shadow-amber-400/40 animate-bounce">
          🏆
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          Quiz Completed!
        </h1>
        <p className="text-base text-indigo-200 font-bold">
          {session.title} • {participantsList.length} Participants
        </p>
      </div>

      {/* Champion Banner */}
      {winner && (
        <div className="bg-amber-400 text-indigo-950 rounded-3xl p-6 sm:p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-4 right-4 px-4 py-1.5 bg-indigo-950 text-amber-400 font-black text-xs uppercase tracking-widest rounded-full shadow">
            Grand Champion
          </div>

          <div className="text-6xl mb-3">{winner.avatar}</div>
          <h2 className="text-3xl sm:text-4xl font-black text-indigo-950">{winner.name}</h2>
          <p className="text-3xl sm:text-5xl font-black text-indigo-950 mt-2 font-mono">
            {winner.score} POINTS
          </p>
          <p className="text-xs sm:text-sm font-bold text-indigo-900 mt-1">
            {winner.correctCount} / {totalQuestions} Correct Answers ({totalQuestions > 0 ? Math.round((winner.correctCount / totalQuestions) * 100) : 0}% Accuracy)
          </p>
        </div>
      )}

      {/* Detailed Participant Statistics Panel */}
      {selectedParticipant && selectedStats && (
        <div className="bg-indigo-900/80 border border-amber-400/40 rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="flex flex-wrap items-center justify-between border-b border-indigo-700/60 pb-4 gap-2">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">{selectedParticipant.avatar}</span>
              <div>
                <h3 className="text-xl font-black text-white flex items-center space-x-2">
                  <span>{selectedParticipant.name}</span>
                  <span className="text-xs px-2.5 py-0.5 bg-amber-400 text-indigo-950 rounded-full font-black">
                    {selectedStats.rankDisplay} Rank
                  </span>
                </h3>
                <p className="text-xs text-indigo-300 font-bold">Detailed Game Performance Summary</p>
              </div>
            </div>

            {participantsList.length > 1 && (
              <div className="flex items-center space-x-2">
                <span className="text-xs text-indigo-300 font-semibold">Select Player:</span>
                <select
                  value={selectedParticipant.id}
                  onChange={(e) => setSelectedParticipantId(e.target.value)}
                  className="bg-indigo-950 border border-indigo-700 text-amber-300 text-xs font-bold rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400"
                >
                  {participantsList.map((p, idx) => (
                    <option key={p.id ? `${p.id}-${idx}` : `opt-${idx}`} value={p.id}>
                      {p.name} ({p.score} pts)
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 pt-2">
            
            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Award className="w-5 h-5 text-amber-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Total Score</p>
              <p className="text-xl font-black text-amber-400 mt-0.5">{selectedStats.score}</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <CheckCircle className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Correct / Total</p>
              <p className="text-xl font-black text-emerald-400 mt-0.5">{selectedStats.correctAnswers} / {totalQuestions}</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <HelpCircle className="w-5 h-5 text-rose-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Incorrect</p>
              <p className="text-xl font-black text-rose-400 mt-0.5">{selectedStats.incorrectAnswers}</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Target className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Accuracy</p>
              <p className="text-xl font-black text-cyan-400 mt-0.5">{selectedStats.accuracy}%</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Flame className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Longest Streak</p>
              <p className="text-xl font-black text-yellow-400 mt-0.5">{selectedStats.longestCorrectStreak}</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Users className="w-5 h-5 text-indigo-300 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Answered</p>
              <p className="text-xl font-black text-indigo-200 mt-0.5">{selectedStats.questionsAnswered}</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <FastForward className="w-5 h-5 text-slate-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Skipped</p>
              <p className="text-xl font-black text-slate-300 mt-0.5">{selectedStats.questionsSkipped}</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Clock className="w-5 h-5 text-cyan-300 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Avg Time</p>
              <p className="text-xl font-black text-cyan-300 mt-0.5">{selectedStats.averageResponseTime}s</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Zap className="w-5 h-5 text-amber-300 mx-auto mb-1 fill-current" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Fastest Time</p>
              <p className="text-xl font-black text-amber-300 mt-0.5">{selectedStats.fastestResponse}s</p>
            </div>

            <div className="bg-indigo-950/80 border border-indigo-800 rounded-2xl p-3 text-center">
              <Hash className="w-5 h-5 text-indigo-400 mx-auto mb-1" />
              <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">Final Rank</p>
              <p className="text-xl font-black text-indigo-200 mt-0.5">{selectedStats.rankDisplay}</p>
            </div>

          </div>
        </div>
      )}

      {/* Top 10 Leaderboard Table */}
      <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-indigo-700/50 pb-4">
          <h3 className="text-lg font-black text-white flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span>Final Leaderboard</span>
          </h3>

          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-xs uppercase tracking-wider rounded-xl flex items-center space-x-2 shadow transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV Report</span>
          </button>
        </div>

        <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
          {participantsList.map((p, idx) => {
            const stats = calculateParticipantStats(p, totalQuestions, participantsList);
            return (
              <div
                key={p.id ? `${p.id}-${idx}` : `res-${p.name || idx}-${idx}`}
                onClick={() => setSelectedParticipantId(p.id)}
                className={`flex items-center justify-between p-3.5 rounded-2xl border cursor-pointer transition-all ${
                  selectedParticipantId === p.id
                    ? 'ring-2 ring-amber-400 border-amber-400 bg-amber-400/10'
                    : 'bg-indigo-950/70 border-indigo-500/30 hover:border-indigo-400'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span className={`w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center ${
                    idx === 0 ? 'bg-amber-400 text-indigo-950' : idx === 1 ? 'bg-cyan-400 text-indigo-950' : idx === 2 ? 'bg-rose-400 text-indigo-950' : 'bg-indigo-800 text-indigo-200'
                  }`}>
                    #{stats.finalRank}
                  </span>
                  <span className="text-2xl">{p.avatar}</span>
                  <div>
                    <p className="font-bold text-sm text-white">{p.name}</p>
                    <p className="text-[10px] text-indigo-300 font-semibold">
                      {stats.correctAnswers}/{totalQuestions} Correct ({stats.accuracy}% Accuracy) • {stats.longestCorrectStreak} Streak
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-black text-amber-400 text-base">{stats.score} pts</p>
                  <p className="text-[10px] text-indigo-300 font-semibold">
                    Avg: {stats.averageResponseTime}s
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Event Feedback Component for Participants */}
      {!isHost && session.settings.enableFeedback !== false && onSubmitFeedback && (
        <EventFeedbackComponent onSubmitFeedback={onSubmitFeedback} />
      )}

      {/* Host Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
        <button
          onClick={() => setShowReportModal(true)}
          className="w-full sm:w-auto py-4 px-6 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black rounded-2xl shadow-lg transition-all flex items-center justify-center space-x-2"
        >
          <BarChart3 className="w-5 h-5" />
          <span>VIEW POST-EVENT REPORT</span>
        </button>

        {isHost && (
          <button
            onClick={() => onHostAction('RESTART_GAME')}
            className="w-full sm:w-auto py-4 px-6 bg-indigo-900 hover:bg-indigo-800 text-indigo-100 font-extrabold rounded-2xl border border-indigo-500/30 transition-colors flex items-center justify-center space-x-2"
          >
            <RotateCcw className="w-5 h-5" />
            <span>PLAY AGAIN WITH SAME PLAYERS</span>
          </button>
        )}

        <button
          onClick={onNewGame}
          className="w-full sm:w-auto py-4 px-8 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-base rounded-2xl shadow-xl shadow-amber-400/20 transition-all flex items-center justify-center space-x-2"
        >
          <Zap className="w-5 h-5 fill-current" />
          <span>HOST NEW QUIZ SESSION</span>
        </button>
      </div>

      {/* Render Post Event Report Modal */}
      {showReportModal && (
        <PostEventReportModal
          session={session}
          onClose={() => setShowReportModal(false)}
        />
      )}

    </div>
  );
};
