import React, { useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { Play, Users, Copy, Check, Sparkles, Smile, Radio } from 'lucide-react';
import { GameSession, Participant } from '../types';
import { getParticipantJoinUrl } from '../utils/url';

interface WaitingRoomProps {
  session: GameSession;
  isHost: boolean;
  participantId?: string;
  onStartGame: () => void;
  onHostAction?: (action: string, payload?: any) => void;
  onSendReaction: (emoji: string) => void;
  reactions: Array<{ id: string; emoji: string; senderName: string }>;
}

const EMOJIS = ['🔥', '⚡', '🧠', '🎉', '🚀', '👏', '💎', '💯'];

export const WaitingRoom: React.FC<WaitingRoomProps> = ({
  session,
  isHost,
  participantId,
  onStartGame,
  onHostAction,
  onSendReaction,
  reactions
}) => {
  const qrCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [copied, setCopied] = React.useState(false);

  const participantsList: Participant[] = Object.values(session.participants || {});
  const currentParticipant = participantId ? session.participants[participantId] : null;

  const joinUrl = getParticipantJoinUrl(session.id);

  useEffect(() => {
    if (isHost && qrCanvasRef.current) {
      QRCode.toCanvas(qrCanvasRef.current, joinUrl, {
        width: 180,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff'
        }
      }, (err) => {
        if (err) {
          console.error('[QuizPulse] Error rendering QR code:', err);
        } else {
          console.log('[QuizPulse] QR generated for URL:', joinUrl);
        }
      });
    }
  }, [isHost, joinUrl]);

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(joinUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = joinUrl;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.warn('Clipboard write error, fallback copy:', err);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-indigo-950 text-white flex flex-col p-4 sm:p-6 md:p-8 relative overflow-hidden">
      
      {/* Reaction Animation Canvas / Overlay */}
      <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
        {reactions.map((r) => (
          <div
            key={r.id}
            className="absolute animate-floatUp text-4xl sm:text-5xl"
            style={{
              left: `${10 + Math.random() * 80}%`,
              bottom: '10%'
            }}
          >
            {r.emoji}
          </div>
        ))}
      </div>

      <div className="max-w-6xl mx-auto w-full flex-1 flex flex-col justify-between space-y-8">
        
        {/* Top Header Card */}
        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="flex items-center space-x-4 text-center md:text-left">
            <div className="w-14 h-14 rounded-2xl bg-amber-400 text-indigo-950 flex items-center justify-center font-black flex-shrink-0 shadow-lg shadow-amber-400/20">
              <Radio className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <span className="inline-block px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs font-bold uppercase tracking-widest mb-1">
                {isHost ? 'Host Presenter Control' : 'Participant Lobby'}
              </span>
              <h1 className="text-2xl sm:text-3xl font-black text-white">{session.title}</h1>
              <p className="text-xs text-indigo-200 mt-1 font-semibold">
                {session.questions.length} Questions • {session.settings.timerDurationSec}s per question
              </p>
            </div>
          </div>

          {/* Session Code & Quick Copy */}
          <div className="bg-indigo-950/80 border border-indigo-500/40 rounded-2xl p-4 flex items-center space-x-4 shadow-inner">
            <div>
              <p className="text-[10px] text-indigo-300 uppercase font-bold tracking-widest">Join Code</p>
              <p className="text-3xl sm:text-4xl font-black text-amber-400 tracking-widest font-mono">
                {session.id}
              </p>
            </div>
            <button
              onClick={handleCopyLink}
              className="p-3 bg-indigo-800 hover:bg-indigo-700 text-indigo-100 rounded-xl transition-colors border border-indigo-500/30"
              title="Copy Join Link"
            >
              {copied ? <Check className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Main Body Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
          
          {/* Left / Center: QR Code & Start Controls for Host OR Waiting Animation for Participant */}
          {isHost ? (
            <div className="lg:col-span-1 bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 flex flex-col items-center justify-between text-center space-y-5 shadow-2xl">
              <div className="p-2.5 bg-white rounded-2xl shadow-2xl">
                <canvas ref={qrCanvasRef} />
              </div>
              <div className="w-full bg-indigo-950/80 border border-indigo-500/30 rounded-2xl p-3.5 text-center space-y-2">
                <p className="text-[11px] text-indigo-300 font-semibold uppercase tracking-wider">Join at:</p>
                <p className="text-xs text-amber-400 font-mono font-bold break-all px-1 select-all">{joinUrl}</p>
                <button
                  onClick={handleCopyLink}
                  className="w-full py-2.5 px-4 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-xs rounded-xl shadow-md flex items-center justify-center space-x-1.5 transition-all active:scale-95"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-800 stroke-[3]" />
                      <span>✓ Link Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-indigo-950" />
                      <span>Copy Join Link</span>
                    </>
                  )}
                </button>
              </div>

              {/* Action Toolbar for Host Testing & Management */}
              <div className="w-full space-y-2 pt-2 border-t border-indigo-800/60">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => window.open(joinUrl, '_blank')}
                    className="py-2.5 px-3 bg-indigo-950/80 hover:bg-indigo-800 text-indigo-100 font-bold text-xs rounded-xl border border-indigo-500/30 flex items-center justify-center space-x-1 transition-colors"
                    title="Open participant join screen in a new browser tab"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Open Player Tab</span>
                  </button>

                  <button
                    onClick={() => onHostAction && onHostAction('ADD_TEST_BOT')}
                    className="py-2.5 px-3 bg-indigo-950/80 hover:bg-indigo-800 text-indigo-100 font-bold text-xs rounded-xl border border-indigo-500/30 flex items-center justify-center space-x-1 transition-colors"
                    title="Add a virtual AI test bot to simulate gameplay"
                  >
                    <span>🤖 + Add Test Bot</span>
                  </button>
                </div>

                <button
                  onClick={onStartGame}
                  className="w-full py-4 px-6 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-lg rounded-2xl shadow-xl shadow-amber-400/20 transition-all flex items-center justify-center space-x-2 transform active:scale-98"
                >
                  <Play className="w-6 h-6 fill-current" />
                  <span>START QUIZ GAME {participantsList.length > 0 ? `(${participantsList.length})` : '(Host Preview)'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="lg:col-span-1 bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 flex flex-col items-center justify-center text-center space-y-6 shadow-2xl">
              <div className="w-24 h-24 rounded-3xl bg-amber-400 text-indigo-950 flex items-center justify-center text-5xl shadow-xl shadow-amber-400/30 animate-pulse">
                {currentParticipant?.avatar || '🦊'}
              </div>

              <div>
                <h2 className="text-xl font-black text-white">
                  Welcome, {currentParticipant?.name || 'Player'}!
                </h2>
                <p className="text-xs text-indigo-200 mt-1 font-semibold animate-pulse">
                  Waiting for host to launch the quiz...
                </p>
              </div>

              {/* Floating Reaction Toolbar */}
              <div className="w-full pt-4 border-t border-indigo-700/50">
                <p className="text-xs text-indigo-300 font-bold mb-3 flex items-center justify-center space-x-1 uppercase tracking-wider">
                  <Smile className="w-4 h-4 text-amber-400" />
                  <span>Send Reaction</span>
                </p>
                <div className="grid grid-cols-4 gap-2">
                  {EMOJIS.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => onSendReaction(emoji)}
                      className="p-3 bg-indigo-950/80 hover:bg-indigo-800 active:scale-125 transition-transform text-2xl rounded-2xl border border-indigo-700/50"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Right Column: Participant Roster */}
          <div className="lg:col-span-2 bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 flex flex-col shadow-2xl">
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-indigo-700/50">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-amber-400" />
                <h2 className="text-lg font-black text-white">
                  Connected Participants ({participantsList.length} / {session.settings?.maxParticipants || 50})
                </h2>
              </div>
              <span className="text-xs text-emerald-300 bg-emerald-400/20 px-3 py-1 rounded-full border border-emerald-400/30 font-bold">
                Live Synced
              </span>
            </div>

            {participantsList.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-indigo-300">
                <Users className="w-12 h-12 stroke-1 mb-2 animate-bounce text-indigo-400" />
                <p className="text-sm font-bold">No players in the lobby yet.</p>
                <p className="text-xs text-indigo-200 mt-1">Share the join code or scan the QR code to connect!</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto pr-1">
                {participantsList.map((p, idx) => (
                  <div
                    key={p.id ? `${p.id}-${idx}` : `p-${p.name || idx}-${idx}`}
                    className="flex items-center space-x-3 p-3 bg-indigo-950/70 border border-indigo-500/30 rounded-2xl shadow-sm transition-transform hover:scale-102"
                  >
                    <span className="text-2xl">{p.avatar}</span>
                    <div className="overflow-hidden">
                      <p className="text-sm font-bold text-white truncate">{p.name}</p>
                      <span className="text-[10px] text-emerald-400 font-bold flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 animate-ping"></span>
                        Ready
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
