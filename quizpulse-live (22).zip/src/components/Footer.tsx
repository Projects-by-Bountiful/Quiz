import React, { useState } from 'react';
import { 
  Sparkles, Info, Shield, FileText, HelpCircle, Mail, DollarSign, Zap, X, 
  Twitter, Instagram, Linkedin, Send, Check
} from 'lucide-react';

type FooterModalType = 'about' | 'features' | 'pricing' | 'contact' | 'privacy' | 'terms' | 'support' | 'how-it-works' | 'game-types' | 'whats-new' | 'events' | 'teams' | 'education' | 'communities' | 'blog' | null;

export const Footer: React.FC = () => {
  const [activeModal, setActiveModal] = useState<FooterModalType>(null);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const closeModal = () => setActiveModal(null);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setEmail('');
    }
  };

  return (
    <>
      <footer className="bg-[#0B0E14] text-white pt-16 pb-12 border-t border-white/10 font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          {/* Main 5-Column Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-10 lg:gap-12">
            
            {/* Col 1: Brand & Tagline & Socials */}
            <div className="space-y-6 md:col-span-1">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center font-black text-base shadow-lg shadow-red-600/30">
                  <Zap className="w-5 h-5 fill-current" />
                </div>
                <span className="text-xl font-extrabold tracking-tight text-white">QuizPulse</span>
              </div>

              <div className="text-sm font-medium text-slate-300 leading-snug">
                <p>Live games.</p>
                <p>Real participation.</p>
              </div>

              {/* Social Icons */}
              <div className="flex items-center space-x-4 pt-1 text-slate-400">
                <a 
                  href="https://twitter.com" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 hover:text-white transition-all"
                  aria-label="Twitter"
                >
                  <Twitter className="w-4 h-4" />
                </a>
                <a 
                  href="https://instagram.com" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 hover:text-white transition-all"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a 
                  href="https://linkedin.com" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 hover:text-white transition-all"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Col 2: Product */}
            <div className="space-y-4">
              <h4 className="font-bold text-sm text-white tracking-wide">Product</h4>
              <ul className="space-y-3 text-xs font-medium text-slate-400">
                <li>
                  <button onClick={() => setActiveModal('features')} className="hover:text-white transition-colors">
                    Features
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('how-it-works')} className="hover:text-white transition-colors">
                    How It Works
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('game-types')} className="hover:text-white transition-colors">
                    Game Types
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('pricing')} className="hover:text-white transition-colors">
                    Pricing
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('whats-new')} className="hover:text-white transition-colors">
                    What's New
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Solutions */}
            <div className="space-y-4">
              <h4 className="font-bold text-sm text-white tracking-wide">Solutions</h4>
              <ul className="space-y-3 text-xs font-medium text-slate-400">
                <li>
                  <button onClick={() => setActiveModal('events')} className="hover:text-white transition-colors">
                    Events
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('teams')} className="hover:text-white transition-colors">
                    Teams
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('education')} className="hover:text-white transition-colors">
                    Education
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('communities')} className="hover:text-white transition-colors">
                    Communities
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 4: Resources */}
            <div className="space-y-4">
              <h4 className="font-bold text-sm text-white tracking-wide">Resources</h4>
              <ul className="space-y-3 text-xs font-medium text-slate-400">
                <li>
                  <button onClick={() => setActiveModal('support')} className="hover:text-white transition-colors">
                    Help Centre
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('support')} className="hover:text-white transition-colors">
                    Host Guide
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('blog')} className="hover:text-white transition-colors">
                    Blog
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveModal('contact')} className="hover:text-white transition-colors">
                    Contact
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 5: Newsletter */}
            <div className="space-y-4 md:col-span-1">
              <h4 className="font-bold text-sm text-white tracking-wide">Newsletter</h4>
              <p className="text-xs text-slate-400 font-medium leading-relaxed">
                Get tips and updates on running better live games.
              </p>

              <form onSubmit={handleNewsletterSubmit} className="pt-1">
                <div className="flex items-center rounded-xl overflow-hidden bg-white/5 border border-white/10 p-1 focus-within:border-yellow-400/80 transition-all">
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full bg-transparent px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
                    required
                  />
                  <button
                    type="submit"
                    className="bg-yellow-400 hover:bg-yellow-300 text-slate-950 px-4 py-2 rounded-lg font-extrabold text-xs transition-all flex items-center gap-1.5 flex-shrink-0"
                  >
                    {subscribed ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-slate-950" />
                        <span>Joined!</span>
                      </>
                    ) : (
                      <span>Subscribe</span>
                    )}
                  </button>
                </div>
              </form>
            </div>

          </div>

          {/* Bottom Bar Divider & Copyright */}
          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-medium text-slate-500">
            <div>
              © 2024 QuizPulse. Powered by Freelancer360.
            </div>

            <div className="flex items-center space-x-6">
              <button 
                onClick={() => setActiveModal('privacy')} 
                className="hover:text-slate-300 transition-colors"
              >
                Privacy Policy
              </button>
              <button 
                onClick={() => setActiveModal('terms')} 
                className="hover:text-slate-300 transition-colors"
              >
                Terms of Service
              </button>
            </div>
          </div>

        </div>
      </footer>

      {/* Information Modals */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl space-y-6 relative max-h-[85vh] overflow-y-auto text-white">
            
            <button
              onClick={closeModal}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {activeModal === 'about' && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <Info className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">About QuizPulse</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  QuizPulse is a next-generation real-time quiz platform designed for live events, corporate workshops, classroom learning, and virtual meetups.
                </p>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Our mission is to create effortless engagement by enabling hosts to launch synchronized trivia challenges that stream instantly across mobile phones, laptops, and projector screens without requiring players to download apps or sign up for accounts.
                </p>
              </div>
            )}

            {(activeModal === 'features' || activeModal === 'game-types' || activeModal === 'whats-new') && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <Zap className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Platform Features</h2>
                </div>
                <ul className="space-y-2 text-sm text-slate-300">
                  <li className="flex items-start space-x-2">
                    <span className="text-yellow-400 font-bold">•</span>
                    <span><strong>Instant Mobile Join:</strong> Join live games in seconds via QR codes or 6-digit room PINs.</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-yellow-400 font-bold">•</span>
                    <span><strong>Host Workspace:</strong> Organized question banks, category management, and saved session templates.</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-yellow-400 font-bold">•</span>
                    <span><strong>AI Question Generator:</strong> Generate rich multiple-choice questions instantly using Gemini AI.</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-yellow-400 font-bold">•</span>
                    <span><strong>Real-Time Leaderboards:</strong> Synchronized live rankings with speed bonuses and animated reveals.</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-yellow-400 font-bold">•</span>
                    <span><strong>Detailed Analytics:</strong> Historical accuracy stats, question difficulty breakdowns, and CSV export.</span>
                  </li>
                </ul>
              </div>
            )}

            {activeModal === 'how-it-works' && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <Sparkles className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">How It Works</h2>
                </div>
                <div className="space-y-3 text-sm text-slate-300">
                  <p>1. <strong>Create or Import:</strong> Set up your questions manually or import CSV/JSON question banks.</p>
                  <p>2. <strong>Launch Room:</strong> Open a room to display the QR code and 6-digit Game PIN on screen.</p>
                  <p>3. <strong>Players Join:</strong> Participants scan the code or enter the PIN on their phone to join live.</p>
                  <p>4. <strong>Play & Reveal:</strong> Host questions, trigger live answer reveals, and present the final leaderboard podium.</p>
                </div>
              </div>
            )}

            {(activeModal === 'events' || activeModal === 'teams' || activeModal === 'education' || activeModal === 'communities') && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <Sparkles className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Solutions for Every Group</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  QuizPulse is engineered to scale seamlessly across conferences, hybrid workplaces, university lecture halls, and community game nights.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                    <strong className="text-blue-400 block mb-1">Live Events</strong>
                    <span>Engage large audiences at conferences and stage presentations.</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                    <strong className="text-indigo-400 block mb-1">Workplace Teams</strong>
                    <span>Energize team meetings, onboarding sessions, and company all-hands.</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                    <strong className="text-emerald-400 block mb-1">Education</strong>
                    <span>Interactive classroom revision quizzes with instant performance insight.</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                    <strong className="text-rose-400 block mb-1">Communities</strong>
                    <span>Trivia nights for associations, social clubs, and church gatherings.</span>
                  </div>
                </div>
              </div>
            )}

            {activeModal === 'pricing' && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <DollarSign className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Pricing Plans (Coming Soon)</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  QuizPulse is currently <strong>100% Free</strong> for all hosts and participants during our public beta.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <h3 className="font-bold text-white text-base">Community Host (Free)</h3>
                    <p className="text-xs text-slate-400">Unlimited public games up to 100 participants per room.</p>
                  </div>
                  <div className="p-4 rounded-2xl bg-yellow-400/10 border border-yellow-400/30 space-y-2">
                    <h3 className="font-bold text-yellow-400 text-base">Pro Enterprise (Coming Soon)</h3>
                    <p className="text-xs text-slate-300">Custom branding, dedicated database, 1,000+ live participants, SSO & SLA support.</p>
                  </div>
                </div>
              </div>
            )}

            {activeModal === 'contact' && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <Mail className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Contact Us</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Have questions, feature requests, or partnership inquiries? Get in touch with our team:
                </p>
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-sm text-slate-300">
                  <p><strong>Email:</strong> support@quizpulse.com</p>
                  <p><strong>Host Support:</strong> hosts@quizpulse.com</p>
                  <p><strong>Organization:</strong> Freelancer360 Team</p>
                </div>
              </div>
            )}

            {activeModal === 'privacy' && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <Shield className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Privacy Policy</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  At QuizPulse, we prioritize data privacy and user security:
                </p>
                <ul className="space-y-2 text-xs text-slate-400 list-disc pl-5">
                  <li>Players can join live quizzes anonymously without creating accounts or revealing personal data.</li>
                  <li>Host account details are stored securely with strict database access controls.</li>
                  <li>We never sell or distribute host or participant data to third-party advertisers.</li>
                </ul>
              </div>
            )}

            {activeModal === 'terms' && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <FileText className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Terms of Service</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  By using QuizPulse, hosts and participants agree to maintain appropriate content standards:
                </p>
                <ul className="space-y-2 text-xs text-slate-400 list-disc pl-5">
                  <li>Hosts are solely responsible for questions uploaded or generated within their account.</li>
                  <li>Offensive, defamatory, or unlawful content in quiz titles or answers is strictly prohibited.</li>
                  <li>QuizPulse provides the service on an as-is basis with high availability guarantees for live events.</li>
                </ul>
              </div>
            )}

            {(activeModal === 'support' || activeModal === 'blog') && (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-yellow-400">
                  <HelpCircle className="w-6 h-6" />
                  <h2 className="text-xl font-black text-white">Help & Host Resources</h2>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Need help hosting your first live event or setting up your question bank?
                </p>
                <div className="space-y-2 text-xs text-slate-300">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <strong className="text-yellow-400 block mb-1">How do players join?</strong>
                    <span>Players scan the QR code displayed on the host presenter screen or enter the 6-digit room PIN at the home page. No signups required!</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <strong className="text-yellow-400 block mb-1">How do I create a Question Bank?</strong>
                    <span>Log in as a Host, navigate to Question Banks, and click "Add Question", "Import CSV/JSON", or "Generate with AI".</span>
                  </div>
                </div>
              </div>
            )}

            <div className="pt-4 flex justify-end">
              <button
                onClick={closeModal}
                className="py-2.5 px-6 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-xl transition-all"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
