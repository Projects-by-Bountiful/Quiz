import React, { useEffect } from 'react';
import { CheckCircle2, XCircle, ArrowRight, Zap, Flame, Award, HelpCircle, ListOrdered, ArrowRightLeft, Sparkles } from 'lucide-react';
import { GameSession, Question, Participant } from '../types';
import { soundEffects } from '../utils/sound';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';

interface AnswerRevealProps {
  session: GameSession;
  isHost: boolean;
  participantId?: string;
  onHostAction: (action: string) => void;
  soundEnabled: boolean;
}

export const AnswerReveal: React.FC<AnswerRevealProps> = ({
  session,
  isHost,
  participantId,
  onHostAction,
  soundEnabled
}) => {
  const currentQ: Question | undefined = session.questions[session.currentQuestionIndex];
  const participant: Participant | undefined = participantId ? session.participants[participantId] : undefined;
  
  const userAns = currentQ ? participant?.answers[currentQ.id] : undefined;
  const isCorrect = userAns ? userAns.isCorrect : false;

  useEffect(() => {
    if (soundEnabled && !isHost) {
      if (isCorrect) {
        soundEffects.correct();
      } else if (userAns) {
        soundEffects.incorrect();
      }
    }
  }, [soundEnabled, isHost, isCorrect, userAns]);

  if (!currentQ) return null;

  const qType = currentQ.type || 'multiple_choice';
  const typeBadgeStyle = getQuestionTypeBadgeColor(qType);
  const typeLabel = getQuestionTypeLabel(qType);

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-slate-950 text-white flex flex-col p-4 sm:p-6 md:p-8 relative justify-between max-w-5xl mx-auto w-full space-y-6">
      
      {/* Participant Result Header Card */}
      {!isHost && userAns && (
        <div className={`p-6 rounded-3xl border-2 flex flex-col sm:flex-row items-center justify-between text-center sm:text-left gap-4 shadow-2xl ${
          isCorrect ? 'bg-emerald-950/90 border-emerald-400/60 text-emerald-100 shadow-emerald-500/20' : 'bg-rose-950/90 border-rose-500/60 text-rose-100 shadow-rose-500/20'
        }`}>
          <div className="flex items-center space-x-4">
            {isCorrect ? (
              <div className="w-14 h-14 rounded-2xl bg-emerald-400 text-slate-950 flex items-center justify-center font-black flex-shrink-0 shadow-lg shadow-emerald-400/30">
                <CheckCircle2 className="w-8 h-8" />
              </div>
            ) : (
              <div className="w-14 h-14 rounded-2xl bg-rose-500 text-white flex items-center justify-center font-black flex-shrink-0 shadow-lg shadow-rose-500/30">
                <XCircle className="w-8 h-8" />
              </div>
            )}
            <div>
              <h2 className="text-2xl font-black">
                {isCorrect ? 'Correct Answer!' : 'Incorrect'}
              </h2>
              <p className="text-xs sm:text-sm font-semibold opacity-90 mt-0.5">
                {isCorrect ? `+${userAns.scoreGained} Points (${userAns.speedBonus > 0 ? `Includes +${userAns.speedBonus} speed bonus!` : 'Base score'})` : 'Better luck next question!'}
              </p>
            </div>
          </div>

          {participant && participant.streak > 1 && (
            <div className="flex items-center space-x-2 px-4 py-2 bg-amber-400 text-slate-950 rounded-2xl text-sm font-black animate-pulse shadow-lg">
              <Flame className="w-5 h-5 fill-current text-slate-950" />
              <span>{participant.streak} In A Row Streak!</span>
            </div>
          )}
        </div>
      )}

      {/* Main Answer Reveal Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        
        <div className="flex items-center justify-between">
          <div className="text-xs font-black uppercase tracking-widest text-amber-400">
            Question {session.currentQuestionIndex + 1} of {session.questions.length} Reveal
          </div>
          <span className={`text-[10px] font-bold px-3 py-1 rounded-xl uppercase tracking-wider border ${typeBadgeStyle.bg} ${typeBadgeStyle.text} ${typeBadgeStyle.border}`}>
            {typeLabel}
          </span>
        </div>

        <h3 className="text-xl sm:text-2xl md:text-3xl font-black text-white leading-snug">
          {currentQ.question}
        </h3>

        {/* 1. Multiple Choice & Fastest Fingers Reveal Breakdown */}
        {(qType === 'multiple_choice' || qType === 'fastest_fingers') && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(currentQ.options || []).map((opt, idx) => {
              const isThisCorrect = idx === currentQ.correctAnswer;
              const isUserSelection = userAns && userAns.selectedOption === idx;

              return (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl border-2 font-bold flex items-center justify-between transition-all ${
                    isThisCorrect
                      ? 'bg-emerald-400/20 border-emerald-400 text-emerald-200 shadow-md ring-2 ring-emerald-400/40'
                      : isUserSelection
                      ? 'bg-rose-500/20 border-rose-500 text-rose-200'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="w-8 h-8 rounded-xl bg-slate-800 text-slate-200 flex items-center justify-center text-xs font-black">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span>{opt}</span>
                  </div>
                  {isThisCorrect && (
                    <span className="flex items-center space-x-1 text-xs px-3 py-1 bg-emerald-400 text-slate-950 font-black rounded-xl shadow">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>CORRECT</span>
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* 2. Fill in the Blank Reveal Breakdown */}
        {qType === 'fill_blank' && (
          <div className="space-y-4">
            <div className="p-5 bg-slate-950/80 rounded-2xl border border-emerald-500/40 space-y-2">
              <div className="text-xs font-black uppercase text-emerald-400 flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Accepted Correct Answer(s)</span>
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                {(currentQ.acceptedAnswers || []).map((ans, i) => (
                  <span key={i} className="px-3.5 py-1.5 bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 font-black text-sm rounded-xl">
                    "{ans}"
                  </span>
                ))}
              </div>
            </div>

            {userAns && userAns.textAnswer && (
              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 flex items-center justify-between text-sm">
                <span className="text-slate-400">Your Submission:</span>
                <span className={`font-bold font-mono ${userAns.isCorrect ? 'text-emerald-300' : 'text-rose-400'}`}>
                  "{userAns.textAnswer}"
                </span>
              </div>
            )}
          </div>
        )}

        {/* 3. Ordering / Ranking Reveal Breakdown */}
        {qType === 'ordering' && (
          <div className="space-y-3">
            <div className="text-xs font-black uppercase text-cyan-400 flex items-center space-x-1.5">
              <ListOrdered className="w-4 h-4" />
              <span>Correct Sequence (1st to Last)</span>
            </div>
            <div className="space-y-2">
              {(currentQ.orderItems || currentQ.options || []).map((item, idx) => (
                <div key={idx} className="p-3.5 bg-cyan-950/30 border border-cyan-500/40 rounded-2xl flex items-center space-x-3 text-slate-100 font-bold text-sm">
                  <span className="w-7 h-7 rounded-xl bg-cyan-500 text-slate-950 flex items-center justify-center font-black text-xs flex-shrink-0">
                    {idx + 1}
                  </span>
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. Matching Reveal Breakdown */}
        {qType === 'matching' && (
          <div className="space-y-3">
            <div className="text-xs font-black uppercase text-purple-400 flex items-center space-x-1.5">
              <ArrowRightLeft className="w-4 h-4" />
              <span>Correct Pairs</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(currentQ.matchingPairs || []).map((pair, idx) => (
                <div key={pair.id || idx} className="p-3.5 bg-purple-950/30 border border-purple-500/40 rounded-2xl flex items-center justify-between text-sm">
                  <span className="font-bold text-white pr-2">{pair.left}</span>
                  <span className="text-xs px-2.5 py-1 bg-purple-500/30 border border-purple-400 text-purple-200 font-bold rounded-xl flex-shrink-0">
                    ↔ {pair.right}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Explanation Box */}
        {currentQ.explanation && (
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl text-xs sm:text-sm text-slate-200 flex items-start space-x-3">
            <HelpCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-black text-amber-400 block mb-0.5 uppercase tracking-wider text-xs">Explanation</span>
              <p className="leading-relaxed font-semibold">{currentQ.explanation}</p>
            </div>
          </div>
        )}

      </div>

      {/* Host Controls */}
      {isHost && (
        <div className="flex justify-end space-x-4">
          <button
            onClick={() => onHostAction('SHOW_LEADERBOARD')}
            className="py-4 px-8 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-base rounded-2xl shadow-xl shadow-amber-400/20 transition-all flex items-center space-x-2 active:scale-95"
          >
            <Award className="w-5 h-5" />
            <span>SHOW LIVE LEADERBOARD</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}

    </div>
  );
};
