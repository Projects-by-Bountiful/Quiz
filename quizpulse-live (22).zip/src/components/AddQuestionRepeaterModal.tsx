import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Copy, Sparkles, X, Check, HelpCircle, Layers, Zap, ListOrdered, ArrowRightLeft } from 'lucide-react';
import { Question, Category, Difficulty, QuestionType, MatchingPair } from '../types';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';

export interface DraftQuestionItem {
  id: string;
  type: QuestionType;
  question: string;
  options: [string, string, string, string];
  correctAnswer: number;
  acceptedAnswersText: string;
  orderItems: string[];
  matchingPairs: MatchingPair[];
  explanation: string;
  category: Category;
  difficulty: Difficulty;
  estimatedTimeSec: number;
}

interface AddQuestionRepeaterModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  defaultCategory: Category;
  editingQuestion?: Question | null;
  onQuestionsAdded: (questions: Question[]) => void;
  onQuestionUpdated?: (question: Question) => void;
}

export const AddQuestionRepeaterModal: React.FC<AddQuestionRepeaterModalProps> = ({
  isOpen,
  onClose,
  categories,
  defaultCategory,
  editingQuestion,
  onQuestionsAdded,
  onQuestionUpdated
}) => {
  const createEmptyDraft = (cat: Category, index: number): DraftQuestionItem => ({
    id: `draft_${Date.now()}_${index}_${Math.random().toString(36).substring(2, 6)}`,
    type: 'multiple_choice',
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    acceptedAnswersText: '',
    orderItems: ['', '', '', ''],
    matchingPairs: [
      { id: '1', left: '', right: '' },
      { id: '2', left: '', right: '' },
      { id: '3', left: '', right: '' },
      { id: '4', left: '', right: '' }
    ],
    explanation: '',
    category: cat,
    difficulty: 'Medium',
    estimatedTimeSec: 20
  });

  const [drafts, setDrafts] = useState<DraftQuestionItem[]>([]);
  const [globalCategory, setGlobalCategory] = useState<Category>(defaultCategory);
  const [globalDifficulty, setGlobalDifficulty] = useState<Difficulty>('Medium');

  useEffect(() => {
    if (isOpen) {
      if (editingQuestion) {
        const qType = editingQuestion.type || 'multiple_choice';
        setDrafts([{
          id: editingQuestion.id,
          type: qType,
          question: editingQuestion.question,
          options: (editingQuestion.options && editingQuestion.options.length >= 4 
            ? [...editingQuestion.options] 
            : ['', '', '', '']) as [string, string, string, string],
          correctAnswer: editingQuestion.correctAnswer || 0,
          acceptedAnswersText: (editingQuestion.acceptedAnswers || []).join(', '),
          orderItems: editingQuestion.orderItems && editingQuestion.orderItems.length > 0 
            ? [...editingQuestion.orderItems] 
            : ['', '', '', ''],
          matchingPairs: editingQuestion.matchingPairs && editingQuestion.matchingPairs.length > 0 
            ? [...editingQuestion.matchingPairs] 
            : [
                { id: '1', left: '', right: '' },
                { id: '2', left: '', right: '' }
              ],
          explanation: editingQuestion.explanation || '',
          category: editingQuestion.category || defaultCategory,
          difficulty: editingQuestion.difficulty || 'Medium',
          estimatedTimeSec: editingQuestion.estimatedTimeSec || 20
        }]);
      } else {
        setGlobalCategory(defaultCategory);
        setDrafts([createEmptyDraft(defaultCategory, 0)]);
      }
    }
  }, [isOpen, editingQuestion?.id, defaultCategory]);

  if (!isOpen) return null;

  const isEditingSingle = Boolean(editingQuestion && editingQuestion.id);

  const handleAddRepeaterQuestion = () => {
    setDrafts(prev => [
      ...prev,
      createEmptyDraft(globalCategory, prev.length)
    ]);
  };

  const handleDuplicateDraft = (index: number) => {
    const target = drafts[index];
    const duplicated: DraftQuestionItem = {
      ...target,
      id: `draft_${Date.now()}_dup_${Math.random().toString(36).substring(2, 6)}`,
      question: `${target.question} (Copy)`,
      options: [...target.options] as [string, string, string, string],
      orderItems: [...target.orderItems],
      matchingPairs: target.matchingPairs.map(p => ({ ...p }))
    };

    setDrafts(prev => {
      const copy = [...prev];
      copy.splice(index + 1, 0, duplicated);
      return copy;
    });
  };

  const handleRemoveDraft = (index: number) => {
    if (drafts.length === 1 && !isEditingSingle) {
      setDrafts([createEmptyDraft(globalCategory, 0)]);
      return;
    }
    setDrafts(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpdateDraft = (index: number, fields: Partial<DraftQuestionItem>) => {
    setDrafts(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], ...fields };
      return copy;
    });
  };

  const handleOptionChange = (draftIdx: number, optIdx: number, val: string) => {
    setDrafts(prev => {
      const copy = [...prev];
      const newOpts = [...copy[draftIdx].options] as [string, string, string, string];
      newOpts[optIdx] = val;
      copy[draftIdx].options = newOpts;
      return copy;
    });
  };

  const handleOrderItemChange = (draftIdx: number, itemIdx: number, val: string) => {
    setDrafts(prev => {
      const copy = [...prev];
      const newItems = [...copy[draftIdx].orderItems];
      newItems[itemIdx] = val;
      copy[draftIdx].orderItems = newItems;
      return copy;
    });
  };

  const handleMatchingPairChange = (draftIdx: number, pairIdx: number, side: 'left' | 'right', val: string) => {
    setDrafts(prev => {
      const copy = [...prev];
      const newPairs = copy[draftIdx].matchingPairs.map((p, i) => 
        i === pairIdx ? { ...p, [side]: val } : p
      );
      copy[draftIdx].matchingPairs = newPairs;
      return copy;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const validQuestions: Question[] = [];
    for (const d of drafts) {
      if (!d.question.trim()) continue;

      const qType = d.type || 'multiple_choice';

      if (qType === 'multiple_choice' || qType === 'fastest_fingers') {
        if (d.options.some(opt => !opt.trim())) continue;
        validQuestions.push({
          id: isEditingSingle ? d.id : `q_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          type: qType,
          category: d.category || globalCategory || 'General Knowledge',
          difficulty: d.difficulty || globalDifficulty || 'Medium',
          question: d.question.trim(),
          options: d.options.map(o => o.trim()) as [string, string, string, string],
          correctAnswer: d.correctAnswer,
          explanation: d.explanation.trim(),
          tags: [d.category || globalCategory, d.difficulty || globalDifficulty],
          estimatedTimeSec: qType === 'fastest_fingers' ? 10 : 20,
          status: 'active'
        });
      } else if (qType === 'fill_blank') {
        const accepted = d.acceptedAnswersText
          .split(',')
          .map(s => s.trim())
          .filter(Boolean);
        if (accepted.length === 0) continue;

        validQuestions.push({
          id: isEditingSingle ? d.id : `q_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          type: 'fill_blank',
          category: d.category || globalCategory || 'General Knowledge',
          difficulty: d.difficulty || globalDifficulty || 'Medium',
          question: d.question.trim(),
          options: [],
          correctAnswer: 0,
          acceptedAnswers: accepted,
          explanation: d.explanation.trim(),
          tags: [d.category || globalCategory, d.difficulty || globalDifficulty],
          estimatedTimeSec: 20,
          status: 'active'
        });
      } else if (qType === 'ordering') {
        const filteredItems = d.orderItems.map(s => s.trim()).filter(Boolean);
        if (filteredItems.length < 2) continue;

        validQuestions.push({
          id: isEditingSingle ? d.id : `q_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          type: 'ordering',
          category: d.category || globalCategory || 'General Knowledge',
          difficulty: d.difficulty || globalDifficulty || 'Medium',
          question: d.question.trim(),
          options: filteredItems,
          orderItems: filteredItems,
          correctAnswer: 0,
          explanation: d.explanation.trim(),
          tags: [d.category || globalCategory, d.difficulty || globalDifficulty],
          estimatedTimeSec: 25,
          status: 'active'
        });
      } else if (qType === 'matching') {
        const validPairs = d.matchingPairs
          .filter(p => p.left.trim() && p.right.trim())
          .map((p, idx) => ({ id: `m_${idx + 1}`, left: p.left.trim(), right: p.right.trim() }));
        if (validPairs.length < 2) continue;

        validQuestions.push({
          id: isEditingSingle ? d.id : `q_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          type: 'matching',
          category: d.category || globalCategory || 'General Knowledge',
          difficulty: d.difficulty || globalDifficulty || 'Medium',
          question: d.question.trim(),
          options: [],
          matchingPairs: validPairs,
          correctAnswer: 0,
          explanation: d.explanation.trim(),
          tags: [d.category || globalCategory, d.difficulty || globalDifficulty],
          estimatedTimeSec: 25,
          status: 'active'
        });
      }
    }

    if (validQuestions.length === 0) {
      alert('Please fill out the question prompt and valid answers for at least one question.');
      return;
    }

    if (isEditingSingle && onQuestionUpdated) {
      onQuestionUpdated(validQuestions[0]);
    } else {
      onQuestionsAdded(validQuestions);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-yellow-400 text-slate-950 font-black flex items-center justify-center shadow-lg shadow-yellow-400/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white">
                {isEditingSingle ? 'Edit Question' : 'Add New Questions to Bank'}
              </h2>
              <p className="text-xs text-slate-400 font-semibold">
                {isEditingSingle ? 'Modify question content and settings' : 'Quickly compose single or multiple questions across 5 question types'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Settings Toolbar */}
        {!isEditingSingle && (
          <div className="px-6 py-3 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs font-bold">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-slate-400 uppercase tracking-wider">Default Category:</span>
                <select
                  value={globalCategory}
                  onChange={(e) => setGlobalCategory(e.target.value as Category)}
                  className="bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-1.5 focus:outline-none focus:border-yellow-400 font-semibold text-xs"
                >
                  {categories.map((cat, i) => (
                    <option key={i} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-slate-400 uppercase tracking-wider">Default Difficulty:</span>
                <select
                  value={globalDifficulty}
                  onChange={(e) => setGlobalDifficulty(e.target.value as Difficulty)}
                  className="bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-1.5 focus:outline-none focus:border-yellow-400 font-semibold text-xs"
                >
                  <option value="Easy">Easy</option>
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                </select>
              </div>
            </div>

            <div className="text-slate-400 text-xs font-semibold">
              Total items: <span className="text-yellow-400 font-black">{drafts.length}</span>
            </div>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {drafts.map((draft, dIdx) => {
            const badge = getQuestionTypeBadgeColor(draft.type);

            return (
              <div
                key={draft.id}
                className="bg-slate-950/80 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-5 shadow-xl relative"
              >
                {/* Draft Card Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center space-x-3">
                    <span className="w-7 h-7 rounded-xl bg-yellow-400 text-slate-950 flex items-center justify-center font-black text-xs">
                      #{dIdx + 1}
                    </span>
                    
                    {/* Question Type Selector */}
                    <div className="flex items-center space-x-2">
                      <select
                        value={draft.type}
                        onChange={(e) => handleUpdateDraft(dIdx, { type: e.target.value as QuestionType })}
                        className={`text-xs font-black rounded-xl px-3 py-1.5 border ${badge.bg} ${badge.text} ${badge.border} focus:outline-none`}
                      >
                        <option value="multiple_choice" className="bg-slate-900 text-white">Multiple Choice</option>
                        <option value="fastest_fingers" className="bg-slate-900 text-white">Fastest Fingers (Speed Challenge)</option>
                        <option value="fill_blank" className="bg-slate-900 text-white">Fill in the Blank</option>
                        <option value="ordering" className="bg-slate-900 text-white">Ordering / Ranking</option>
                        <option value="matching" className="bg-slate-900 text-white">Matching Pairs</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <select
                      value={draft.category}
                      onChange={(e) => handleUpdateDraft(dIdx, { category: e.target.value as Category })}
                      className="bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-2.5 py-1 text-xs font-bold"
                    >
                      {categories.map((cat, i) => (
                        <option key={i} value={cat}>{cat}</option>
                      ))}
                    </select>

                    <select
                      value={draft.difficulty}
                      onChange={(e) => handleUpdateDraft(dIdx, { difficulty: e.target.value as Difficulty })}
                      className="bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-2.5 py-1 text-xs font-bold"
                    >
                      <option value="Easy">Easy</option>
                      <option value="Medium">Medium</option>
                      <option value="Hard">Hard</option>
                    </select>

                    {!isEditingSingle && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleDuplicateDraft(dIdx)}
                          className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-all"
                          title="Duplicate question"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRemoveDraft(dIdx)}
                          className="p-1.5 hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 rounded-lg transition-all"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Question Prompt */}
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-slate-400 mb-1.5">
                    Question Prompt / Text
                  </label>
                  <textarea
                    rows={2}
                    value={draft.question}
                    onChange={(e) => handleUpdateDraft(dIdx, { question: e.target.value })}
                    placeholder={
                      draft.type === 'fill_blank'
                        ? 'e.g. In web architecture, CSS stands for Cascading ______ Sheets.'
                        : 'e.g. What is the primary purpose of creating a wireframe?'
                    }
                    className="w-full bg-slate-900 border border-slate-700 focus:border-yellow-400 rounded-2xl p-3 text-sm text-white font-bold placeholder-slate-500 focus:outline-none resize-none"
                    required
                  />
                </div>

                {/* TYPE-SPECIFIC ANSWER INPUT FIELDS */}

                {/* 1. Multiple Choice & Fastest Fingers: 4 Options */}
                {(draft.type === 'multiple_choice' || draft.type === 'fastest_fingers') && (
                  <div className="space-y-2.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-400">
                      Options & Correct Answer (Select radio button for correct answer)
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {draft.options.map((opt, optIdx) => {
                        const isCorrect = draft.correctAnswer === optIdx;
                        return (
                          <div
                            key={optIdx}
                            className={`p-3 rounded-2xl border flex items-center space-x-3 transition-all ${
                              isCorrect
                                ? 'bg-emerald-950/40 border-emerald-400 ring-2 ring-emerald-400/30'
                                : 'bg-slate-900 border-slate-700'
                            }`}
                          >
                            <input
                              type="radio"
                              name={`correct_${draft.id}`}
                              checked={isCorrect}
                              onChange={() => handleUpdateDraft(dIdx, { correctAnswer: optIdx as any })}
                              className="w-4 h-4 text-emerald-400 accent-emerald-400 cursor-pointer"
                            />
                            <span className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center flex-shrink-0">
                              {String.fromCharCode(65 + optIdx)}
                            </span>
                            <input
                              type="text"
                              value={opt}
                              onChange={(e) => handleOptionChange(dIdx, optIdx, e.target.value)}
                              placeholder={`Option ${String.fromCharCode(65 + optIdx)} text`}
                              className="flex-1 bg-transparent text-sm font-bold text-white placeholder-slate-500 focus:outline-none"
                              required
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 2. Fill in the Blank: Accepted Answers */}
                {draft.type === 'fill_blank' && (
                  <div className="space-y-2">
                    <label className="block text-xs font-black uppercase tracking-wider text-emerald-400">
                      Accepted Correct Answers (Comma-separated, case-insensitive)
                    </label>
                    <input
                      type="text"
                      value={draft.acceptedAnswersText}
                      onChange={(e) => handleUpdateDraft(dIdx, { acceptedAnswersText: e.target.value })}
                      placeholder="e.g. Style, style, Styles"
                      className="w-full bg-slate-900 border border-emerald-500/50 rounded-2xl p-3 text-sm text-white font-bold placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-400/30"
                      required
                    />
                    <p className="text-[11px] text-slate-400 font-medium">
                      Add all valid variations. Comparison ignores case and leading/trailing whitespace automatically.
                    </p>
                  </div>
                )}

                {/* 3. Ordering / Ranking: Ordered Sequence */}
                {draft.type === 'ordering' && (
                  <div className="space-y-2.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-cyan-400">
                      Sequence Items in Correct Chronological / Ranked Order (1st to Last)
                    </label>
                    <div className="space-y-2">
                      {draft.orderItems.map((item, itemIdx) => (
                        <div key={itemIdx} className="flex items-center space-x-3 p-2.5 bg-slate-900 border border-cyan-500/30 rounded-2xl">
                          <span className="w-7 h-7 rounded-xl bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center flex-shrink-0">
                            {itemIdx + 1}
                          </span>
                          <input
                            type="text"
                            value={item}
                            onChange={(e) => handleOrderItemChange(dIdx, itemIdx, e.target.value)}
                            placeholder={`Step ${itemIdx + 1} / Item text`}
                            className="flex-1 bg-transparent text-sm font-bold text-white placeholder-slate-500 focus:outline-none"
                            required
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4. Matching: Left & Right Pairs */}
                {draft.type === 'matching' && (
                  <div className="space-y-2.5">
                    <label className="block text-xs font-black uppercase tracking-wider text-purple-400">
                      Matching Pairs (Term / Definition)
                    </label>
                    <div className="space-y-2">
                      {draft.matchingPairs.map((pair, pairIdx) => (
                        <div key={pairIdx} className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-900 border border-purple-500/30 rounded-2xl">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-black text-slate-400">#{pairIdx + 1} Left:</span>
                            <input
                              type="text"
                              value={pair.left}
                              onChange={(e) => handleMatchingPairChange(dIdx, pairIdx, 'left', e.target.value)}
                              placeholder="e.g. JavaScript"
                              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs font-bold text-white focus:outline-none"
                              required
                            />
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-black text-purple-400">Right:</span>
                            <input
                              type="text"
                              value={pair.right}
                              onChange={(e) => handleMatchingPairChange(dIdx, pairIdx, 'right', e.target.value)}
                              placeholder="e.g. Brendan Eich"
                              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs font-bold text-white focus:outline-none"
                              required
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Explanation */}
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">
                    Explanation / Solution Notes (Optional)
                  </label>
                  <input
                    type="text"
                    value={draft.explanation}
                    onChange={(e) => handleUpdateDraft(dIdx, { explanation: e.target.value })}
                    placeholder="Provide a brief explanation shown during answer reveal"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-semibold focus:outline-none focus:border-slate-600"
                  />
                </div>

              </div>
            );
          })}

          {/* Add Another Question Item Button */}
          {!isEditingSingle && (
            <button
              type="button"
              onClick={handleAddRepeaterQuestion}
              className="w-full py-4 border-2 border-dashed border-slate-700 hover:border-yellow-400 text-slate-400 hover:text-yellow-400 rounded-3xl font-black text-sm flex items-center justify-center space-x-2 transition-all hover:bg-yellow-400/5 active:scale-[0.99]"
            >
              <Plus className="w-5 h-5" />
              <span>+ ADD ANOTHER QUESTION TO FORM</span>
            </button>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-8 py-3 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-sm transition-all shadow-xl shadow-yellow-400/20 active:scale-95 flex items-center space-x-2"
            >
              <Check className="w-4 h-4" />
              <span>{isEditingSingle ? 'Save Changes' : `Save ${drafts.length} Question${drafts.length > 1 ? 's' : ''} to Bank`}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
