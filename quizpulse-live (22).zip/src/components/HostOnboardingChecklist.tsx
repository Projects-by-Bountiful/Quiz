import React, { useState, useEffect } from 'react';
import { CheckCircle2, Circle, ChevronDown, ChevronUp, Sparkles, X, HelpCircle, ArrowRight } from 'lucide-react';

interface HostOnboardingChecklistProps {
  questionsCount: number;
  categoriesCount: number;
  onNavigate: (view: string) => void;
  onCreateRoomClick?: () => void;
}

export const HostOnboardingChecklist: React.FC<HostOnboardingChecklistProps> = ({
  questionsCount,
  categoriesCount,
  onNavigate,
  onCreateRoomClick
}) => {
  const [isDismissed, setIsDismissed] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  useEffect(() => {
    const dismissed = localStorage.getItem('quizpulse_host_checklist_dismissed');
    if (dismissed === 'true') {
      setIsDismissed(true);
    }
  }, []);

  const handleDismiss = () => {
    setIsDismissed(true);
    localStorage.setItem('quizpulse_host_checklist_dismissed', 'true');
  };

  if (isDismissed) return null;

  const steps = [
    {
      id: 'questions',
      title: '1. Populate Your Question Bank',
      description: 'Add or import custom questions in multiple categories.',
      isDone: questionsCount > 0,
      actionText: 'Manage Questions',
      actionView: 'host_questions'
    },
    {
      id: 'categories',
      title: '2. Organize Categories',
      description: 'Group questions into Freelancing, Web Dev, AI, and custom topics.',
      isDone: categoriesCount > 3,
      actionText: 'View Categories',
      actionView: 'host_categories'
    },
    {
      id: 'settings',
      title: '3. Configure Game Settings',
      description: 'Set timers, sound controls, celebrations & feedback settings.',
      isDone: true,
      actionText: 'Game Settings',
      actionView: 'host_settings'
    },
    {
      id: 'room',
      title: '4. Launch a Live Room & Share Code',
      description: 'Generate a 6-character PIN and display the QR Code on projector/TV.',
      isDone: false,
      actionText: 'Launch Game',
      actionView: 'host_quizzes'
    },
    {
      id: 'analytics',
      title: '5. Review Post-Event Reports',
      description: 'Analyze accuracy, response speed, and participant feedback after sessions.',
      isDone: false,
      actionText: 'View History',
      actionView: 'host_history'
    }
  ];

  const completedCount = steps.filter(s => s.isDone).length;
  const progressPercent = Math.round((completedCount / steps.length) * 100);

  return (
    <div className="bg-gradient-to-r from-indigo-900/90 via-slate-900 to-indigo-950 border border-indigo-500/40 rounded-3xl p-6 shadow-2xl relative overflow-hidden my-6">
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-indigo-950">
        <div
          className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all duration-500"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-amber-400 text-indigo-950 rounded-2xl shadow">
            <Sparkles className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white flex items-center space-x-2">
              <span>Host Quick Onboarding Checklist</span>
              <span className="text-xs bg-amber-400/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-400/30 font-bold">
                {completedCount} of {steps.length} completed ({progressPercent}%)
              </span>
            </h3>
            <p className="text-xs text-indigo-200 mt-0.5">
              Follow these simple steps to host seamless, interactive quiz events.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-2 text-indigo-300 hover:text-white hover:bg-indigo-800/50 rounded-xl transition"
            title={isMinimized ? 'Expand Checklist' : 'Minimize Checklist'}
          >
            {isMinimized ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
          </button>
          <button
            onClick={handleDismiss}
            className="p-2 text-indigo-400 hover:text-rose-300 hover:bg-rose-500/20 rounded-xl transition"
            title="Dismiss Checklist"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {steps.map(step => (
            <div
              key={step.id}
              className={`p-4 rounded-2xl border transition-all ${
                step.isDone
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-100'
                  : 'bg-indigo-950/60 border-indigo-500/20 text-indigo-100 hover:border-indigo-400/40'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2.5">
                  {step.isDone ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <Circle className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                  )}
                  <h4 className="text-sm font-bold">{step.title}</h4>
                </div>
              </div>
              <p className="text-xs text-indigo-200/80 mt-2 leading-relaxed">
                {step.description}
              </p>
              <div className="mt-3 flex justify-end">
                <button
                  onClick={() => {
                    if (step.id === 'room' && onCreateRoomClick) {
                      onCreateRoomClick();
                    } else {
                      onNavigate(step.actionView);
                    }
                  }}
                  className="text-xs font-bold text-amber-300 hover:text-amber-200 flex items-center space-x-1 hover:underline"
                >
                  <span>{step.actionText}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
