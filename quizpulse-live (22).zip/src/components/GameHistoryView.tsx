import React, { useState } from 'react';
import { History, Download, Trophy, Users, Eye, Trash2, X, CheckCircle2, HelpCircle, Award, Target, Clock, Zap, AlertTriangle, FileText, BarChart3, Star } from 'lucide-react';
import { GameHistoryRecord, Participant } from '../types';
import { exportResultsToCSV } from '../utils/csv';
import { deleteGameResultFromSupabase } from '../lib/supabaseService';
import { calculateParticipantStats } from '../utils/stats';
import { PostEventReportModal } from './PostEventReportModal';

interface GameHistoryViewProps {
  history?: GameHistoryRecord[];
  records?: GameHistoryRecord[];
  onRefreshHistory?: () => void;
  onDeleteRecord?: (id: string) => void;
}

export const GameHistoryView: React.FC<GameHistoryViewProps> = ({
  history,
  records,
  onRefreshHistory,
  onDeleteRecord
}) => {
  const initialData = history || records || [];
  const [localHistory, setLocalHistory] = useState<GameHistoryRecord[]>(initialData);
  const [selectedRecord, setSelectedRecord] = useState<GameHistoryRecord | null>(null);
  const [reportRecord, setReportRecord] = useState<GameHistoryRecord | null>(null);
  const [deleteRecordId, setDeleteRecordId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Sync with prop safely when history or records changes
  React.useEffect(() => {
    const incoming = history || records;
    if (incoming) {
      setLocalHistory(prev => {
        if (
          prev.length === incoming.length &&
          prev.every((rec, i) => rec.id === incoming[i]?.id)
        ) {
          return prev;
        }
        return incoming;
      });
    }
  }, [history, records]);

  const handleExportHistoryCSV = (rec: GameHistoryRecord) => {
    if (rec.fullSession) {
      const pList = Object.values(rec.fullSession.participants || {}) as Participant[];
      exportResultsToCSV(rec.title, pList, rec.fullSession.questions.length);
      return;
    }

    const formattedParticipants = (rec.participants || []).map(p => ({
      id: p.name,
      name: p.name,
      avatar: '🎮',
      score: p.score,
      streak: 0,
      correctCount: p.correctCount,
      totalResponseTime: p.avgTime * p.correctCount,
      answers: {},
      joinedAt: 0,
      isOnline: false
    }));
    exportResultsToCSV(rec.title, formattedParticipants as any, rec.totalQuestions);
  };

  const handleDeleteConfirm = async () => {
    if (!deleteRecordId) return;
    setIsDeleting(true);

    await deleteGameResultFromSupabase(deleteRecordId);
    
    setLocalHistory(prev => prev.filter(h => h.id !== deleteRecordId));
    if (selectedRecord?.id === deleteRecordId) {
      setSelectedRecord(null);
    }
    setDeleteRecordId(null);
    setIsDeleting(false);

    if (onRefreshHistory) {
      onRefreshHistory();
    }
  };

  return (
    <div className="w-full space-y-6 min-w-0">
      
      {/* Header */}
      <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl">
        <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center space-x-3">
          <div className="p-2.5 bg-amber-400 text-indigo-950 rounded-2xl shadow">
            <History className="w-6 h-6 stroke-[2.5]" />
          </div>
          <span>Game Session History</span>
        </h1>
        <p className="text-xs text-indigo-200 mt-2 font-semibold">
          Review past quiz events, participant performance, question breakdowns, and export CSV reports
        </p>
      </div>

      {/* History List */}
      {localHistory.length === 0 ? (
        <div className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-12 text-center text-indigo-300 shadow-2xl">
          <History className="w-12 h-12 stroke-1 mx-auto mb-2 text-indigo-400" />
          <p className="text-base font-bold">No game history available yet.</p>
          <p className="text-xs text-indigo-200 mt-1">Start and finish a live quiz session to see logs and analytics here!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {localHistory.map((rec) => (
            <div
              key={rec.id}
              className="bg-indigo-900/60 border border-indigo-500/30 rounded-3xl p-4 sm:p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 md:gap-6 hover:border-indigo-400/50 transition-all min-w-0"
            >
              <div className="space-y-2 min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
                    {rec.date}
                  </span>
                  <span className="text-xs text-indigo-200 font-bold uppercase tracking-wider truncate max-w-[180px]">{rec.category}</span>
                </div>
                <h3 className="text-lg sm:text-xl font-black text-white break-words">{rec.title}</h3>
                <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-xs text-indigo-200 font-semibold">
                  <span className="flex items-center space-x-1">
                    <Users className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span>{rec.totalParticipants} Players</span>
                  </span>
                  <span>•</span>
                  <span>{rec.totalQuestions} Questions</span>
                  <span>•</span>
                  <span className="text-emerald-400 font-bold">{rec.averageAccuracy}% Accuracy</span>
                </div>
              </div>

              {/* Winner & Actions */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between md:justify-end gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-indigo-700/50 min-w-0">
                <div className="flex items-center justify-between sm:block text-left sm:text-right bg-indigo-950/60 sm:bg-transparent p-2.5 sm:p-0 rounded-2xl border sm:border-0 border-indigo-700/40">
                  <span className="text-[10px] text-amber-400 font-black uppercase tracking-widest block">Winner</span>
                  <div className="text-right">
                    <p className="text-sm sm:text-base font-black text-white flex items-center justify-end space-x-1 truncate max-w-[180px]">
                      <Trophy className="w-4 h-4 text-amber-400 fill-current flex-shrink-0" />
                      <span className="truncate">{rec.winnerName}</span>
                    </p>
                    <span className="text-xs text-indigo-300 font-mono font-bold block">{rec.winnerScore} pts</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:flex sm:items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => setReportRecord(rec)}
                    className="px-3 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center space-x-1.5 transition-all shadow"
                    title="View Comprehensive Post-Event Analytics Report"
                  >
                    <BarChart3 className="w-4 h-4 flex-shrink-0" />
                    <span>Report</span>
                  </button>

                  <button
                    onClick={() => setSelectedRecord(rec)}
                    className="px-3 py-2.5 bg-indigo-800 hover:bg-indigo-700 text-indigo-100 font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center space-x-1.5 transition-all border border-indigo-600/50"
                    title="View Complete Session Details"
                  >
                    <Eye className="w-4 h-4 flex-shrink-0" />
                    <span>Details</span>
                  </button>

                  <button
                    onClick={() => handleExportHistoryCSV(rec)}
                    className="px-3 py-2.5 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center space-x-1.5 transition-all shadow-md"
                    title="Export CSV Report"
                  >
                    <Download className="w-4 h-4 stroke-[2.5] flex-shrink-0" />
                    <span>Export</span>
                  </button>

                  <button
                    onClick={() => setDeleteRecordId(rec.id)}
                    className="px-3 py-2.5 bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white font-black text-xs rounded-xl transition-all border border-rose-500/30 flex items-center justify-center space-x-1.5"
                    title="Delete Session Record"
                  >
                    <Trash2 className="w-4 h-4 flex-shrink-0" />
                    <span className="sm:hidden">Delete</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SESSION DETAILS MODAL */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-indigo-950 border border-amber-400/50 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 shadow-2xl text-white relative">
            
            <button
              onClick={() => setSelectedRecord(null)}
              className="absolute top-5 right-5 p-2 bg-indigo-900 hover:bg-indigo-800 text-indigo-200 hover:text-white rounded-full transition-all"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="space-y-2 pr-8">
              <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold inline-block">
                {selectedRecord.date} • {selectedRecord.category}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white">{selectedRecord.title}</h2>
            </div>

            {/* Overview Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-indigo-900/60 border border-indigo-700/50 rounded-2xl p-3 text-center">
                <Users className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                <p className="text-[10px] text-indigo-300 font-bold uppercase">Participants</p>
                <p className="text-xl font-black text-white mt-0.5">{selectedRecord.totalParticipants}</p>
              </div>

              <div className="bg-indigo-900/60 border border-indigo-700/50 rounded-2xl p-3 text-center">
                <HelpCircle className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
                <p className="text-[10px] text-indigo-300 font-bold uppercase">Questions</p>
                <p className="text-xl font-black text-white mt-0.5">{selectedRecord.totalQuestions}</p>
              </div>

              <div className="bg-indigo-900/60 border border-indigo-700/50 rounded-2xl p-3 text-center">
                <Trophy className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                <p className="text-[10px] text-indigo-300 font-bold uppercase">Top Winner</p>
                <p className="text-lg font-black text-amber-400 truncate mt-0.5">{selectedRecord.winnerName}</p>
              </div>

              <div className="bg-indigo-900/60 border border-indigo-700/50 rounded-2xl p-3 text-center">
                <Target className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                <p className="text-[10px] text-indigo-300 font-bold uppercase">Avg Accuracy</p>
                <p className="text-xl font-black text-emerald-400 mt-0.5">{selectedRecord.averageAccuracy}%</p>
              </div>
            </div>

            {/* Leaderboard Table */}
            <div className="bg-indigo-900/40 border border-indigo-700/50 rounded-2xl p-4 space-y-3">
              <h3 className="text-sm font-black text-white flex items-center space-x-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span>Final Leaderboard & Participant Breakdown</span>
              </h3>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {(selectedRecord.fullSession ? Object.values(selectedRecord.fullSession.participants || {}) : selectedRecord.participants).map((p: any, idx) => {
                  let rank = p.rank || idx + 1;
                  let score = p.score || 0;
                  let correctCount = p.correctCount || 0;
                  let totalQ = selectedRecord.totalQuestions || 10;
                  let accuracy = p.accuracy !== undefined ? p.accuracy : (totalQ > 0 ? Math.round((correctCount / totalQ) * 100) : 0);
                  let avgTime = p.avgTime || p.averageResponseTime || (p.totalResponseTime && correctCount > 0 ? Number((p.totalResponseTime / correctCount).toFixed(1)) : 0);
                  let avatar = p.avatar || '⚡';
                  let name = p.name || 'Participant';

                  if (selectedRecord.fullSession && p.answers && Object.keys(p.answers).length > 0) {
                    const stats = calculateParticipantStats(p as Participant, totalQ, Object.values(selectedRecord.fullSession.participants || {}));
                    rank = stats.finalRank;
                    score = stats.score;
                    correctCount = stats.correctAnswers;
                    accuracy = stats.accuracy;
                    avgTime = stats.averageResponseTime;
                  }

                  return (
                    <div key={p.id ? `${p.id}-${idx}` : `hist-p-${p.name || idx}-${idx}`} className="flex items-center justify-between p-3 bg-indigo-950/80 rounded-xl border border-indigo-800 text-xs">
                      <div className="flex items-center space-x-3">
                        <span className="w-6 h-6 rounded-lg bg-amber-400 text-indigo-950 font-black flex items-center justify-center">
                          #{rank}
                        </span>
                        <span className="text-base">{avatar}</span>
                        <div>
                          <p className="font-bold text-white text-sm">{name}</p>
                          <p className="text-[10px] text-indigo-300 font-semibold">
                            {correctCount}/{totalQ} Correct ({accuracy}% Accuracy)
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-black text-amber-400 text-sm">{score} pts</p>
                        <p className="text-[10px] text-indigo-300 font-semibold">{avgTime > 0 ? `Avg: ${avgTime}s` : ''}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Question Breakdown (If available) */}
            {(selectedRecord.fullSession?.questions || selectedRecord.questions) && (
              <div className="bg-indigo-900/40 border border-indigo-700/50 rounded-2xl p-4 space-y-3">
                <h3 className="text-sm font-black text-white flex items-center space-x-2">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>Question-by-Question Breakdown</span>
                </h3>

                <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                  {(selectedRecord.fullSession?.questions || selectedRecord.questions || []).map((q, qIdx) => (
                    <div key={q.id || qIdx} className="bg-indigo-950/80 border border-indigo-800 rounded-xl p-3.5 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 bg-indigo-800 text-amber-300 font-black text-[10px] rounded">
                          Q{qIdx + 1}
                        </span>
                        <span className="text-[10px] text-indigo-300 font-semibold">{q.category} • {q.difficulty}</span>
                      </div>
                      <p className="font-bold text-white text-sm">{q.question}</p>
                      <div className="grid grid-cols-2 gap-1.5 pt-1">
                        {q.options.map((opt, optIdx) => (
                          <div
                            key={optIdx}
                            className={`p-2 rounded-lg font-semibold flex items-center justify-between text-[11px] ${
                              optIdx === q.correctAnswer
                                ? 'bg-emerald-500/20 border border-emerald-500/50 text-emerald-300'
                                : 'bg-indigo-900/50 text-indigo-300'
                            }`}
                          >
                            <span>{['A', 'B', 'C', 'D'][optIdx]}. {opt}</span>
                            {optIdx === q.correctAnswer && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Footer */}
            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={() => handleExportHistoryCSV(selectedRecord)}
                className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-indigo-950 font-black text-xs uppercase tracking-wider rounded-xl flex items-center space-x-2 shadow"
              >
                <Download className="w-4 h-4" />
                <span>Export CSV Report</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteRecordId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-indigo-950 border border-rose-500/50 rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl text-white">
            <div className="w-12 h-12 bg-rose-500/20 text-rose-400 rounded-2xl mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-xl font-black text-white">Delete Completed Session?</h3>
            <p className="text-xs text-indigo-200 font-medium">
              Are you sure you want to permanently delete this session record from history? This action cannot be undone.
            </p>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteRecordId(null)}
                disabled={isDeleting}
                className="px-5 py-2.5 bg-indigo-900 hover:bg-indigo-800 text-indigo-200 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>

              <button
                onClick={handleDeleteConfirm}
                disabled={isDeleting}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase tracking-wider rounded-xl flex items-center space-x-2 shadow-lg"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeleting ? 'Deleting...' : 'Confirm Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POST EVENT REPORT MODAL */}
      {reportRecord && (
        <PostEventReportModal
          historyRecord={reportRecord}
          onClose={() => setReportRecord(null)}
        />
      )}

    </div>
  );
};

