import React, { useState, useEffect } from 'react';
import { 
  Zap, X, Check, Search, Layers, Clock, Shield, ArrowRight, ArrowLeft, 
  Play, Save, Eye, Sparkles, Filter, HelpCircle, Loader2, CheckCircle2, Bookmark,
  AlertTriangle, ListOrdered, ArrowRightLeft, CreditCard, Users, ShieldAlert,
  Gift, RefreshCw
} from 'lucide-react';
import { Category, Question, SessionSettings, QuestionType } from '../types';
import { ParticipantQuestionPreviewModal } from './ParticipantQuestionPreviewModal';
import { getQuestionTypeBadgeColor, getQuestionTypeLabel } from '../utils/questionEngine';
import { 
  calculateGamePrice, formatPrice, MAX_SUPPORTED_PLAYERS, 
  ALLOWED_CAPACITY_PRESETS, PRICING_TIERS 
} from '../config/pricingConfig';
import { MockPaymentModal } from './MockPaymentModal';
import { paymentService } from '../services/payment/paymentService';
import { PaymentInitResult, PaymentVerificationResult, GameEntitlement } from '../services/payment/types';
import { useAuth } from '../context/AuthContext';

export interface QuizTemplate {
  id: string;
  name: string;
  description: string;
  title: string;
  timerDurationSec: number;
  questionCount: number;
  isRandom: boolean;
  enableBonusSpeedPoints: boolean;
  allowAnswerChange: boolean;
  showCorrectAnswer: boolean;
  enableLeaderboard: boolean;
  categories: Category[];
  selectedQuestionIds?: string[];
  createdAt: number;
}

interface QuizCreationWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateSession: (title: string, settings: Partial<SessionSettings>, selectedQuestionIds?: string[]) => Promise<any> | void;
  availableCategories: Category[];
  allQuestions: Question[];
  initialSelectedQuestionIds?: string[];
  initialCategory?: Category | null;
  onSaveTemplate?: (template: QuizTemplate) => void;
}

export const QuizCreationWizardModal: React.FC<QuizCreationWizardModalProps> = ({
  isOpen,
  onClose,
  onCreateSession,
  availableCategories = [],
  allQuestions = [],
  initialSelectedQuestionIds = [],
  initialCategory = null,
  onSaveTemplate
}) => {
  const { user, profile } = useAuth();
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);

  // Step 1 State: Event Info, Question Mode & Selection
  const [title, setTitle] = useState('QuizPulse Live Event');
  const [questionMode, setQuestionMode] = useState<'mixed' | QuestionType>('mixed');
  const [activeTab, setActiveTab] = useState<'auto' | 'manual'>('auto');
  const [selectedCategories, setSelectedCategories] = useState<Category[]>([]);
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<string[]>(initialSelectedQuestionIds);
  const [searchFilter, setSearchFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Step 2 State: Timing, Rules & Capacity
  const [timerDurationSec, setTimerDurationSec] = useState<number>(20);
  const [maxParticipants, setMaxParticipants] = useState<number>(5); // Default to free tier
  const [isRandom, setIsRandom] = useState<boolean>(true);
  const [enableBonusSpeedPoints, setEnableBonusSpeedPoints] = useState<boolean>(true);
  const [allowAnswerChange, setAllowAnswerChange] = useState<boolean>(false);
  const [showCorrectAnswer, setShowCorrectAnswer] = useState<boolean>(true);
  const [enableLeaderboard, setEnableLeaderboard] = useState<boolean>(true);

  // Template Save State
  const [templateName, setTemplateName] = useState('');
  const [isSavingTemplate, setIsSavingTemplate] = useState(false);
  const [templateSavedSuccess, setTemplateSavedSuccess] = useState(false);

  // Preview Overlay State
  const [previewQuestion, setPreviewQuestion] = useState<Question | null>(null);

  // Validation & Error State
  const [validationError, setValidationError] = useState<string | null>(null);

  // Payment & Checkout State
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentInitData, setPaymentInitData] = useState<PaymentInitResult | null>(null);
  const [paidEntitlement, setPaidEntitlement] = useState<GameEntitlement | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [roomCreationError, setRoomCreationError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      if (initialCategory) {
        setSelectedCategories([initialCategory]);
        setTitle(`${initialCategory} Quiz Challenge`);
      }
      if (initialSelectedQuestionIds && initialSelectedQuestionIds.length > 0) {
        setSelectedQuestionIds(initialSelectedQuestionIds);
        setActiveTab('manual');
        setTitle(`Hand-Picked Quiz (${initialSelectedQuestionIds.length} Questions)`);
      }
    }
  }, [initialCategory, initialSelectedQuestionIds?.join(','), isOpen]);

  if (!isOpen) return null;

  // Real-time authoritative price calculation
  const priceInfo = calculateGamePrice(maxParticipants);

  // Filter questions according to questionMode (Mixed vs Dedicated Single Type)
  const modeFilteredQuestions = allQuestions.filter(q => {
    if (questionMode === 'mixed') return true;
    const qType = q.type || 'multiple_choice';
    return qType === questionMode;
  });

  // Category & Search Filters on top of modeFilteredQuestions
  let filteredQuestions = modeFilteredQuestions;
  if (categoryFilter !== 'ALL') {
    filteredQuestions = filteredQuestions.filter(q => q.category === categoryFilter);
  }
  if (searchFilter.trim()) {
    const qTerm = searchFilter.toLowerCase();
    filteredQuestions = filteredQuestions.filter(q =>
      q.question.toLowerCase().includes(qTerm) ||
      q.category.toLowerCase().includes(qTerm)
    );
  }

  let autoPool = modeFilteredQuestions;
  if (selectedCategories.length > 0) {
    autoPool = autoPool.filter(q => selectedCategories.includes(q.category));
  }

  const effectiveCount = activeTab === 'manual'
    ? selectedQuestionIds.length
    : Math.min(questionCount, autoPool.length > 0 ? autoPool.length : modeFilteredQuestions.length);

  const toggleCategory = (cat: Category) => {
    if (selectedCategories.includes(cat)) {
      setSelectedCategories(selectedCategories.filter(c => c !== cat));
    } else {
      setSelectedCategories([...selectedCategories, cat]);
    }
  };

  const toggleSelectQuestion = (qId: string) => {
    if (selectedQuestionIds.includes(qId)) {
      setSelectedQuestionIds(selectedQuestionIds.filter(id => id !== qId));
    } else {
      setSelectedQuestionIds([...selectedQuestionIds, qId]);
    }
  };

  const handleSaveCustomTemplate = () => {
    if (!templateName.trim()) return;
    setIsSavingTemplate(true);

    const newTemplate: QuizTemplate = {
      id: `tmpl_${Date.now()}`,
      name: templateName.trim(),
      description: `${effectiveCount} Qs • ${questionMode === 'mixed' ? 'Mixed Types' : getQuestionTypeLabel(questionMode as QuestionType)} • ${timerDurationSec}s timer • ${maxParticipants}p max`,
      title,
      timerDurationSec,
      questionCount: effectiveCount,
      isRandom,
      enableBonusSpeedPoints,
      allowAnswerChange,
      showCorrectAnswer,
      enableLeaderboard,
      categories: selectedCategories,
      selectedQuestionIds: activeTab === 'manual' ? selectedQuestionIds : undefined,
      createdAt: Date.now()
    };

    if (onSaveTemplate) {
      onSaveTemplate(newTemplate);
    } else {
      try {
        const saved = JSON.parse(localStorage.getItem('quizpulse_saved_templates') || '[]');
        localStorage.setItem('quizpulse_saved_templates', JSON.stringify([...saved, newTemplate]));
      } catch (e) {}
    }

    setTemplateSavedSuccess(true);
    setIsSavingTemplate(false);
    setTimeout(() => setTemplateSavedSuccess(false), 3000);
  };

  // Pre-launch validation
  const validateBeforeLaunch = (): boolean => {
    setValidationError(null);
    setRoomCreationError(null);

    if (!title.trim()) {
      setValidationError('Please provide a quiz title.');
      return false;
    }

    if (maxParticipants > MAX_SUPPORTED_PLAYERS) {
      setValidationError(`Maximum capacity is currently ${MAX_SUPPORTED_PLAYERS} players.`);
      return false;
    }

    if (maxParticipants < 1) {
      setValidationError('Please specify a valid participant capacity.');
      return false;
    }

    if (effectiveCount === 0) {
      setValidationError('No questions available in the selected pool. Please select questions or change filters.');
      return false;
    }

    // Check questions for structural validity
    let questionsToValidate: Question[] = [];
    if (activeTab === 'manual') {
      questionsToValidate = allQuestions.filter(q => selectedQuestionIds.includes(q.id));
    } else {
      questionsToValidate = autoPool.slice(0, effectiveCount);
    }

    for (const q of questionsToValidate) {
      const qType = q.type || 'multiple_choice';
      if (!q.question || q.question.trim().length === 0) {
        setValidationError(`One of your questions is missing question text.`);
        return false;
      }
      if ((qType === 'multiple_choice' || qType === 'fastest_fingers') && (!q.options || q.options.length < 2)) {
        setValidationError(`Question "${q.question.substring(0, 30)}..." must have at least 2 answer choices.`);
        return false;
      }
      if (qType === 'fill_blank' && (!q.acceptedAnswers || q.acceptedAnswers.length === 0) && (!q.options || q.options.length === 0)) {
        setValidationError(`Fill in the blank question "${q.question.substring(0, 30)}..." is missing accepted answers.`);
        return false;
      }
      if (qType === 'ordering' && (!q.orderItems || q.orderItems.length < 2) && (!q.options || q.options.length < 2)) {
        setValidationError(`Ordering question "${q.question.substring(0, 30)}..." must have at least 2 sequence items.`);
        return false;
      }
      if (qType === 'matching' && (!q.matchingPairs || q.matchingPairs.length < 2)) {
        setValidationError(`Matching question "${q.question.substring(0, 30)}..." must have at least 2 matching pairs.`);
        return false;
      }
    }

    return true;
  };

  /**
   * Final room creation trigger.
   * Ensures paid sessions carry entitlement metadata and enforces player capacity.
   */
  const executeRoomCreation = async (entitlement?: GameEntitlement | null) => {
    setIsSubmitting(true);
    setRoomCreationError(null);

    const hostId = user?.id || profile?.id || 'host_default';

    // Verify entitlement if paid game (> 5 players)
    if (maxParticipants > 5) {
      const entitlementCheck = await paymentService.validateEntitlementForLaunch(
        hostId,
        maxParticipants,
        entitlement?.id || paidEntitlement?.id
      );

      if (!entitlementCheck.valid) {
        setIsSubmitting(false);
        setValidationError(entitlementCheck.error || 'Payment verification required before launching a paid live game.');
        return;
      }
    }

    const sessionSettingsPayload: Partial<SessionSettings> = {
      categories: activeTab === 'manual' ? [] : selectedCategories,
      questionCount: effectiveCount,
      timerDurationSec,
      isRandom,
      enableBonusSpeedPoints,
      allowAnswerChange,
      showCorrectAnswer,
      enableLeaderboard,
      enableSoundEffects: true,
      maxParticipants: Math.min(maxParticipants, MAX_SUPPORTED_PLAYERS)
    };

    try {
      let poolIds: string[] | undefined;
      if (activeTab === 'manual' && selectedQuestionIds.length > 0) {
        poolIds = selectedQuestionIds;
      } else if (questionMode !== 'mixed') {
        poolIds = autoPool.map(q => q.id).slice(0, effectiveCount);
      }

      await onCreateSession(title, sessionSettingsPayload, poolIds);

      // If paid game, mark entitlement used
      const activeEntitlementId = entitlement?.id || paidEntitlement?.id;
      if (activeEntitlementId) {
        await paymentService.markEntitlementUsed(activeEntitlementId, 'LIVE_SESSION');
      }

      onClose();
    } catch (err: any) {
      console.error('Room creation error in wizard:', err);
      if (maxParticipants > 5) {
        // Required resilient message to prevent double billing
        setRoomCreationError(
          "Payment received, but we couldn't prepare your game. Your payment has been recorded and the game can be recovered without charging you again."
        );
      } else {
        setRoomCreationError(err?.message || 'Failed to initialize live quiz room.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Primary button handler on Step 3
   */
  const handleProceedToLaunchOrPayment = async () => {
    if (!validateBeforeLaunch()) return;

    // Free Tier (0–5 players) -> Bypasses payment completely
    if (priceInfo.isFree || maxParticipants <= 5) {
      await executeRoomCreation(null);
      return;
    }

    // Paid Tier (> 5 players) -> Initialize payment flow
    setIsSubmitting(true);
    try {
      const hostId = user?.id || profile?.id || 'host_default';
      const hostEmail = user?.email || profile?.email || '';

      const initResult = await paymentService.initializeGamePayment({
        hostId,
        hostEmail,
        quizTitle: title,
        playerCapacity: maxParticipants
      });

      setPaymentInitData(initResult);
      setIsPaymentModalOpen(true);
    } catch (err: any) {
      setValidationError(err?.message || 'Failed to initialize payment checkout.');
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Callback when Mock Payment succeeds
   */
  const handlePaymentSuccess = async (
    verification: PaymentVerificationResult,
    entitlement?: GameEntitlement
  ) => {
    setIsPaymentModalOpen(false);
    if (entitlement) {
      setPaidEntitlement(entitlement);
    }
    await executeRoomCreation(entitlement);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl p-6 sm:p-8 shadow-2xl relative space-y-6 my-4">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Wizard Header */}
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-yellow-400/20 flex-shrink-0">
            <Zap className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">Quiz Creation Wizard</h2>
            <p className="text-xs text-slate-400 font-semibold">
              Step {currentStep} of 3: {
                currentStep === 1 ? 'Game Mode, Title & Questions' :
                currentStep === 2 ? 'Capacity, Rules & Pricing' :
                'Review & Checkout'
              }
            </p>
          </div>
        </div>

        {/* Stepper Progress Bar */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { step: 1, label: '1. Questions & Mode' },
            { step: 2, label: '2. Capacity & Rules' },
            { step: 3, label: '3. Review & Launch' }
          ].map((s) => {
            const isActive = currentStep === s.step;
            const isPassed = currentStep > s.step;

            return (
              <button
                key={s.step}
                onClick={() => {
                  if (s.step < currentStep || (s.step === 2 && effectiveCount > 0)) {
                    setCurrentStep(s.step as any);
                  }
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold text-center border transition-all flex items-center justify-center space-x-1.5 ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 border-amber-300 font-black shadow-md'
                    : isPassed
                    ? 'bg-indigo-900/60 text-indigo-200 border-indigo-700/50'
                    : 'bg-slate-950 text-slate-500 border-slate-800'
                }`}
              >
                {isPassed ? <Check className="w-3.5 h-3.5" /> : null}
                <span>{s.label}</span>
              </button>
            );
          })}
        </div>

        {/* Validation Error Toast */}
        {validationError && (
          <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded-xl text-rose-300 text-xs font-bold flex items-center space-x-2 animate-shake">
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Room Creation Resilient Error Recovery Banner */}
        {roomCreationError && (
          <div className="p-4 bg-amber-500/15 border border-amber-500/50 rounded-2xl text-amber-200 text-xs space-y-2">
            <div className="flex items-start space-x-2.5">
              <ShieldAlert className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="font-semibold leading-relaxed">{roomCreationError}</p>
            </div>
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => executeRoomCreation(paidEntitlement)}
                disabled={isSubmitting}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow flex items-center space-x-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSubmitting ? 'animate-spin' : ''}`} />
                <span>Retry Room Launch</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 1: Questions, Mode & Title */}
        {currentStep === 1 && (
          <div className="space-y-5 text-sm">
            {/* Event Title */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Quiz Event Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Freelancer Community Friday Trivia"
                className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-2xl text-white font-extrabold focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Question Type Mode Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Select Question Format
                </label>
                <span className="text-[11px] text-amber-400 font-bold">
                  {modeFilteredQuestions.length} Questions Available
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setQuestionMode('mixed')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    questionMode === 'mixed'
                      ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black text-white">Mixed Types</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Combine all question types</p>
                </button>

                <button
                  type="button"
                  onClick={() => setQuestionMode('fastest_fingers')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    questionMode === 'fastest_fingers'
                      ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black text-white">Fastest Fingers</span>
                  </div>
                  <p className="text-[10px] text-slate-400">2-choice rapid duel</p>
                </button>

                <button
                  type="button"
                  onClick={() => setQuestionMode('multiple_choice')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    questionMode === 'multiple_choice'
                      ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black text-white">Multiple Choice</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Standard 4 options</p>
                </button>

                <button
                  type="button"
                  onClick={() => setQuestionMode('fill_blank')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    questionMode === 'fill_blank'
                      ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <HelpCircle className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black text-white">Fill in Blank</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Direct text answers</p>
                </button>

                <button
                  type="button"
                  onClick={() => setQuestionMode('ordering')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    questionMode === 'ordering'
                      ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <ListOrdered className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black text-white">Ordering</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Sequential sorting</p>
                </button>

                <button
                  type="button"
                  onClick={() => setQuestionMode('matching')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    questionMode === 'matching'
                      ? 'bg-amber-400/15 border-amber-400 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <ArrowRightLeft className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-black text-white">Matching</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Pair items together</p>
                </button>
              </div>
            </div>

            {/* Question Sourcing Tabs */}
            <div className="space-y-3">
              <div className="flex space-x-2 border-b border-slate-800 pb-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('auto')}
                  className={`pb-2 px-3 text-xs font-bold transition-all border-b-2 ${
                    activeTab === 'auto'
                      ? 'border-amber-400 text-amber-400 font-black'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Auto-Select by Categories
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('manual')}
                  className={`pb-2 px-3 text-xs font-bold transition-all border-b-2 ${
                    activeTab === 'manual'
                      ? 'border-amber-400 text-amber-400 font-black'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Hand-Pick Questions ({selectedQuestionIds.length})
                </button>
              </div>

              {/* AUTO MODE */}
              {activeTab === 'auto' && (
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Filter by Categories (Leave empty for all)
                    </label>
                    <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto pr-1">
                      {availableCategories.map((cat) => {
                        const isSelected = selectedCategories.includes(cat);
                        return (
                          <button
                            type="button"
                            key={cat}
                            onClick={() => toggleCategory(cat)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                              isSelected
                                ? 'bg-amber-400 text-slate-950 shadow-md font-black'
                                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                            }`}
                          >
                            {cat}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Number of Questions
                    </label>
                    <div className="flex items-center space-x-3">
                      {[5, 10, 15, 20, 30].map((count) => (
                        <button
                          key={count}
                          type="button"
                          onClick={() => setQuestionCount(count)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                            questionCount === count
                              ? 'bg-amber-400 text-slate-950 font-black'
                              : 'bg-slate-900 text-slate-300 border border-slate-800'
                          }`}
                        >
                          {count} Qs
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* MANUAL MODE */}
              {activeTab === 'manual' && (
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="relative flex-1 min-w-[180px]">
                      <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                      <input
                        type="text"
                        placeholder="Search questions..."
                        value={searchFilter}
                        onChange={(e) => setSearchFilter(e.target.value)}
                        className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
                      />
                    </div>

                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="py-1.5 px-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 font-semibold"
                    >
                      <option value="ALL">All Categories</option>
                      {availableCategories.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => {
                        if (selectedQuestionIds.length === filteredQuestions.length) {
                          setSelectedQuestionIds([]);
                        } else {
                          setSelectedQuestionIds(filteredQuestions.map(q => q.id));
                        }
                      }}
                      className="text-xs text-amber-400 font-bold hover:underline"
                    >
                      {selectedQuestionIds.length === filteredQuestions.length ? 'Deselect All' : 'Select All Filtered'}
                    </button>
                  </div>

                  <div className="max-h-52 overflow-y-auto space-y-2 pr-1">
                    {filteredQuestions.map((q) => {
                      const isChecked = selectedQuestionIds.includes(q.id);
                      const qBadge = getQuestionTypeBadgeColor(q.type || 'multiple_choice');
                      return (
                        <div
                          key={q.id}
                          className={`p-2.5 rounded-xl border text-xs flex items-center justify-between transition-colors ${
                            isChecked
                              ? 'bg-amber-400/10 border-amber-400/60 text-white'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <div
                            onClick={() => toggleSelectQuestion(q.id)}
                            className="flex items-center space-x-3 cursor-pointer overflow-hidden pr-2 flex-1"
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {}}
                              className="w-4 h-4 accent-amber-400 rounded cursor-pointer flex-shrink-0"
                            />
                            <div className="truncate">
                              <div className="flex items-center space-x-2 mb-0.5">
                                <span className={`px-1.5 py-0.2 rounded text-[9px] font-black uppercase border ${qBadge.bg} ${qBadge.text} ${qBadge.border}`}>
                                  {getQuestionTypeLabel(q.type || 'multiple_choice')}
                                </span>
                                <span className="font-bold text-white truncate">{q.question}</span>
                              </div>
                              <span className="text-[10px] text-slate-500 font-semibold">{q.category} • {q.difficulty}</span>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => setPreviewQuestion(q)}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg text-[10px] font-bold flex items-center space-x-1 flex-shrink-0 ml-2"
                            title="Preview question view"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Preview</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-3 flex justify-between items-center border-t border-slate-800">
              <span className="text-xs text-amber-400 font-bold">
                Selected: {effectiveCount} Questions ({questionMode === 'mixed' ? 'Mixed' : getQuestionTypeLabel(questionMode as QuestionType)})
              </span>
              <button
                type="button"
                disabled={effectiveCount === 0}
                onClick={() => {
                  setValidationError(null);
                  setCurrentStep(2);
                }}
                className="py-3 px-6 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow flex items-center space-x-2"
              >
                <span>NEXT: CAPACITY & RULES</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Capacity, Pricing & Game Rules */}
        {currentStep === 2 && (
          <div className="space-y-5 text-sm">
            
            {/* CAPACITY SELECTOR & REAL-TIME PRICING BADGE */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <label className="block text-xs font-black text-white uppercase tracking-wider">
                    Maximum Player Capacity (Max {MAX_SUPPORTED_PLAYERS})
                  </label>
                  <p className="text-[11px] text-slate-400">
                    Pay-As-You-Go pricing calculates instantly based on your capacity limit.
                  </p>
                </div>
                
                {/* Live Real-time Price Summary Pill */}
                <div className="flex items-center space-x-2 bg-slate-900 border border-slate-700 px-3.5 py-1.5 rounded-xl self-start sm:self-auto">
                  <span className="text-xs font-bold text-slate-400">Game Price:</span>
                  <span className={`text-sm font-black ${priceInfo.isFree ? 'text-emerald-400' : 'text-yellow-400'}`}>
                    {priceInfo.formattedPrice}
                  </span>
                </div>
              </div>

              {/* Preset Capacity Selector Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {ALLOWED_CAPACITY_PRESETS.map((preset) => {
                  const isSelected = maxParticipants === preset;
                  const tierInfo = calculateGamePrice(preset);
                  return (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        setMaxParticipants(preset);
                        setValidationError(null);
                      }}
                      className={`p-3 rounded-2xl border text-center transition-all ${
                        isSelected
                          ? 'bg-amber-400 text-slate-950 border-amber-300 font-black shadow-lg shadow-amber-400/20'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-xs font-extrabold flex items-center justify-center space-x-1">
                        <Users className="w-3.5 h-3.5" />
                        <span>{preset} Players</span>
                      </div>
                      <div className={`text-[11px] mt-0.5 font-bold ${isSelected ? 'text-slate-950 font-black' : tierInfo.isFree ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {tierInfo.formattedPrice}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Custom Number Input Support */}
              <div className="pt-2 border-t border-slate-900 flex items-center justify-between gap-4">
                <span className="text-xs text-slate-400 font-semibold">
                  Or enter custom player limit (1–{MAX_SUPPORTED_PLAYERS}):
                </span>
                <input
                  type="number"
                  min={1}
                  max={MAX_SUPPORTED_PLAYERS}
                  value={maxParticipants}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setMaxParticipants(val);
                    if (val > MAX_SUPPORTED_PLAYERS) {
                      setValidationError(`Maximum capacity is currently ${MAX_SUPPORTED_PLAYERS} players.`);
                    } else {
                      setValidationError(null);
                    }
                  }}
                  className="w-24 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-center text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Dynamic Instant Price Box */}
              <div className={`p-3.5 rounded-xl border flex items-center justify-between text-xs ${
                priceInfo.isFree
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-yellow-500/10 border-yellow-500/30 text-yellow-300'
              }`}>
                <div className="flex items-center space-x-2">
                  {priceInfo.isFree ? <Gift className="w-4 h-4 text-emerald-400" /> : <CreditCard className="w-4 h-4 text-yellow-400" />}
                  <span className="font-bold">
                    {priceInfo.isFree
                      ? `Free Game (Up to ${maxParticipants} players) • No checkout required`
                      : `${priceInfo.tier.label} Tier • ${priceInfo.formattedPrice} per live game`}
                  </span>
                </div>
                <span className="font-black text-sm">
                  {priceInfo.formattedPrice}
                </span>
              </div>
            </div>

            {/* TIMER & GAME RULES */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Question Countdown
                </label>
                <select
                  value={timerDurationSec}
                  onChange={(e) => setTimerDurationSec(Number(e.target.value))}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-2xl text-white font-bold focus:outline-none"
                >
                  <option value={5}>⚡ 5 Seconds (Blitz)</option>
                  <option value={10}>🚀 10 Seconds</option>
                  <option value={15}>⏱️ 15 Seconds (Fast)</option>
                  <option value={20}>🏆 20 Seconds (Standard)</option>
                  <option value={30}>🧠 30 Seconds</option>
                  <option value={60}>⌛ 60 Seconds</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Scoring Rules
                </label>
                <div className="bg-slate-950 border border-slate-800 p-3 rounded-2xl space-y-2 text-xs">
                  <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isRandom}
                      onChange={(e) => setIsRandom(e.target.checked)}
                      className="w-4 h-4 accent-amber-400"
                    />
                    <span>Randomize Question Order</span>
                  </label>
                  <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enableBonusSpeedPoints}
                      onChange={(e) => setEnableBonusSpeedPoints(e.target.checked)}
                      className="w-4 h-4 accent-amber-400"
                    />
                    <span>Bonus Speed Points (+50 max)</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                Display & Leaderboard Options
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showCorrectAnswer}
                    onChange={(e) => setShowCorrectAnswer(e.target.checked)}
                    className="w-4 h-4 accent-amber-400"
                  />
                  <span>Show Correct Answer After Timer</span>
                </label>
                <label className="flex items-center space-x-2 text-slate-300 font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableLeaderboard}
                    onChange={(e) => setEnableLeaderboard(e.target.checked)}
                    className="w-4 h-4 accent-amber-400"
                  />
                  <span>Show Live Standings Leaderboard</span>
                </label>
              </div>
            </div>

            <div className="pt-3 flex justify-between items-center border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="py-3 px-5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>BACK</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (maxParticipants > MAX_SUPPORTED_PLAYERS) {
                    setValidationError(`Maximum capacity is currently ${MAX_SUPPORTED_PLAYERS} players.`);
                    return;
                  }
                  setValidationError(null);
                  setCurrentStep(3);
                }}
                className="py-3 px-6 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow flex items-center space-x-2"
              >
                <span>NEXT: REVIEW & CHECKOUT</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Review, Entitlement & Checkout */}
        {currentStep === 3 && (
          <div className="space-y-5 text-sm">
            
            {/* Review Order Card */}
            <div className="bg-indigo-950/70 border border-indigo-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-indigo-800/60 pb-3">
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider">
                  Live Game Order Summary
                </span>
                <span className="text-xs bg-indigo-900 text-indigo-200 font-bold px-2.5 py-0.5 rounded-full border border-indigo-700/50">
                  {priceInfo.isFree ? 'Free Game' : 'Pay-As-You-Go'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Your Game</span>
                  <span className="font-black text-white text-sm truncate block">{title}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Game Mode</span>
                  <span className="font-black text-amber-400 text-sm">
                    {questionMode === 'mixed' ? '🎲 Mixed Question Types' : `⚡ ${getQuestionTypeLabel(questionMode as QuestionType)} Only`}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Questions & Timer</span>
                  <span className="font-bold text-white">{effectiveCount} Questions • {timerDurationSec}s timer</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Player Capacity</span>
                  <span className="font-black text-white text-sm flex items-center space-x-1">
                    <Users className="w-3.5 h-3.5 text-amber-400" />
                    <span>{maxParticipants} Players</span>
                  </span>
                </div>
              </div>

              {/* Total & Price Breakdown Line */}
              <div className="pt-3 border-t border-indigo-800/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block">Total Amount</span>
                  <span className="text-[10px] text-slate-500">
                    {priceInfo.isFree ? 'No payment required for up to 5 players' : 'One game • No recurring billing'}
                  </span>
                </div>
                <div className="text-2xl font-black text-yellow-400">
                  {priceInfo.formattedPrice}
                </div>
              </div>
            </div>

            {/* Save Template Section */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-300 uppercase">
                <Bookmark className="w-4 h-4 text-amber-400" />
                <span>Save Settings as Reusable Template</span>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Template Name (e.g. Speed Trivia, Staff Duel)..."
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleSaveCustomTemplate}
                  disabled={!templateName.trim() || isSavingTemplate}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-amber-400 font-bold text-xs rounded-xl border border-slate-700 flex items-center space-x-1.5 flex-shrink-0"
                >
                  {templateSavedSuccess ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">Saved!</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>Save Template</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex justify-between items-center border-t border-slate-800">
              <button
                type="button"
                onClick={() => setCurrentStep(2)}
                disabled={isSubmitting}
                className="py-3 px-5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>BACK</span>
              </button>

              <button
                type="button"
                onClick={handleProceedToLaunchOrPayment}
                disabled={isSubmitting || effectiveCount === 0}
                className="py-3.5 px-8 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-amber-400/20 flex items-center space-x-2 transform active:scale-95 transition-all"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    <span>PREPARING GAME...</span>
                  </>
                ) : priceInfo.isFree ? (
                  <>
                    <Play className="w-4 h-4 fill-current text-slate-950" />
                    <span>LAUNCH FREE GAME (UP TO 5 PLAYERS)</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4 text-slate-950" />
                    <span>PROCEED TO CHECKOUT ({priceInfo.formattedPrice})</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Mock Payment Simulation Modal */}
      {paymentInitData && (
        <MockPaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          initData={paymentInitData}
          hostId={user?.id || profile?.id || 'host_default'}
          hostEmail={user?.email || profile?.email}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Question Participant View Overlay */}
      <ParticipantQuestionPreviewModal
        question={previewQuestion}
        isOpen={Boolean(previewQuestion)}
        onClose={() => setPreviewQuestion(null)}
        timerDurationSec={timerDurationSec}
      />

    </div>
  );
};
