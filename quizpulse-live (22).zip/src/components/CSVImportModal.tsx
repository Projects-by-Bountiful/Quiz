import React, { useState, useEffect } from 'react';
import { Upload, X, CheckCircle2, AlertTriangle, XCircle, ArrowRight, RefreshCw, FileSpreadsheet, Eye, Filter } from 'lucide-react';
import { Question } from '../types';
import { parseQuestionsCSV, CSVImportReport, CSVRowItem } from '../utils/csv';

interface CSVImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  csvText: string;
  existingQuestions: Question[];
  onQuestionsImported: (questions: Question[]) => void;
}

export const CSVImportModal: React.FC<CSVImportModalProps> = ({
  isOpen,
  onClose,
  csvText,
  existingQuestions,
  onQuestionsImported
}) => {
  const [report, setReport] = useState<CSVImportReport | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showOnlyErrors, setShowOnlyErrors] = useState(false);

  useEffect(() => {
    if (isOpen && csvText) {
      const rep = parseQuestionsCSV(csvText, existingQuestions, true);
      setReport(rep);
      const validIds = new Set(rep.questions.map(q => q.id));
      setSelectedIds(validIds);
      setShowOnlyErrors(rep.failedCount > 0 && rep.importedCount === 0);
    }
  }, [isOpen, csvText, existingQuestions.length]);

  if (!isOpen || !report) return null;

  const handleToggleSelect = (qId: string) => {
    const next = new Set(selectedIds);
    if (next.has(qId)) next.delete(qId);
    else next.add(qId);
    setSelectedIds(next);
  };

  const handleSelectAll = () => {
    const validQuestions = report.questions;
    if (selectedIds.size === validQuestions.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(validQuestions.map(q => q.id)));
    }
  };

  const handleConfirmImport = () => {
    const questionsToImport = report.questions.filter(q => selectedIds.has(q.id));
    if (questionsToImport.length > 0) {
      onQuestionsImported(questionsToImport);
      onClose();
    }
  };

  const visibleItems = report.items.filter(item => {
    if (showOnlyErrors) {
      return item.status === 'INVALID' || item.status === 'DUPLICATE';
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-5xl p-5 sm:p-8 shadow-2xl relative space-y-6 my-6">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-yellow-400 to-amber-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-yellow-400/20">
            <FileSpreadsheet className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">CSV File Import Preview</h2>
            <p className="text-xs text-slate-400 font-semibold">Validate CSV rows, inspect errors, and select questions to import</p>
          </div>
        </div>

        {/* Summary Stats Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
            <span className="px-3 py-1 bg-slate-800 text-slate-200 font-black rounded-full border border-slate-700">
              {report.totalRows} Questions
            </span>

            <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-black rounded-full flex items-center space-x-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{report.importedCount} Valid</span>
            </span>

            {report.failedCount > 0 && (
              <span className="px-3 py-1 bg-rose-500/10 border border-rose-500/30 text-rose-400 font-extrabold rounded-full flex items-center space-x-1">
                <XCircle className="w-3.5 h-3.5" />
                <span>{report.failedCount} Failed</span>
              </span>
            )}

            {report.skippedDuplicatesCount > 0 && (
              <span className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold rounded-full flex items-center space-x-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{report.skippedDuplicatesCount} Duplicates Skipped</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            {report.failedCount > 0 && (
              <button
                onClick={() => setShowOnlyErrors(!showOnlyErrors)}
                className={`px-3 py-1.5 text-xs font-bold rounded-xl border transition-colors flex items-center space-x-1.5 ${
                  showOnlyErrors
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                <span>{showOnlyErrors ? 'Show All Rows' : 'View Errors'}</span>
              </button>
            )}

            <button
              onClick={handleSelectAll}
              disabled={report.importedCount === 0}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl border border-slate-700 disabled:opacity-40"
            >
              {selectedIds.size === report.questions.length ? 'Deselect All' : 'Select All Valid'}
            </button>
          </div>
        </div>

        {/* Error Details Box if View Errors is active or errors exist */}
        {report.errors.length > 0 && showOnlyErrors && (
          <div className="bg-rose-950/40 border border-rose-800/60 rounded-2xl p-4 text-xs space-y-2 max-h-40 overflow-y-auto">
            <p className="font-extrabold text-rose-300 flex items-center space-x-2">
              <XCircle className="w-4 h-4 text-rose-400" />
              <span>Import Failure Log ({report.errors.length} issues)</span>
            </p>
            <ul className="list-disc list-inside space-y-1 text-rose-200/90 font-mono text-[11px]">
              {report.errors.map((err, idx) => (
                <li key={idx}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Table Preview */}
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950/80 max-h-[400px] overflow-y-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-900 sticky top-0 border-b border-slate-800 text-[11px] font-black uppercase text-slate-400 tracking-wider z-10">
              <tr>
                <th className="p-3.5 w-12 text-center">Import</th>
                <th className="p-3.5 w-16">Row</th>
                <th className="p-3.5">Question & Options</th>
                <th className="p-3.5 w-32">Category & Level</th>
                <th className="p-3.5 w-32">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-xs">
              {visibleItems.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500 font-semibold">
                    No rows to display.
                  </td>
                </tr>
              ) : (
                visibleItems.map((item) => {
                  const isValid = item.status === 'VALID' && item.question;
                  const isSelected = isValid ? selectedIds.has(item.question!.id) : false;
                  const isInvalid = item.status === 'INVALID';
                  const isDuplicate = item.status === 'DUPLICATE';

                  return (
                    <tr
                      key={item.rowNumber}
                      className={`transition-colors ${
                        isInvalid
                          ? 'bg-rose-950/20'
                          : isDuplicate
                          ? 'bg-amber-950/20'
                          : isSelected
                          ? 'bg-slate-900/90'
                          : 'bg-slate-950/40 opacity-75'
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="p-3.5 text-center align-top">
                        <input
                          type="checkbox"
                          disabled={!isValid}
                          checked={isSelected}
                          onChange={() => isValid && handleToggleSelect(item.question!.id)}
                          className="w-4 h-4 accent-yellow-400 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
                        />
                      </td>

                      {/* Row Num */}
                      <td className="p-3.5 align-top font-mono font-bold text-slate-400 text-[11px]">
                        #{item.rowNumber}
                      </td>

                      {/* Question Details */}
                      <td className="p-3.5 align-top space-y-2">
                        <p className="font-bold text-white text-sm">
                          {item.rawQuestion || '(Empty question)'}
                        </p>

                        {/* Options */}
                        {item.rawOptions && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                            {item.rawOptions.map((opt, oIdx) => {
                              const letter = String.fromCharCode(65 + oIdx);
                              const isCorrect = item.question ? item.question.correctAnswer === oIdx : false;

                              return (
                                <div
                                  key={oIdx}
                                  className={`p-2 rounded-xl border text-xs flex items-center space-x-2 ${
                                    isCorrect
                                      ? 'bg-emerald-500/15 border-emerald-400/60 text-emerald-200 font-bold'
                                      : 'bg-slate-900/60 border-slate-800 text-slate-400'
                                  }`}
                                >
                                  <span className={`w-5 h-5 rounded-lg flex items-center justify-center font-black text-[10px] ${
                                    isCorrect ? 'bg-emerald-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                                  }`}>
                                    {letter}
                                  </span>
                                  <span className="truncate">{opt || `(Empty)`}</span>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* Error message */}
                        {item.errorMessage && (
                          <p className="text-[11px] font-semibold text-rose-400 bg-rose-950/50 p-2 rounded-xl border border-rose-900">
                            ⚠️ {item.errorMessage}
                          </p>
                        )}
                      </td>

                      {/* Category & Difficulty */}
                      <td className="p-3.5 align-top space-y-1">
                        <span className="px-2 py-0.5 bg-slate-800 text-slate-300 font-bold text-[10px] rounded block truncate">
                          {item.rawCategory || 'General Knowledge'}
                        </span>
                        <span className="px-2 py-0.5 bg-slate-800/60 text-yellow-400 font-semibold text-[10px] rounded block">
                          {item.rawDifficulty || 'Medium'}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="p-3.5 align-top">
                        {isValid && (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-extrabold text-[11px] rounded-xl">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Valid</span>
                          </span>
                        )}
                        {isInvalid && (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-rose-500/10 border border-rose-500/30 text-rose-400 font-extrabold text-[11px] rounded-xl">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Invalid</span>
                          </span>
                        )}
                        {isDuplicate && (
                          <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 font-extrabold text-[11px] rounded-xl">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Duplicate</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Action Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <span className="text-xs font-bold text-slate-400">
            {selectedIds.size} of {report.importedCount} valid questions selected
          </span>

          <button
            onClick={handleConfirmImport}
            disabled={selectedIds.size === 0}
            className="py-3.5 px-6 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-sm rounded-2xl shadow-lg shadow-yellow-400/20 disabled:opacity-40 transition-all flex items-center space-x-2"
          >
            <span>CONFIRM & IMPORT {selectedIds.size} QUESTIONS</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
