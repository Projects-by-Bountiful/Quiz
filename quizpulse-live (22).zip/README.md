# QuizPulse Live — Real-Time Multiplayer Quiz & Trivia Platform

> **QuizPulse Live** is a full-stack, real-time multiplayer live quiz platform built for corporate events, classrooms, workshops, watch-parties, and trivia nights. It features sub-second synchronized timers, dynamic question engines, dedicated presenter projector views, AI-powered question generation, comprehensive host analytics, and transparent **Pay-As-You-Go (PAYG)** game pricing.

---

## 📑 Table of Contents

1. [Architectural Overview](#-architectural-overview)
2. [User Roles & Experience Flows](#-user-roles--experience-flows)
3. [Feature Breakdown by Section](#-feature-breakdown-by-section)
   - [1. Landing Page & Public Arena](#1-landing-page--public-arena)
   - [2. Authentication & Host Profiles](#2-authentication--host-profiles)
   - [3. Host Workspace & Dashboard](#3-host-workspace--dashboard)
   - [4. Question Bank Management & Ingestion](#4-question-bank-management--ingestion)
   - [5. AI Question Generator (Gemini 2.5)](#5-ai-question-generator-gemini-25)
   - [6. Five Interactive Question Engines](#6-five-interactive-question-engines)
   - [7. Quiz Creation Wizard & Template System](#7-quiz-creation-wizard--template-system)
   - [8. Pay-As-You-Go (PAYG) Pricing & Payment System](#8-pay-as-you-go-payg-pricing--payment-system)
   - [9. Live Game Session & Synchronized Timer](#9-live-game-session--synchronized-timer)
   - [10. Presenter Mode (Big-Screen TV / Projector)](#10-presenter-mode-big-screen-tv--projector)
   - [11. Live Leaderboard, Scoring & Speed Bonus Engine](#11-live-leaderboard-scoring--speed-bonus-engine)
   - [12. Analytics Dashboard & Post-Event Reports](#12-analytics-dashboard--post-event-reports)
   - [13. Sound & Celebration Systems](#13-sound--celebration-systems)
4. [Real-Time Synchronization Engine](#-real-time-synchronization-engine)
5. [Project Structure](#-project-structure)
6. [Environment Configuration](#-environment-configuration)
7. [Build, Development & Deployment](#-build-development--deployment)
8. [Maintenance & README Update Guide](#-maintenance--readme-update-guide)

---

## 🏗️ Architectural Overview

QuizPulse Live is engineered as a modern, unified TypeScript full-stack application:

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Motion (animations), Lucide React (icons), Canvas-Confetti, QRCode.
- **Backend / API**: Express 4 running on Node.js / `tsx` (dev) and pre-bundled CommonJS with `esbuild` (production) on Port 3000.
- **AI Intelligence**: Google Gemini API via `@google/genai` TypeScript SDK (server-side proxy for prompt generation and question banking).
- **Real-Time Data Layer**: Dual-layer architecture:
  1. **Supabase Realtime**: Broadcast channel synchronization for multi-device events across mobile and desktop.
  2. **In-Memory / Local Storage Fallback**: Automatic failover enabling complete local standalone play even if cloud credentials are absent.
- **Audio Synthesis Engine**: Web Audio API synthesized procedural sounds (clock tick, ding, buzz, fanfare, swoosh) without external audio asset dependencies.

---

## 👥 User Roles & Experience Flows

### 1. The Host (Organizer / Presenter / Teacher)
- Creates question banks, imports spreadsheets, or uses Gemini AI to auto-generate balanced quizzes.
- Configures game parameters (countdown duration, speed bonuses, capacity limits).
- Controls the live room state (starts game, advances questions, reveals answers, triggers standings, finishes game).
- Accesses real-time response charts, participant lists, kicking controls, and post-game CSV analytics.

### 2. The Participant (Player / Attendee)
- Joins with zero registration required using a 6-character PIN or scanning the QR code on a mobile device or browser.
- Selects an avatar and nickname.
- Answers questions in real-time with responsive touch/click feedback, lock-in confirmations, and instant score updates.
- Sees customized end-game summary and gives post-event host feedback.

### 3. The Audience / Big-Screen View (Presenter Mode)
- Dedicated display route designed specifically for projectors, stage TVs, or Zoom screen shares.
- High-contrast, giant typography with real-time response distribution graphs and podium animations.

---

## 🔍 Feature Breakdown by Section

### 1. Landing Page & Public Arena
- **Hero Banner**: Instant call-to-actions for **Host a Game** and **Join Live Game**.
- **Interactive PIN Join Card**: Auto-capitalizing 6-digit PIN input with instant room validation.
- **Interactive Mini-Playground**: Allows visitors to test question mechanics right on the landing page before starting a game.
- **Live Feature Highlights**: Breakdown of interactive question formats, AI generators, and synchronization capabilities.
- **Transparent Pricing Section**: Interactive PAYG tier breakdown (Free up to 5 players, tiered up to 100 players).
- **Target Use Cases**: Tailored value propositions for Corporate All-Hands, Universities & Schools, Virtual Meetups, and Game Nights.

---

### 2. Authentication & Host Profiles
- **Authentication Routes**:
  - `LoginPage`: Secure sign-in with email & password, remember me, and demo login shortcut.
  - `SignupPage`: Host registration with validation and terms acceptance.
  - `ForgotPasswordPage` & `ResetPasswordPage`: Password recovery flow.
  - `EmailVerificationPage`: Account confirmation screen.
- **Host Profile Management**:
  - Custom display name, company / organization name, avatar selection.
  - Organization branding preferences (custom theme colors, default game durations).
  - Storage for custom saved quiz templates and recent billing receipts.

---

### 3. Host Workspace & Dashboard
The host workspace provides a comprehensive navigation hierarchy across:
1. **Question Banks**: Complete inventory of all available questions, filterable by category, type, and difficulty.
2. **Categories**: Create and color-tag question topics with automatic count indicators.
3. **Quiz Sessions**: Quick launcher for standard quizzes, mixed trivia, or custom pools.
4. **Billing & Payments**: Comprehensive transaction history, receipt details, capacity upgrades, and pricing modal.
5. **Participants Management**: Live participant tracking, ping status, and one-click remove/kick controls.
6. **Analytics & Performance**: Aggregated accuracy rates, toughest questions, and speed metrics.
7. **Game History**: Past session logs, winner archives, replay data, and CSV exports.
8. **Settings & Preferences**: Default timer speeds, sound effect toggles, celebration particle switches.

---

### 4. Question Bank Management & Ingestion
Hosts have five flexible ways to build and manage questions:

- **Single Question Creator**: Interactive modal with support for all 5 question types, rich options editor, explanations, and difficulty ratings (`Easy`, `Medium`, `Hard`).
- **Add Question Repeater Modal**: Rapid sequential input tool allowing organizers to enter 10+ questions continuously without closing modals.
- **CSV Spreadsheet Importer**:
  - Downloadable CSV template file.
  - Automatic column mapping (`question`, `type`, `options`, `correct_answer`, `category`, `difficulty`, `explanation`).
  - Strict validation engine that flags syntax errors before importing.
- **Bulk Text / AI Smart Parser**:
  - Paste unformatted quiz text or outputs from ChatGPT/Claude.
  - Automatically parses question numbers, choices (`A)`, `B)`, `C)`, `D)`), and answer keys (`Answer: B`).
- **Question Preview Drawer**: Real-time mock preview showing exactly how questions render on participant phones.

---

### 5. AI Question Generator (Gemini 2.5)
- Powered by server-side Google Gemini 2.5 / 2.0 Flash models via `/api/ai/generate-questions`.
- **Customizable Controls**:
  - Topic / Subject Prompt (e.g., *"Cloud Computing Fundamentals"*, *"African History"*, *"90s Pop Culture"*).
  - Question Format Selection (Multiple Choice, Fastest Fingers, Fill in the Blank, Ordering, Matching, or Mixed).
  - Difficulty distribution (Easy, Medium, Hard, or Balanced Mix).
  - Target Quantity (1 to 20 questions in a single generation batch).
- **Direct Insertion**: Generated questions are reviewed in a preview matrix where the host can edit, deselect, and import into their active question bank with one click.

---

### 6. Five Interactive Question Engines

QuizPulse features 5 specialized question types located in `/src/components/questions/`:

| Question Type | Engine Component | Description & Mechanics |
| :--- | :--- | :--- |
| **Multiple Choice** | `MultipleChoiceQuestion.tsx` | Traditional 2 to 4 options with colored geometry cards (Red Triangle, Blue Diamond, Yellow Circle, Green Square). |
| **Fastest Fingers** | `FastestFingersQuestion.tsx` | High-stakes 2-choice rapid duel designed for rapid reflexes and maximum speed bonus points. |
| **Fill in the Blank** | `FillBlankQuestion.tsx` | Text submission input with fuzzy string normalization, case-insensitivity, trim handling, and multiple accepted alternative answers. |
| **Ordering / Sequence** | `OrderingQuestion.tsx` | Drag-and-drop / click-to-reorder sequence engine for sorting historical dates, process steps, or numerical values. |
| **Matching Pairs** | `MatchingQuestion.tsx` | Interactive two-column connector where players pair related items (e.g. Countries to Capitals, Terms to Definitions) before time expires. |

---

### 7. Quiz Creation Wizard & Template System
A 3-step structured game launcher modal (`QuizCreationWizardModal.tsx`):
- **Step 1: Game Mode, Title & Questions**:
  - Choose between Mixed Types or dedicated formats.
  - Choose Auto-selection by categories or Hand-pick specific questions from bank.
- **Step 2: Capacity, Rules & Pricing**:
  - Set Participant Capacity Limit (1–100 players) with instant price tier calculation.
  - Set Question Timer (5s Blitz, 10s, 15s, 20s Standard, 30s, 60s).
  - Configure Scoring Rules: Randomize order, Speed bonus points toggle, Answer reveal toggle, Live leaderboard display.
- **Step 3: Review & Checkout**:
  - Summary review of game rules, questions, and player limit.
  - Option to save the current configuration as a reusable **Quiz Template**.
  - Direct launch for free games (≤ 5 players) or checkout flow trigger for paid tiers.

---

### 8. Pay-As-You-Go (PAYG) Pricing & Payment System

QuizPulse implements a transparent **Pay-As-You-Go (PAYG)** model where creating quizzes, organizing banks, and importing questions is 100% free. Hosts only pay when launching a live session with over 5 participants:

#### Authoritative Pricing Tiers
- **Starter Tier (0–5 Players)**: **FREE** (₦0) — Unlimited free live games.
- **Small Event (6–10 Players)**: **₦5,000** per live session.
- **Medium Event (11–20 Players)**: **₦10,000** per live session *(Most Popular)*.
- **Large Event (21–50 Players)**: **₦25,000** per live session.
- **High-Scale Enterprise (51–100 Players)**: **₦50,000** per live session.
- **Maximum Player Limit**: Strictly enforced at **100 participants** to ensure low-latency WebSocket synchronization.

#### Payment Infrastructure & Resilient Entitlements
- **Architecture**: Located in `/src/services/payment/`:
  - `types.ts`: Strongly typed payment intents, verification records, and game entitlements.
  - `pricingConfig.ts`: Authoritative price calculations and formatting utilities.
  - `paymentService.ts`: Extensible payment abstraction layer with pre-launch entitlement validation.
  - `mockPaymentProvider.ts`: Safe simulated checkout engine supporting instant card & bank transfer simulation, idempotency keys, and payment failure simulation toggles.
- **Double-Billing Protection**: If room creation fails after successful payment verification, the host's entitlement remains safely active, displaying a one-click **Retry Room Launch** recovery action without charging again.
- **Billing History View** (`PaymentHistoryView.tsx`): Searchable host transaction table with reference IDs, player capacities, timestamps, status pills, and downloadable payment receipts.

---

### 9. Live Game Session & Synchronized Timer
- **Waiting Lobby (`WaitingRoom.tsx`)**:
  - Prominent 6-character Room PIN and auto-generated QR Code.
  - Live participant bubbles updating in real-time as players join.
  - Host controls to start game when players are ready.
- **Synchronized Countdown Engine (`useSynchronizedTimer.ts`)**:
  - Calculates time using host timestamps rather than local browser intervals.
  - Compensates for clock drift and network lag across participants.
  - Visual circular / linear progress bars that transition from emerald -> amber -> rose as time runs low.
- **Answer Lock-in & Reveal (`AnswerReveal.tsx`)**:
  - Instant tactile feedback when a participant taps an answer.
  - Visual percentage distribution bar charts on host & presenter screens.
  - Displays correct answer along with custom explanations.

---

### 10. Presenter Mode (Big-Screen TV / Projector)
- Accessible via `/src/components/PresenterModeView.tsx`.
- Designed for large-format displays:
  - Full-screen distraction-free UI.
  - Giant question typography and enlarged high-contrast option cards.
  - Live bar chart reflecting answer submissions in real time.
  - Standings transitions with podium effects.

---

### 11. Live Leaderboard, Scoring & Speed Bonus Engine
- **Base Score**: 100 points per correct answer.
- **Speed Bonus Points**: Up to +50 bonus points calculated dynamically based on the fraction of time remaining when the answer was submitted:
  $$\text{Bonus} = \text{round}\left(50 \times \frac{\text{Time Remaining}}{\text{Total Timer Duration}}\right)$$
- **Leaderboard Animations (`LeaderboardView.tsx`)**:
  - Real-time animated position reordering.
  - Top 3 highlighted with Gold, Silver, and Bronze badges.
  - Current streak counter and "+Points" floating indicators.
- **Victory Podium (`ResultsView.tsx`)**:
  - 3D-styled Olympic podium for 1st, 2nd, and 3rd place.
  - Multi-colored confetti burst celebration via `canvas-confetti`.
  - Full downloadable rankings leaderboard for the host.

---

### 12. Analytics Dashboard & Post-Event Reports
- **Live In-Game Analytics (`AnalyticsDashboard.tsx`)**:
  - Real-time question difficulty index (% correct per question).
  - Average response time per question in seconds.
  - Participant drop-off and engagement rates.
- **Post-Event Report Modal (`PostEventReportModal.tsx`)**:
  - Executive summary of session attendance, total points scored, and top questions.
  - Participant feedback score aggregate (1–5 stars and written notes).
  - One-click **Export to CSV** for complete classroom/event grading.

---

### 13. Sound & Celebration Systems
- **Sound Engine (`/src/utils/sound.ts`)**:
  - Pure Web Audio API procedural sound generation.
  - Sound effects for: Correct Answer, Wrong Answer, Countdown Tick, Warning Tick, Fanfare Victory, UI Click, Level Transition.
  - Host global sound toggle (enable/disable with persistent preference).
- **Celebration Particle System**:
  - Full-screen physics confetti bursts on podium reveals.
  - Streamlined celebratory particle effects for fastest responses.

---

## ⚡ Real-Time Synchronization Engine

The platform coordinates state using `useRealtimeSession.ts`:

```
┌─────────────────────────────────────────────────────────────┐
│                      Host Controller                        │
│ (Starts Game -> Next Question -> Reveal -> Standings -> End)│
└──────────────────────────────┬──────────────────────────────┘
                               │ Broadcasts State Payload
                               ▼
┌─────────────────────────────────────────────────────────────┐
│           Supabase Realtime Channel / Local Relay           │
│             Channel: `quizpulse_session_{sessionPin}`       │
└──────────────┬───────────────────────────────┬──────────────┘
               │                               │
               ▼                               ▼
┌──────────────────────────────┐ ┌────────────────────────────┐
│      Participant Devices     │ │     Presenter Display      │
│  (Mobile Phones / Tablets)   │ │    (Projector / Large TV)  │
└──────────────────────────────┘ └────────────────────────────┘
```

### Game State Transitions:
1. `waiting`: Players join lobby; PIN & QR code active.
2. `question`: Question text, options, and countdown timer live.
3. `reveal`: Correct answer highlighted; response distribution shown.
4. `leaderboard`: Live standings and score changes animated.
5. `results`: Final podium, confetti celebration, and feedback form.

---

## 📁 Project Structure

```
├── .env.example                       # Environment variable definitions
├── metadata.json                      # Application metadata and permissions
├── package.json                       # Dependencies and build scripts
├── server.ts                          # Express server & Gemini API proxy
├── src/
│   ├── App.tsx                        # Master app router & state coordinator
│   ├── index.css                      # Global Tailwind CSS imports & theme rules
│   ├── main.tsx                       # React application DOM entry point
│   ├── types.ts                       # Global TypeScript data contracts & schemas
│   ├── components/
│   │   ├── AIQuestionGeneratorModal.tsx   # Gemini AI question generator dialog
│   │   ├── AddQuestionRepeaterModal.tsx   # Continuous rapid question entry modal
│   │   ├── AnalyticsDashboard.tsx         # Real-time host metrics & accuracy charts
│   │   ├── AnswerReveal.tsx               # Question resolution & distribution view
│   │   ├── BulkPasteModal.tsx             # Raw text quiz parser
│   │   ├── CSVImportModal.tsx             # Spreadsheet batch importer & validator
│   │   ├── EmailVerificationPage.tsx      # Email verification flow
│   │   ├── EventFeedbackComponent.tsx     # Player post-game rating form
│   │   ├── Footer.tsx                     # Global footer with navigation links
│   │   ├── ForgotPasswordPage.tsx         # Account recovery request page
│   │   ├── GameHistoryView.tsx            # Historical past games archive
│   │   ├── HostDashboard.tsx              # Host live game control cockpit
│   │   ├── HostOnboardingChecklist.tsx    # Interactive onboarding guide for hosts
│   │   ├── HostQuickTip.tsx               # Contextual tips for event hosts
│   │   ├── HostWorkspace.tsx              # Main host tabs & navigation shell
│   │   ├── LandingPage.tsx                # Public home page & marketing arena
│   │   ├── LeaderboardView.tsx            # Live rankings & animated scores
│   │   ├── LoginPage.tsx                  # Host sign-in page
│   │   ├── MockPaymentModal.tsx           # PAYG simulated checkout modal
│   │   ├── Navbar.tsx                     # Global navigation header with role toggles
│   │   ├── ParticipantJoin.tsx            # Player join with PIN and nickname
│   │   ├── ParticipantQuestionPreviewModal.tsx # Mobile view preview simulator
│   │   ├── PaymentHistoryView.tsx         # Host billing history & receipt modal
│   │   ├── PostEventReportModal.tsx       # Comprehensive session summary dialog
│   │   ├── PresenterModeView.tsx          # Full-screen TV / Projector display
│   │   ├── PricingModal.tsx               # Interactive pricing & tier comparison
│   │   ├── QuestionBank.tsx               # Question management inventory
│   │   ├── QuestionView.tsx               # Active question display for players
│   │   ├── QuizCreationWizardModal.tsx    # 3-Step game builder & checkout wizard
│   │   ├── ResetPasswordPage.tsx          # Password reset form
│   │   ├── ResultsView.tsx                # Victory podium & celebration finish
│   │   ├── SessionSettingsModal.tsx       # Host quick session parameters modal
│   │   ├── SignupPage.tsx                 # Host account registration page
│   │   ├── SupabaseDiagnosticModal.tsx    # Connection health & debug utility
│   │   ├── WaitingRoom.tsx                # Pre-game participant lobby
│   │   └── questions/                     # Dedicated question engine implementations
│   │       ├── FastestFingersQuestion.tsx # 2-choice rapid duel engine
│   │       ├── FillBlankQuestion.tsx      # Fuzzy text input matching engine
│   │       ├── MatchingQuestion.tsx       # Interactive column connector engine
│   │       ├── MultipleChoiceQuestion.tsx # Geometric 4-choice card engine
│   │       └── OrderingQuestion.tsx       # Drag-and-drop sequence ordering engine
│   ├── config/
│   │   └── pricingConfig.ts               # Authoritative PAYG tiers & player limits
│   ├── context/
│   │   └── AuthContext.tsx                # Host session & profile state provider
│   ├── data/                              # Default initial question bank & templates
│   ├── services/
│   │   └── payment/                       # Modular payment facade & providers
│   │       ├── mockPaymentProvider.ts     # Simulated card/transfer gateway
│   │       ├── paymentService.ts          # Unified payment & entitlement service
│   │       └── types.ts                   # Payment data schemas & intents
│   └── utils/
│       ├── bulkParser.ts                  # Raw quiz text parsing algorithm
│       ├── csv.ts                         # CSV parser & template generator
│       ├── questionEngine.ts              # Type badge colors & validation logic
│       ├── sound.ts                       # Web Audio API procedural sound engine
│       ├── stats.ts                       # Performance calculation helpers
│       ├── supabase.ts                    # Supabase client initializer
│       ├── url.ts                         # URL join link helpers
│       ├── useRealtimeSession.ts          # Supabase real-time sync hook
│       └── useSynchronizedTimer.ts        # Drift-compensated clock hook
```

---

## ⚙️ Environment Configuration

Define the following environment variables in your `.env` file (see `.env.example`):

```env
# Google Gemini API Key for AI Question Generation
GEMINI_API_KEY=your_gemini_api_key_here

# Optional: Supabase Realtime Credentials for Multi-Device Cloud Sync
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

> **Note**: QuizPulse is designed with full offline/local resilience. If Supabase keys are not set, the platform automatically utilizes in-memory channel relays and local storage persistence.

---

## 🚀 Build, Development & Deployment

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```
The server binds to `0.0.0.0:3000` with Vite middleware mounted automatically.

### 3. Type Checking & Linting
```bash
npm run lint
```

### 4. Production Build
```bash
npm run build
```
This compiles the client-side SPA into `dist/` and bundles `server.ts` into `dist/server.cjs` via `esbuild`.

### 5. Production Start
```bash
npm start
```

---

## 🔄 Maintenance & README Update Guide

When extending or modifying QuizPulse Live, keep this document synchronized by following these guidelines:

1. **New Question Types**:
   - Create the engine component in `src/components/questions/`.
   - Update `QuestionType` enum in `src/types.ts`.
   - Add validation rules in `src/utils/questionEngine.ts`.
   - Update **Section 6 (Interactive Question Engines)** of this README with mechanics and screenshots/descriptions.

2. **New Pricing Tiers or Payment Gateways**:
   - Update `src/config/pricingConfig.ts` with new capacity or currency rules.
   - Implement gateway providers under `src/services/payment/`.
   - Update **Section 8 (PAYG Pricing & Payment System)** of this README.

3. **New Host Workspace Tabs or Roles**:
   - Update navigation items in `HostWorkspace.tsx` and role definitions in `src/types.ts`.
   - Document the new tab's purpose in **Section 3 (Host Workspace & Dashboard)**.

4. **Synchronizing Environment Variables**:
   - Always declare newly added environment keys in `.env.example` and update **Section 6 (Environment Configuration)** above.
